﻿using Microsoft.SharePoint.Client;
using System;
using System.Text;
using System.Configuration;
using System.Net.Mail;
using System.IO;
using CPRONotifications.Common;

namespace CPRONotifications
{
    class Program
    {
        static readonly string TemplateFolderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "EmailTemplates");
        static ClientContext context = new ClientContext(ConfigurationManager.AppSettings["siteURL"]);
        static StreamWriter errLogWrtr;
        static StreamWriter logWrtr;

        static void Main(string[] args)
        {
            var errLogFile = "";
            var logFile = "";
            var projectNumber = "";

            try
            {
                // Set credentials
                context.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["ImpersUser"],
                    ConfigurationManager.AppSettings["ImpersPssd"], ConfigurationManager.AppSettings["ImpersDomain"]);

                // Setup writers
                var timeStamp = GetTimestamp(DateTime.Now);
                errLogFile = ConfigurationManager.AppSettings["ErrorLogPath"] + "\\" + "CPRONotify_" + timeStamp + "_ErrorLog.txt";
                logFile = ConfigurationManager.AppSettings["LogPath"] + "\\" + "CPRONotify_" + timeStamp + "_Log.txt";
                errLogWrtr = new StreamWriter(errLogFile);
                logWrtr = new StreamWriter(logFile);

                // Evaluate incomplete projects with date of first use = today
                // Approval Status != submitted aka Not Approved
                ListItemCollection dofuProjects = GetCPROListItems(MessageType.DateOfFirstUseApproval);
                foreach (ListItem listItem in dofuProjects)
                {
                    // Build email
                    Email email = new Email();
                    email.DisplayName = "";
                    var dateNull = new DateTime(1, 1, 1);

                    //Get Project Number
                    projectNumber = GetProjectNumber(listItem);

                    // ensure submitter is set
                    if (listItem["Writer"] != null)
                    {

                        // Build submitter user value
                        var submitter = context.Web.EnsureUser(((FieldUserValue)listItem["Writer"]).LookupValue);
                        context.Load(submitter);
                        context.ExecuteQuery();


                        // Build approver user value
                        User approver = null;
                        if (listItem["ApprovingManager"] != null)
                        {
                            approver = context.Web.EnsureUser(((FieldUserValue)listItem["ApprovingManager"]).LookupValue);
                            context.Load(approver);
                            context.ExecuteQuery();
                        }

                        email.To = submitter.Email;
                        if (approver != null)
                            email.To += "," + approver.Email;
                        email.Subject = "Project Date of First Use Due Today " + projectNumber + " - " + listItem["Title"];
                        email.CC = ConfigurationManager.AppSettings["dateOfFirstUseDueEmailCC"];
                        email.HtmlBody = ReturnEmailHTML(MessageType.DateOfFirstUseApproval, Convert.ToInt32(listItem["ID"]), projectNumber, dateNull, 0);
                        SendMail(email);
                        logWrtr.WriteLine("DOFU email sent for Project ID '" + projectNumber + "'; Recipient(s): " + email.To);
                    }
                    else
                        errLogWrtr.WriteLine("No Submitter assigned for Project ID '" + projectNumber + "'");
                }

                //Console.ReadLine();

                // Evaluate projects with expired communications, pull project records that have project approval status = 'submitted' and expiration notifications required flag = 'yes
                // Uses expiration date to determine number of days to expiration - will use 'revised' expiration date if populated over expiration date
                // Looks for project records with expiration dates at 5-30-60-90 day target and sends email to the submitter / writer and copies approving mgr
                // Expiration dates set during approval stage
                ListItemCollection doexProjects = GetCPROListItems(MessageType.ExpiredProjectCommunications);
                foreach (ListItem listItem in doexProjects)
                {
                    // Build email
                    Email email = new Email();
                    email.DisplayName = "";

                    // ensure both submitter and approvers are set
                    if (listItem["Writer"] != null && listItem["ApprovingManager"] != null)
                    {
                        // Build submitter user value
                        var submitter = context.Web.EnsureUser(((FieldUserValue)listItem["Writer"]).LookupValue);
                        context.Load(submitter);
                        context.ExecuteQuery();


                        // Build approver user value
                        var approver = context.Web.EnsureUser(((FieldUserValue)listItem["ApprovingManager"]).LookupValue);
                        context.Load(approver);
                        context.ExecuteQuery();


                        // Build Content Owner user value (if they exist)
                        User contentOwner = null;
                        if (listItem["Content_x0020_Owner"] != null)
                        {
                            contentOwner = context.Web.EnsureUser(((FieldUserValue)listItem["Content_x0020_Owner"]).LookupValue);
                            context.Load(contentOwner);
                            context.ExecuteQuery();
                        }

                        var todayDate = DateTime.Today;
                        var dateNull = new DateTime(1, 1, 1);
                        DateTime dtExpiration;

                        dtExpiration = DateTime.Parse(listItem["ExpirationDate"].ToString());
                        TimeSpan td = dtExpiration.Subtract(todayDate);
                        int days = td.Days;

                        //Get Project Number
                        projectNumber = GetProjectNumber(listItem);

                        email.To = submitter.Email;
                        email.CC = approver.Email;
                        if (contentOwner != null)
                            email.CC += "," + contentOwner.Email;

                        switch (days)
                        {

                            case 1:
                                {
                                    email.Subject = "Project expiration in  " + days.ToString() + " days. " + projectNumber + " - " + listItem["Title"];
                                    email.HtmlBody = ReturnEmailHTML(MessageType.ExpiredProjectCommunications, Convert.ToInt32(listItem["ID"]), projectNumber, dtExpiration, days);
                                    SendMail(email);
                                    logWrtr.WriteLine("Expired Communications email sent for Project ID '" + projectNumber + "'; Recipient(s): " + email.To);
                                    break;
                                }
                            case 15:
                                {
                                    email.Subject = "Project expiration in  " + days.ToString() + " days. " + projectNumber + " - " + listItem["Title"];
                                    email.HtmlBody = ReturnEmailHTML(MessageType.ExpiredProjectCommunications, Convert.ToInt32(listItem["ID"]), projectNumber, dtExpiration, days);
                                    SendMail(email);
                                    logWrtr.WriteLine("Expired Communications email sent for Project ID '" + projectNumber + "'; Recipient(s): " + email.To);
                                    break;
                                }
                            case 45:
                                {
                                    email.Subject = "Project expiration in  " + days.ToString() + " days. " + projectNumber + " - " + listItem["Title"];
                                    email.HtmlBody = ReturnEmailHTML(MessageType.ExpiredProjectCommunications, Convert.ToInt32(listItem["ID"]), projectNumber, dtExpiration, days);
                                    SendMail(email);
                                    logWrtr.WriteLine("Expired Communications email sent for Project ID '" + projectNumber + "'; Recipient(s): " + email.To);
                                    break;
                                }

                        }
                    }
                    else
                        errLogWrtr.WriteLine("No Submitter and / or Approving Manager assigned for Project ID '" + projectNumber + "'");
                }
            }
            catch (Exception ex)
            {
                errLogWrtr.WriteLine("Error Type: " + ex.GetType() + "; Message: " + ex.Message);
            }
            finally
            {
                // Cleanup
                context.Dispose();

                // Close log writers
                errLogWrtr.Close();
                logWrtr.Close();

                // Cleanup
                FileInfo fi = new FileInfo(logFile);
                if (fi.Length < 1)
                {
                    fi.Delete();
                }
                fi = new FileInfo(errLogFile);
                if (fi.Length < 1)
                {
                    fi.Delete();
                }

                // Historical log cleanup and archives
                LogFileCleanup(ConfigurationManager.AppSettings["LogPath"]);
                LogFileCleanup(ConfigurationManager.AppSettings["ErrorLogPath"]);
            }
        }

        private static string GetProjectNumber(ListItem listItem)
        {
            var icNumber = "";

            if (listItem["CNumber"] !=  null && listItem["CNumber"].ToString() != "")
            {
                icNumber = listItem["CNumber"].ToString();
            }
            else if (listItem["INumber"] != null && listItem["INumber"].ToString() != "")
            {
                icNumber = listItem["INumber"].ToString();
            }

            return icNumber;
        }

        private static ListItemCollection GetCPROListItems(MessageType type)
        {
            List projectList = context.Web.Lists.GetByTitle(ConfigurationManager.AppSettings["listName"]);

            bool ExcludeMigratedProjects = Boolean.Parse(ConfigurationManager.AppSettings["ExcludeMigratedProjects"]);
            string excludeMigProjCAMLQry = "";
            if (ExcludeMigratedProjects)
                excludeMigProjCAMLQry = "<Neq><FieldRef Name = 'Migrated' /><Value Type = 'Integer' >1</ Value></ Neq>";

            CamlQuery query = new CamlQuery();

            // Set query based on type of message
            switch (type)
            {
                case MessageType.DateOfFirstUseApproval:
                    if (ExcludeMigratedProjects)
                    { }
                    query.ViewXml =
                        @"<View>
                    <Query>
                      <Where>
                        <And>
                        <Eq>
                          <FieldRef Name='DateOfFirstUse' />
                          <Value IncludeTimeValue='FALSE' Type='DateTime'><Today /></Value>
                        </Eq>
                        <And>
                          <Neq>
                            <FieldRef Name='ApprovalStatus' />
                            <Value Type='Choice'>Submitted</Value>
                          </Neq>" + excludeMigProjCAMLQry +
                        @"</And>
                        </And>
                      </Where>
                    </Query>
                  </View>";
                    break;
                case MessageType.ExpiredProjectCommunications:
                    query.ViewXml =
                        @"<View>
                    <Query>
                      <Where>
                        <And>
                            <IsNotNull>
                               <FieldRef Name='DateOfFirstUse' />
                            </IsNotNull>
                            <And>
                            <Eq>
                              <FieldRef Name='ApprovalStatus' />
                              <Value Type='Choice'>Submitted</Value>
                            </Eq>" + excludeMigProjCAMLQry +
                            @"</And>
                          </And>
                        </Where>
                      </Query>
                  </View>";
                    break;
                default:
                    // You can use the default case.
                    //return "Invalid";
                    break;
            }

            ListItemCollection items = projectList.GetItems(query);
            context.Load(items);
            context.ExecuteQuery();

            return items;
        }

        private static string ReturnEmailHTML(MessageType type, int projId, string projectNumber, DateTime dtExpiration, int days)
        {
            StringBuilder mailContents = new StringBuilder();
            string mailbody = null;
            string projEditUrl = ConfigurationManager.AppSettings["siteURL"] + "/Lists/" +
                ConfigurationManager.AppSettings["listName"].Replace(" ", "%20") + "/Item/editifs.aspx?ID=" + projId.ToString();

            if (type == MessageType.DateOfFirstUseApproval)
            {
                mailContents.Append("<html><body><u><h3>Notification:</h3></u>");
                mailContents.Append("<table><tr><td width='500'>");
                mailContents.Append("<tr><td width='650'>");
                mailContents.Append(" Your material ");

                mailContents.Append("under Project Number:<b> " + projectNumber + "</b> is due for first use today.");

                mailContents.Append(" Please send notification to approver so that it can be approved for use.<br></br>");

                if (projId > 0)
                    mailContents.Append("<br>For details <a href=" + projEditUrl + ">click here</a><br>");


                mailContents.Append("</td></tr></table></body></html>");
                mailbody = mailContents.ToString();
            }
            else if (type == MessageType.ExpiredProjectCommunications)
            {
                mailContents.Append("<html><body><u><h3>Notification:</h3></u>");
                mailContents.Append("<table><tr><td width='500'>");
                mailContents.Append("<tr><td width='500'>");
                mailContents.Append(" Your approved material ");

                mailContents.Append("under Project Number:<b> " + projectNumber + "</b><br>");

                mailContents.Append(" will expire in ");
                mailContents.Append(days.ToString());   // changed by Renju,Oct 16 FR 5.1
                mailContents.Append(" days on ");

                mailContents.Append("<b>" + dtExpiration.ToShortDateString() + ".</b><br>");

                mailContents.Append(" If you would like to use this material past the expiration date, please update your material as soon as possible");

                if (projId > 0)
                    mailContents.Append("<br>For details <a href=" + projEditUrl + ">click here</a><br>");

                mailContents.Append("</td></tr></table></body></html>");
                mailbody = mailContents.ToString();
            }

            return mailbody;
        }

        private static void SendMail(Email email)
        {
            // Send email based on provided parameters
            var mailMessage = new MailMessage()
            {
                From = new MailAddress("SPNoReply@tiaa.org"),
                Body = email.HtmlBody,
                IsBodyHtml = true,
                Subject = email.Subject
            };

            mailMessage.To.Add(email.To);
            mailMessage.CC.Add(email.CC);

            var smtpClient = new SmtpClient();
            smtpClient.Host = ConfigurationManager.AppSettings["smtp"];
            smtpClient.Send(mailMessage);  
        }

        // Return timestamp for logs
        private static String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmm");
        }

        // Procedure to cleanup log files older than 7 days
        private static void LogFileCleanup(string logLocation)
        {
            string[] logs = Directory.GetFiles(logLocation);
            foreach (string log in logs)
            {
                FileInfo logFi = new FileInfo(log);
                if (logFi.CreationTime < DateTime.Now.AddDays(-7))
                    logFi.Delete();
            }
        }
    }
}
