﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Web.Configuration;
using System.Net;
using System.Net.Mail;
using System.IO;
using System.Xml;
using System.Xml.Linq;

namespace CPROWORMLibrary
{
    class Program
    {
        static string siteUrl = "";
         static string CproListTitle = "";
         static string WormLibrary="";
         static string WormHistoryList = "";
        static List wormLibrary;
        static void Main(string[] args)
        {
            //Read the Site Url and list titles from external XML file
            XmlDocument oXmlDoc = new XmlDocument();
            oXmlDoc.Load(@"SiteURLandListTitles.xml");
            XmlNodeList oXmlNodeList = oXmlDoc.SelectNodes("/siteUrls");
           foreach(XmlNode oXmlNode in oXmlNodeList)
           {
               siteUrl = oXmlNode.SelectSingleNode("SiteURL").InnerText;
               CproListTitle = oXmlNode.SelectSingleNode("CproList").InnerText;
               WormLibrary = oXmlNode.SelectSingleNode("WormLibrary").InnerText;
               WormHistoryList = oXmlNode.SelectSingleNode("CPROHistory").InnerText;
           }
          
            ClientContext context = new ClientContext(siteUrl);
            wormLibrary = context.Web.Lists.GetByTitle(WormLibrary);
            List wormHistoryList = context.Web.Lists.GetByTitle(WormHistoryList);
            //Delete all the existing Empty folders in "WORM LIBRARY"
            FolderCollection wormfolders = wormLibrary.RootFolder.Folders;
            context.Load(wormfolders);
            context.ExecuteQuery();
          
            for (int i = 0; i < wormfolders.Count; i++)
            {
                FileCollection oFIleColl = wormfolders[i].Files;
                context.Load(oFIleColl);
                context.ExecuteQuery();
                if (oFIleColl.Count == 0)
                {

                    wormfolders[i].DeleteObject();
                    context.ExecuteQuery();
                }
            }
            //Gets CPRO list items 
            ListItemCollection cproListItems = getCproListItems(context);
            //CPRO WORM Process History

            ListItemCreationInformation wormListInfo = new ListItemCreationInformation();
            ListItem objListHistoryItem = wormHistoryList.AddItem(wormListInfo);
            objListHistoryItem["Title"] = "Run Scheduler Job on " + System.DateTime.Now.ToShortDateString();
            objListHistoryItem["Start_x0020_DateTime"] = System.DateTime.Now;
            objListHistoryItem.Update();
            try
            {
                string strHistoryDescription = string.Empty;
                string CorINumber;
                bool isSuccess = false;
                foreach (ListItem cproitem in cproListItems)
                {
                    if (cproitem["CNumber"] != null)
                        CorINumber = cproitem["CNumber"].ToString();
                    else
                        CorINumber = cproitem["INumber"].ToString();

                    //Gets Files From "CPRO  Documents" library and copy to worm library
                    isSuccess = GetFiles(context, CorINumber, "Approved", cproitem);
                    strHistoryDescription += Environment.NewLine + "Moved Control # " + CorINumber + " -----" + Environment.NewLine;
                    if (isSuccess)
                    {
                        cproitem["Moved"] = "Yes";
                        objListHistoryItem["Result"] = "Success";
                        objListHistoryItem["End_x0020_DateTime"] = System.DateTime.Now;
                        if (string.IsNullOrEmpty(strHistoryDescription))
                        {
                            strHistoryDescription = "Executed job without moving any CPRO Items";
                        }
                        objListHistoryItem["Description"] = strHistoryDescription;
                        objListHistoryItem.Update();
                        cproitem.Update();
                        context.ExecuteQuery();
                    }
                }
            }
            catch(Exception ex)
            {
                objListHistoryItem["Result"] = "Failure";
                objListHistoryItem["Description"] = "ERROR: " + ex.Message + "<BR> STACK TRACE: " + ex.StackTrace.ToString();
                objListHistoryItem["End_x0020_DateTime"] = System.DateTime.Now;
                objListHistoryItem.Update();
                context.ExecuteQuery();
            }
            
        }

        private static ListItemCollection getCproListItems(ClientContext context)
        {
            ListItemCollection cproListItems=null;
            List cproList = context.Web.Lists.GetByTitle(CproListTitle);
            try
            {
              
                CamlQuery query = new CamlQuery();
                //CUrrently using AdvApprovalStatus as "on time" as  we don't have items with Submitted status upto now
                query.ViewXml =
                           @"<View>
                    <Query>
                     <Where>
                       <And>
                         <And>
                            <Eq>
                                <FieldRef Name='Moved' />
                                <Value Type='Text'>No</Value>
                            </Eq>
                            <Eq>
                                <FieldRef Name='ApprovalStatus' />
                                <Value Type='Choice'>Submitted</Value>
                             </Eq>
                        </And>
                            <Leq>
                                <FieldRef Name='ApprovalDate' />
                                <Value IncludeTimeValue='FALSE' Type='DateTime'><Today /></Value>
                           </Leq>
                        </And>
                         </Where>
                      </Query>
                  </View>";
                 cproListItems = cproList.GetItems(query);
                 context.Load(cproListItems);
                 context.ExecuteQuery();
            }
            catch (Exception ex)
            {
                Console.Write("Error " + ex.Message);
            }
            return cproListItems;
        }

        private static bool GetFiles(ClientContext context, string CorINumber, string p, ListItem cproitem)
        {
          
            Web web = context.Web;
            try
            {
         
                var getCurrentFolder = web.GetFolderByServerRelativeUrl("/Sites/CPRO/CPRO Documents/" + CorINumber + "/Approved");
                var getAllfiles = getCurrentFolder.Files;
                context.Load(getAllfiles);
                context.ExecuteQuery();

                //Creates folder in the Worm Library
                bool isFolderCreated = createDestFolder(context, CorINumber, cproitem);

                if (isFolderCreated)
                {
                    //Moves files to the WOrm Library
                    string folderLocation = "/Sites/CPRO/Worm Library/" + CorINumber + "/";
                    foreach (var file in getAllfiles)
                    {
                        file.CopyTo(folderLocation + file.Name, true);
                        context.ExecuteQuery();
                    }
                   
                    var getWormFolder = web.GetFolderByServerRelativeUrl("/Sites/CPRO/Worm Library/" + CorINumber);
                    var getWormfiles = getWormFolder.Files;
                    context.Load(getWormfiles);
                    context.ExecuteQuery();
                    foreach (var file in getWormfiles)
                    {
                        var item = file.ListItemAllFields;
                        item["ProjectName"] = cproitem["Title"];
                        if (cproitem["ApprovalDate"] != "" && cproitem["ApprovalDate"] !=null)
                        {
                            item["ApprovalDate"] = cproitem["ApprovalDate"];
                        }
                        if (cproitem["ExpirationDate"] != "" && cproitem["ExpirationDate"] != null)
                        {
                            item["ExpirationDate"] = cproitem["ExpirationDate"];
                        }
                        item["ApprovingManager"] = cproitem["ApprovingManager"];
                        item["BusinessEntity"] = cproitem["BusinessArea"];
                        item["ControlNumber"] = CorINumber;
                        if (cproitem["MaterialReference"] != null)
                        {
                            item["Product"] = cproitem["MaterialReference"];
                        }
                        else
                        {
                            item["Product"] = cproitem["MaterialReferenceOther"];
                        }

                        item.Update();
                        context.Load(item);
                        context.ExecuteQuery();
                    }

                }
            

                return true;
            }
            catch (Exception ex)
            {
                Console.Write("Error " + ex.Message);
            }
            return false;
        }

        private static bool createDestFolder(ClientContext context, string CorINumber, ListItem cproitem)
        {
            ListItem newItem=null;
            try
            {
                ListItemCreationInformation info = new ListItemCreationInformation();
                info.UnderlyingObjectType = FileSystemObjectType.Folder;
                info.LeafName = CorINumber.Trim();//Trim for spaces.Just extra check
                newItem = wormLibrary.AddItem(info);
                newItem["Title"] = CorINumber;
                newItem.Update();
                context.ExecuteQuery();
                return true;           
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex.Message);
            }
            return false;
        }

        
    }
}
