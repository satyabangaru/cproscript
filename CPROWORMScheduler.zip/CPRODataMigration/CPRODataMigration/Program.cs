﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CPRODataMigration.Utility;
using Microsoft.VisualBasic.FileIO;
using Microsoft.SharePoint.Client.Utilities;

namespace CPRODataMigration
{
    class Program
    {
        #region Field Constants
        const int CNUM = 3;
        const int INUM = 4;
        #endregion
        static ClientContext sourceContext;
        static ClientContext desContext;
        static StreamWriter outputWrtr;
        static StreamWriter stateFilingWrtr;
        static StreamWriter exceptionWrtr;
        static StreamWriter projectControlWrtr;
        static StreamWriter migrationLogWrtr;
        static ListItemCollection siteUsers;
        static string runType;
        static void Main(string[] args)
        {
            
             // Determine run type (either migrate or extract values)
            if (args.Length > 0)
                runType = args[0].ToUpper();

            if (runType == "EXTRACT")
            {
                sourceContext = new ClientContext(ConfigurationManager.AppSettings["sourceSiteURL"]);
                sourceContext.RequestTimeout = 600000;

                #region Main Project List
                Console.WriteLine("Main Project List Start");
                // Setup writers
                exceptionWrtr = new StreamWriter(ConfigurationManager.AppSettings["extractExceptionWrtrPath"]);
                outputWrtr = new StreamWriter(ConfigurationManager.AppSettings["outputProjWrtrPath"]);

                #region Main Project Header
                outputWrtr.WriteLine("ID," +
                     "CreationDate," +
                     "Project Name," +
                     "C Number," +
                     "I Number," +
                     "Submitter," +
                     "Acknowledge Details Submitted," +
                     "Additional Information," +
                     "Additional information before submittal," +
                     "Approval Comments," +
                     "Approval Date," +
                     "Approving Manager," +
                     "Attorney Name," +
                     "Audience," +
                     "Business Area," +
                     "isApproved," +
                     "CategoryOfMaterial," +
                     "ComplianceComment," +
                     "ComplianceReviewCompletedDate," +
                     "ComplianceReviewStatus," +
                     "CoordinatingReviewers," +
                     "CreateProjectStatus," +
                     "DateAssigned," +
                     "DateOfFirstUse," +
                     "DateSubmitted," +
                     "DateSubmittedToMRU," +
                     "DateCommentsReceivedFromLaw," +
                     "DateOfVerification," +
                     "DateSentToLaw," +
                     "DiscontinuedComments," +
                     "DateDiscontinued," +
                     "DocumentUploadedInDrafts," +
                     "EligibleForStreamlinedReview," +
                     "ExpirationDate," +
                     "ExpirationNotificationsRequired," +
                     "FINRARule," +
                     "FiledBy," +
                     "FilingDueDate," +
                     "FilingSubmittedOn," +
                     "FilingRequired," +
                     "FINRAFilingComment," +
                     "FINRAFilingStatus," +
                     "Location," +
                     "FromIntendedUsagePeriod," +
                     "IsPreviouslyApprovedBySME," +
                     "IsPreviouslyApproved," +
                     "DistributionMethod," +
                     "StateFilingsRequired," +
                     "DistributionGroupOtherSelected," +
                     "From," +
                     "Subject," +
                     "To," +
                     "AudienceOtherSelected," +
                     "NoFilingReasonsSelectedOther," +
                     "StateFilingsSelectedOther," +
                     "TypeOfMaterialOtherSelected," +
                     "InternalUseOnly," +
                     "IsRegisteredPrincipal," +
                     "ComplianceReviewComplete," +
                     "MaterialReference," +
                     "MaterialSentToApprover," +
                     "MaterialSubmittedIsWebContent," +
                     "Moved," +
                     "NewReview," +
                     "NoFilingReasons," +
                     "NoCommentsReceivedFromLaw," +
                     "PagesReviewed," +
                     "PerformanceVerification," +
                     "Preceded," +
                     "PreviousAttorneyName," +
                     "PreviousReviewDate," +
                     "PreviousSMEName," +
                     "ApprovalStatus," +
                     "ProjectInformationStatus," +
                     "DistributeMaterialOtherSelected," +
                     "ProjectDocumentLibraryName," +
                     "ReasonForChangeInExpirationDate," +
                     "FilingReplyDate," +
                     "ReplyStatus," +
                     "ReReview," +
                     "Reviewers," +
                     "ReviewersAssessmentOfMarketingMa," +
                     "RevisedExpirationDate," +
                     "RevisionRequired," +
                     "SectionNumber," +
                     "SMEPReviousReviewDate," +
                     "StateFiler," +
                     "StateFilingStatus," +
                     "SubmittedToLawForReview," +
                     "TIAACREFEntity," +
                     "ToIntendedUsage," +
                     "Turnaround," +
                     "FilingType," +
                     "TypeOfMaterial," +
                     "TypeOfProject," +
                     "TypeOfReview," +
                     "UnLockComments," +
                     "UnlockProject," +
                     "DistributionGroup," +
                     "OtherMaterialsIncluded," +
                     "CreatedBy," +
                     "ModifiedBy," +
                     "ProjectCNumber"
                );
                #endregion

                #region State Filing Header
                stateFilingWrtr = new StreamWriter(ConfigurationManager.AppSettings["stateFilingOutputWrtrPath"]);
                stateFilingWrtr.WriteLine("ID," +
                    "CNumber," +
                    "INumber," +
                     "StateAbbr," +
                     "Comments," +
                     "DateApproved," +
                     "DateFiled"
                );
                #endregion

                #region Project Control Header
                projectControlWrtr = new StreamWriter(ConfigurationManager.AppSettings["projectCtrlOutputWrtrPath"]);
                projectControlWrtr.WriteLine("ID," +
                     "Project Reference," +
                     "Is Create project Locked," +
                     "Is Project information Locked," +
                     "Is Compliance/Law review Locked," +
                     "Is Approval Locked," +
                     "Is FINRA filing Locked," +
                     "Is State Insurance Dept filing Locked ," +
                     "UnLock Request," +
                     "Month created," +
                     "Month," +
                     "Year,");
                #endregion

                // Project Control setup
                List projectControlList = sourceContext.Web.Lists.GetByTitle(ConfigurationManager.AppSettings["sourceProjControlListName"]);
                CamlQuery controlListQuery = new CamlQuery();

                // Load site users list for lookups
                LoadSiteUsers();

                // Filter list by 
                List projectList = sourceContext.Web.Lists.GetByTitle(ConfigurationManager.AppSettings["sourceProjListName"]);
                CamlQuery query = new CamlQuery();
                //query.ViewXml =
                //    @"<View><Query><Where><Geq><FieldRef Name='ID'/>" +
                //    "<Value Type='Number'>32845</Value></Geq></Where></Query><RowLimit>100</RowLimit></View>";
                //query.ViewXml =
                //    @"<View><Query><Where><Geq><FieldRef Name='Date'/>" +
                //    "<Value IncludeTimeValue='TRUE' Type='DateTime'>2016-01-01T15:55:52Z</Value></Geq><And><Leq><FieldRef Name='Date'/>" +
                //    "<Value IncludeTimeValue='TRUE' Type='DateTime'>2016-03-30T15:55:52Z</Value></Leq></And></Where></Query></View>";
                query.ViewXml =
                    @"<View><Query><Where><Leq><FieldRef Name='ID'/><Value Type='Number'>32845</Value></Leq></Where><OrderBy>" +
                    "<FieldRef Name='ID' Ascending='FALSE'/></OrderBy></Query><RowLimit>300</RowLimit></View>";
                //query.ViewXml =
                //    @"<View><Query><Where><Eq><FieldRef Name='ID'/>" +
                //    "<Value Type='Number'>32723</Value></Eq><Or><Eq><FieldRef Name='ID'/><Value Type='Number'>32618</Value></Eq></Or></Where></Query><RowLimit>100</RowLimit></View>";

                ListItemCollection items = projectList.GetItems(query);
                sourceContext.Load(items);
                sourceContext.ExecuteQuery();

                foreach (ListItem listItem in items)
                {
                    // Assign project identifier
                    bool projCtlRecFound = false;
                    string coriNumber = GetProjectIdentifier(listItem);
                    if (coriNumber != "")
                    {
                        #region Project Control
                        // Process Project Control Record per cnum/inum from Main List
                        // Need exception handling if Project Control Record not found
                        controlListQuery.ViewXml =
                            @"<View><Query><Where><Eq><FieldRef Name='Title'/><Value Type='Text'>" + coriNumber + "</Value></Eq></Where></Query></View>";
                        ListItemCollection projectControlItems = projectControlList.GetItems(controlListQuery);
                        sourceContext.Load(projectControlItems);
                        sourceContext.ExecuteQuery();
                        foreach (ListItem projectControlItem in projectControlItems)
                        {
                            projectControlWrtr.WriteLine("\"" + projectControlItem["ID"] + "\"," +
                                   "\"" + projectControlItem["Title"] + "\"," +
                                   "\"" + projectControlItem["IsCreateProjectLocked"] + "\"," +
                                   "\"" + projectControlItem["IsProjectInformationLocked"] + "\"," +
                                   "\"" + projectControlItem["IsComplianceReviewLocked"] + "\"," +
                                   "\"" + projectControlItem["IsApprovalLocked"] + "\"," +
                                   "\"" + projectControlItem["IsFINRALocked"] + "\"," +
                                   "\"" + projectControlItem["IsStateFilingLocked"] + "\"," +
                                   "\"" + projectControlItem["UnLockRequest"] + "\"," +
                                   "\"" + projectControlItem["Month_x0020_created"] + "\"," +
                                   "\"" + projectControlItem["Month"] + "\"," +
                                   "\"" + projectControlItem["Year"] + "\"");
                            projCtlRecFound = true;
                            Console.WriteLine(projectControlItem["Title"]);
                        }
                        #endregion

                        if (projCtlRecFound)
                        {
                            #region Main Project Lookups
                            // Lookup account name from people picker, assumption is single value
                            string acctNameWriter = "";
                            if (listItem["Writer"] != null)
                            {
                                acctNameWriter = GetUserAcctName(listItem, "Writer");
                            }

                            // Lookup account name
                            string acctNameApprMgr = "";
                            if (listItem["ApprovingManager"] != null)
                            {
                                acctNameApprMgr = GetUserAcctName(listItem, "ApprovingManager");
                            }

                            string audience = listItem["Audience"] != null ? GetLookupValues(listItem, "Audience") : "";
                            string businessArea = listItem["BusinessArea"] != null ? GetLookupValues(listItem, "BusinessArea") : "";

                            // 
                            string categoryOfMaterial = "";
                            if (listItem["CategoryOfMaterial"] != null)
                            {
                                categoryOfMaterial = GetLookupValues(listItem, "CategoryOfMaterial");
                            }

                            // Choice field logic, comes across as string array so grab 1st item
                            string filingRequired = "";
                            if (listItem["FilingRequired"] != null)
                            {
                                //filingRequired = ((string[])listItem["FilingRequired"])[0];
                                filingRequired = GetStringCollValues(listItem, "FilingRequired");
                                
                            }

                            //
                            string coordinatingReviewers = "";
                            if (listItem["CoordinatingReviewers"] != null)
                            {
                                coordinatingReviewers = GetUserAcctName(listItem, "CoordinatingReviewers");
                            }

                            // Lookup filed by
                            string filedBy = "";
                            if (listItem["FiledBy"] != null)
                            {
                                filedBy = GetUserAcctName(listItem, "FiledBy");
                            }

                            // 
                            string forUseIn = "";
                            if (listItem["Location"] != null)
                            {
                                forUseIn = GetLookupValues(listItem, "Location");
                            }

                            // 
                            string distributionMethod = "";
                            if (listItem["DistributionMethod"] != null)
                            {
                                distributionMethod = GetLookupValues(listItem, "DistributionMethod");
                            }

                            //
                            string materialReference = "";
                            if (listItem["MaterialReference"] != null)
                            {
                                materialReference = GetLookupValues(listItem, "MaterialReference");
                            }

                            string noFilingReasons = "";
                            if (listItem["NoFilingReasons"] != null)
                            {
                                noFilingReasons = GetLookupValues(listItem, "NoFilingReasons");
                            }

                            string stateFilingsRequired = "";
                            if (listItem["StateFilingsRequired"] != null)
                            {
                                stateFilingsRequired = GetLookupValues(listItem, "StateFilingsRequired");
                            }

                            string reviewers = "";
                            if (listItem["Reviewers"] != null)
                            {
                                reviewers = GetUserAcctName(listItem, "Reviewers");
                            }

                            string stateFiler = "";
                            if (listItem["StateFiler"] != null)
                            {
                                stateFiler = GetUserAcctName(listItem, "StateFiler");
                            }

                            string tiaaCREFEntity = "";
                            if (listItem["TIAA_x002d_CREFEntity"] != null)
                            {
                                // cb (10/6/16) - Updated to replace invalid dash character
                                tiaaCREFEntity = GetLookupValues(listItem, "TIAA_x002d_CREFEntity");
                                tiaaCREFEntity = tiaaCREFEntity.Replace("–", "-");
                            }

                            string typeOfMaterial = "";
                            if (listItem["TypeOfMaterial"] != null)
                            {
                                typeOfMaterial = GetLookupValues(listItem, "TypeOfMaterial");
                            }

                            string distributionGroup = "";
                            if (listItem["DistributionGroup"] != null)
                            {
                                distributionGroup = GetLookupValues(listItem, "DistributionGroup");
                            }

                            string createdBy = "";
                            if (listItem["Author"] != null)
                            {
                                createdBy = GetUserAcctName(listItem, "Author");
                            }

                            string modifiedBy = "";
                            if (listItem["Editor"] != null)
                            {
                                modifiedBy = GetUserAcctName(listItem, "Editor");
                            }

                            // Added to handle double quotes inside of field
                            string complianceComment = "";
                            if (listItem["ComplianceComment"] != null)
                            {
                                complianceComment = listItem["ComplianceComment"].ToString().Replace("\"", "\"\"");
                            }

                            // cb (10/7/16) - Check for invalid dashes and replace in reviewer feedback
                            string reviewersAssessmentOfMarketingMa = "";
                            if (listItem["ReviewersAssessmentOfMarketingMa"] != null)
                            {
                                reviewersAssessmentOfMarketingMa = listItem["ReviewersAssessmentOfMarketingMa"].ToString().Replace("–", "-");
                            }
                            #endregion

                            #region Main Project Detail Row
                            outputWrtr.WriteLine("\"" + listItem["ID"] + "\"," +
                                "\"" + listItem["Date"] + "\"," +
                                "\"" + listItem["Title"] + "\"," + // Project Name
                                "\"" + listItem["CNumber"] + "\"," +
                                "\"" + listItem["INumber"] + "\"," +
                                "\"" + acctNameWriter + "\"," +
                                "\"" + listItem["AcknowledgeDetailsSubmitted"] + "\"," +
                                "\"" + listItem["AdditionalInformation"] + "\"," +
                                "\"" + listItem["StateAdditionalInfo"] + "\"," +
                                "\"" + listItem["ApprovalComments"] + "\"," +
                                "\"" + listItem["ApprovalDate"] + "\"," +
                                "\"" + acctNameApprMgr + "\"," +
                                "\"" + listItem["AttorneyName"] + "\"," +
                                "\"" + audience + "\"," +
                                "\"" + businessArea + "\"," +
                                "\"" + listItem["isApproved"] + "\"," +
                                "\"" + categoryOfMaterial + "\"," +
                                "\"" + complianceComment + "\"," +
                                "\"" + listItem["ComplianceReviewCompletedDate"] + "\"," +
                                "\"" + listItem["ComplianceReviewStatus"] + "\"," +
                                "\"" + coordinatingReviewers + "\"," +
                                "\"" + listItem["CreateProjectStatus"] + "\"," +
                                "\"" + listItem["DateAssigned"] + "\"," +
                                "\"" + listItem["DateOfFirstUse"] + "\"," +
                                "\"" + listItem["DateSubmitted"] + "\"," +
                                "\"" + listItem["Date_x0020_Submitted_x0020_to_x0"] + "\"," +
                                "\"" + listItem["DateCommentsReceivedFromLaw"] + "\"," +
                                "\"" + listItem["DateOfVerification"] + "\"," +
                                "\"" + listItem["DateSentToLaw"] + "\"," +
                                "\"" + listItem["DiscontinuedComments"] + "\"," +
                                "\"" + listItem["DateDiscontinued"] + "\"," +
                                "\"" + listItem["DocumentUploadedInDrafts"] + "\"," +
                                "\"" + listItem["EligibleForStreamlinedReview"] + "\"," +
                                "\"" + listItem["ExpirationDate"] + "\"," +
                                "\"" + listItem["ExpirationNotificationsRequired"] + "\"," +
                                "\"" + listItem["FINRARule"] + "\"," +
                                "\"" + filedBy + "\"," +
                                "\"" + listItem["FilingDueDate"] + "\"," +
                                "\"" + listItem["FilingSubmittedOn"] + "\"," +
                                "\"" + filingRequired + "\"," +
                                "\"" + listItem["FINFRAFilingComment"] + "\"," +
                                "\"" + listItem["FINRAFilingStatus"] + "\"," +
                                "\"" + forUseIn + "\"," +
                                "\"" + listItem["From_x0020_Intended_x0020_Usage_"] + "\"," +
                                "\"" + listItem["IsPreviouslyApprovedBySME"] + "\"," +
                                "\"" + listItem["IsPreviouslyApproved"] + "\"," +
                                "\"" + distributionMethod + "\"," +
                                "\"" + stateFilingsRequired + "\"," +
                                "\"" + listItem["DistributionGroupOtherSelected"] + "\"," +
                                "\"" + listItem["From"] + "\"," +
                                "\"" + listItem["Subject"] + "\"," +
                                "\"" + listItem["To"] + "\"," +
                                "\"" + listItem["AudienceOtherSelected"] + "\"," +
                                "\"" + listItem["NoFilingReasonsSelectedOther"] + "\"," +
                                "\"" + listItem["StateFilingsSelectedOther"] + "\"," +
                                "\"" + listItem["TypeOfMaterialOtherSelected"] + "\"," +
                                "\"" + listItem["InternalUseOnly"] + "\"," +
                                "\"" + listItem["IsRegisteredPrincipal"] + "\"," +
                                "\"" + listItem["ComplianceReviewComplete"] + "\"," +
                                "\"" + materialReference + "\"," +
                                "\"" + listItem["MaterialSentToApprover"] + "\"," +
                                "\"" + listItem["MaterialSubmittedIsWebContent"] + "\"," +
                                "\"" + listItem["Moved"] + "\"," +
                                "\"" + listItem["NewReview"] + "\"," +
                                "\"" + noFilingReasons + "\"," +
                                "\"" + listItem["NoCommentsReceivedFromLaw"] + "\"," +
                                "\"" + listItem["PagesReviewed"] + "\"," +
                                "\"" + listItem["PerformanceVerification"] + "\"," +
                                "\"" + listItem["Preceded"] + "\"," +
                                "\"" + listItem["PreviousAttorneyName"] + "\"," +
                                "\"" + listItem["PreviousReviewDate"] + "\"," +
                                "\"" + listItem["PreviousSMEName"] + "\"," +
                                "\"" + listItem["ApprovalStatus"] + "\"," +
                                "\"" + listItem["ProjectInformationStatus"] + "\"," +
                                "\"" + listItem["DistributeMaterialOtherSelected"] + "\"," +
                                "\"" + listItem["ProjectDocumentLibraryName"] + "\"," +
                                "\"" + listItem["ReasonForChangeInExpirationDate"] + "\"," +
                                "\"" + listItem["FilingReplyDate"] + "\"," +
                                "\"" + listItem["ReplyStatus"] + "\"," +
                                "\"" + listItem["Re_x002d_Review"] + "\"," +
                                "\"" + reviewers + "\"," +
                                "\"" + reviewersAssessmentOfMarketingMa + "\"," +                           
                                "\"" + listItem["RevisedExpirationDate"] + "\"," +
                                "\"" + listItem["RevisionRequired"] + "\"," +
                                "\"" + listItem["SectionNumber"] + "\"," +
                                "\"" + listItem["SMEPReviousReviewDate"] + "\"," +
                                "\"" + stateFiler + "\"," +
                                "\"" + listItem["StateFilingStatus"] + "\"," +
                                "\"" + listItem["SubmittedToLawForReview"] + "\"," +
                                "\"" + tiaaCREFEntity + "\"," +
                                "\"" + listItem["To_x0020_Intended_x0020_Usage_x0"] + "\"," +
                                "\"" + listItem["Turnaround"] + "\"," +
                                "\"" + listItem["FilingType"] + "\"," +
                                "\"" + typeOfMaterial + "\"," +
                                "\"" + listItem["TypeOfProject"] + "\"," +
                                "\"" + listItem["TypeOfReview"] + "\"," +
                                "\"" + listItem["UnLockComments"] + "\"," +
                                "\"" + listItem["UnlockProject"] + "\"," +
                                "\"" + distributionGroup + "\"," +
                                "\"" + listItem["OtherMaterialsIncluded"] + "\"," +
                                "\"" + createdBy + "\"," +
                                "\"" + modifiedBy + "\"," +
                                "\"" + listItem["ProjectCNumber"] + "\""
                                );
                            #endregion

                            if (stateFilingsRequired != "")
                            {
                                // Logic to write state filing based on delimited state listing from 2010 list
                                #region State Filing
                                // State filing transform, build array to handle transform of state filing columns into rows
                                ArrayList stateFilings = new ArrayList();
                                string[] filingStates = stateFilingsRequired.Split(new Char[] { '|' });
                                foreach (string filingState in filingStates)
                                {
                                    FilingState sf = new FilingState();

                                    // Need NULL check
                                    switch (filingState)
                                    {
                                        case "NC":
                                            sf.Abbreviation = Abbreviation.NC;
                                            sf.Comments = listItem["NorthCarolinaComments"] != null ? listItem["NorthCarolinaComments"].ToString() : "";
                                            if (listItem["NorthCarolinaDateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["NorthCarolinaDateApproved"];
                                            }
                                            if (listItem["NorthCarolinaDateFiled"] != null)
                                            {
                                                sf.DateFiled = (DateTime)listItem["NorthCarolinaDateFiled"];
                                            }
                                            break;
                                        case "GA":
                                            sf.Abbreviation = Abbreviation.GA;
                                            sf.Comments = listItem["GeorgiaComments"] != null ? listItem["GeorgiaComments"].ToString() : "";
                                            if (listItem["GeorgiaDateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["GeorgiaDateApproved"];
                                            }
                                            if (listItem["GeorgiaDateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["GeorgiaDateFiled"];
                                            }
                                            break;
                                        case "OR":
                                            sf.Abbreviation = Abbreviation.OR;
                                            sf.Comments = listItem["OregonComments"] != null ? listItem["OregonComments"].ToString() : "";
                                            if (listItem["OregonDateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["OregonDateApproved"];
                                            }
                                            if (listItem["OregonDateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["OregonDateFiled"];
                                            }
                                            break;
                                        case "CA":
                                            sf.Abbreviation = Abbreviation.CA;
                                            sf.Comments = listItem["CaliforniaComments"] != null ? listItem["CaliforniaComments"].ToString() : "";
                                            if (listItem["CaliforniaDateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["CaliforniaDateApproved"];
                                            }
                                            if (listItem["CaliforniaDateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["CaliforniaDateFiled"];
                                            }
                                            break;
                                        case "MI":
                                            sf.Abbreviation = Abbreviation.MI;
                                            sf.Comments = listItem["MichiganComments"] != null ? listItem["MichiganComments"].ToString() : "";
                                            if (listItem["MichiganDateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["MichiganDateApproved"];
                                            }
                                            if (listItem["MichiganDateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["MichiganDateFiled"];
                                            }
                                            break;
                                        case "CT":
                                            sf.Abbreviation = Abbreviation.CT;
                                            sf.Comments = listItem["ConnecticutComments"] != null ? listItem["ConnecticutComments"].ToString() : "";
                                            if (listItem["ConnecticutDateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["ConnecticutDateApproved"];
                                            }
                                            if (listItem["ConnecticutDateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["ConnecticutDateFiled"];
                                            }
                                            break;
                                        case "MD":
                                            sf.Abbreviation = Abbreviation.MD;
                                            sf.Comments = listItem["MarylandComments"] != null ? listItem["MarylandComments"].ToString() : "";
                                            if (listItem["MarylandDateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["MarylandDateApproved"];
                                            }
                                            if (listItem["MarylandDateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["MarylandDateFiled"];
                                            }
                                            break;
                                        case "MN":
                                            sf.Abbreviation = Abbreviation.MN;
                                            sf.Comments = listItem["MinnesotaComments"] != null ? listItem["MinnesotaComments"].ToString() : "";
                                            if (listItem["MinnesotaDateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["MinnesotaDateApproved"];
                                            }
                                            if (listItem["MinnesotaDateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["MinnesotaDateFiled"];
                                            }
                                            break;
                                        case "MS":
                                            sf.Abbreviation = Abbreviation.MS;
                                            sf.Comments = listItem["MississippiComments"] != null ? listItem["MississippiComments"].ToString() : "";
                                            if (listItem["MississippiDateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["MississippiDateApproved"];
                                            }
                                            if (listItem["MississippiDateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["MississippiDateFiled"];
                                            }
                                            break;
                                        case "NV":
                                            sf.Abbreviation = Abbreviation.NV;
                                            sf.Comments = listItem["NevadaComments"] != null ? listItem["NevadaComments"].ToString() : "";
                                            if (listItem["NevadaDateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["NevadaDateApproved"];
                                            }
                                            if (listItem["NevadaDateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["NevadaDateFiled"];
                                            }
                                            break;
                                        case "OK":
                                            sf.Abbreviation = Abbreviation.OK;
                                            sf.Comments = listItem["OklahomaComments"] != null ? listItem["OklahomaComments"].ToString() : "";
                                            if (listItem["OklahomaDateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["OklahomaDateApproved"];
                                            }
                                            if (listItem["OklahomaDateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["OklahomaDateFiled"];
                                            }
                                            break;
                                        case "WV":
                                            sf.Abbreviation = Abbreviation.WV;
                                            sf.Comments = listItem["WestVirginiaComments"] != null ? listItem["WestVirginiaComments"].ToString() : "";
                                            if (listItem["WestVirginiaDateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["WestVirginiaDateApproved"];
                                            }
                                            if (listItem["WestVirginiaDateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["WestVirginiaDateFiled"];
                                            }
                                            break;
                                        case "Other 1":
                                            sf.Abbreviation = Abbreviation.other1;
                                            sf.Comments = listItem["Other1Comments"] != null ? listItem["Other1Comments"].ToString() : "";
                                            if (listItem["Other1DateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["Other1DateApproved"];
                                            }
                                            if (listItem["Other1DateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["Other1DateFiled"];
                                            }
                                            break;
                                        case "Other 2":
                                            sf.Abbreviation = Abbreviation.other2;
                                            sf.Comments = listItem["Other2Comments"] != null ? listItem["Other2Comments"].ToString() : "";
                                            if (listItem["Other2DateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["Other2DateApproved"];
                                            }
                                            if (listItem["Other2DateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["Other2DateFiled"];
                                            }
                                            break;
                                        case "Other 3":
                                            sf.Abbreviation = Abbreviation.other3;
                                            sf.Comments = listItem["Other3Comments"] != null ? listItem["Other3Comments"].ToString() : "";
                                            if (listItem["Other3DateApproved"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["Other3DateApproved"];
                                            }
                                            if (listItem["Other3DateFiled"] != null)
                                            {
                                                sf.DateApproved = (DateTime)listItem["Other3DateFiled"];
                                            }
                                            break;

                                    }

                                    //Console.WriteLine(filingState);

                                    stateFilingWrtr.WriteLine("\"" + listItem["ID"] + "\"," +
                                         "\"" + listItem["CNumber"] + "\"," +
                                        "\"" + listItem["INumber"] + "\"," +
                                        "\"" + sf.Abbreviation.ToString() + "\"," +
                                        "\"" + sf.Comments + "\"," +
                                        "\"" + sf.DateApproved.ToShortDateString() + "\"," +
                                        "\"" + sf.DateFiled.ToShortDateString() + "\""
                                    );
                                }
                                Console.WriteLine(stateFilingsRequired);
                                #endregion

                            }
                        }
                        else
                        {
                            exceptionWrtr.WriteLine("No Project Control Record Found; SharePoint List Item ID: " + listItem["ID"].ToString());
                        }

                        Console.WriteLine(listItem["ID"]);
                    }
                    else
                    {
                        // Log exception for missing project identifier
                        exceptionWrtr.WriteLine("Missing C or I Number; SharePoint List Item ID: " + listItem["ID"].ToString());
                    }
                }

                outputWrtr.Close();
                projectControlWrtr.Close();
                stateFilingWrtr.Close();
                Console.WriteLine("Main Project List Exported");
                #endregion

                

                exceptionWrtr.Close();
           }
           else if (runType == "MIGRATE")
           {
                migrationLogWrtr = new StreamWriter(ConfigurationManager.AppSettings["migrateLogPath"]); 
                exceptionWrtr = new StreamWriter(ConfigurationManager.AppSettings["migrateExceptionWrtrPath"]);
                Migrate2013();
                migrationLogWrtr.Close();
                exceptionWrtr.Close();
           }
        }
        #region sring collection Values
        private static string GetStringCollValues(ListItem listItem, string fieldName)
        {
            try
            {
                // Check for multi-value
                string[] flv = (string[])listItem[fieldName];
                return GetStringValues(flv);
            }
            catch (InvalidCastException ex)
            {
                // Handle single value
                string flv = (string)listItem[fieldName];
                return GetStringValues(flv);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        static string GetStringValues(string flv)
        {
            return flv.ToString(); ;
        }

        static string GetStringValues(string[] flv)
        {
            string stringValues = "";

            foreach (string f in flv)
            {
                stringValues += f.ToString() + "; ";
            }

            return stringValues.Length > 0 ? stringValues.Remove(stringValues.Length - 2, 2) : String.Empty;
        }
        #endregion

        // Check if Project Exists
        static bool DoesProjectExist (List list, ClientContext context, string cOrI, string projIdentifier)
        {
            CamlQuery query = new CamlQuery();
            if (cOrI == "C")
                query.ViewXml =
                    @"<View><Query><Where><Eq><FieldRef Name='CNumber'/><Value Type='Text'>" + projIdentifier + "</Value></Eq></Where></Query></View>";
            else if (cOrI == "I")
                query.ViewXml =
                    @"<View><Query><Where><Eq><FieldRef Name='INumber'/><Value Type='Text'>" + projIdentifier + "</Value></Eq></Where></Query></View>";

            ListItemCollection items = list.GetItems(query);
            context.Load(items);
            context.ExecuteQuery();

            if (items.Count > 0)
                return true;
            else
                return false;
        }
        // Function to write CSV outputs to new 2013 list and document library structures
        static string GetProjectIdentifier (ListItem li)
        {
            string projId = "";
            if (li["CNumber"] != null && li["CNumber"].ToString() != "")
            {
                projId = li["CNumber"].ToString();
            }
            else if(li["INumber"] != null && li["INumber"].ToString() != "")
            {
                projId = li["INumber"].ToString();
            }

            return projId;
        }

        static void Migrate2013 ()
        {
            string[] currentRow;
            string coriNumber="";
            bool isSuccess = false;
            UserFieldValues oUFV;
            bool addDocs = false; // Testing switch for file transfers
            bool isProjCtrlSuccess = false;
            bool isStateFIlingSuccess = false;
            sourceContext = new ClientContext(ConfigurationManager.AppSettings["sourceSiteURL"]);
            desContext = new ClientContext(ConfigurationManager.AppSettings["destSiteURL"]);
            desContext.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["ImpersUser"],
                ConfigurationManager.AppSettings["ImpersPssd"], ConfigurationManager.AppSettings["ImpersDomain"]);

            using (TextFieldParser inputProjReader = new TextFieldParser(ConfigurationManager.AppSettings["inputProjWrtrPath"]))
            {
                inputProjReader.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited;
                inputProjReader.HasFieldsEnclosedInQuotes = true;
                inputProjReader.TrimWhiteSpace = false;
                inputProjReader.SetDelimiters(",");
                List newProjList = desContext.Web.Lists.GetByTitle(ConfigurationManager.AppSettings["destProjListName"]);
                currentRow = inputProjReader.ReadFields(); // Skip header
                while (!inputProjReader.EndOfData)
                {
                    try
                    {
                        oUFV = new UserFieldValues();
                        currentRow = inputProjReader.ReadFields();
                        bool projExists = false;
                        bool projChkOverride = false;
                        string projIdentifier = "";
                        // cb (10/3/16) - Verify project record does not exist yet in destination library
                        if (currentRow[CNUM] != null && currentRow[CNUM] != "")
                        {
                            projIdentifier = currentRow[CNUM];
                            projExists = DoesProjectExist(newProjList, desContext, "C", projIdentifier);
                        }
                        else if (currentRow[INUM] != null && currentRow[INUM] != "")
                        {
                            projIdentifier = currentRow[INUM];
                            projExists = DoesProjectExist(newProjList, desContext, "I", projIdentifier);
                        }
                        if (!projExists || projChkOverride)
                        {
                            //Get AD users
                            GetValidADUsers(currentRow, oUFV, desContext);
                            ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                            desContext.Load(newProjList);
                            desContext.ExecuteQuery();
                            ListItem newItem = newProjList.AddItem(itemCreateInfo);
                            //Function to insert data into CPRO 2013 list
                           isSuccess = InsertDataintoCPROList(currentRow, newItem, desContext, oUFV);
                            if (isSuccess)
                            {
                                coriNumber = GetProjectIdentifier(newItem);
                                migrationLogWrtr.WriteLine("Project " + coriNumber + " inserted into main 2013 CPRO list.");
                                //Create record in the CPRO control list 2013 for corresponding CNUmber/Inumber
                                isProjCtrlSuccess = InsertDataintoControlList(coriNumber, desContext);
                                migrationLogWrtr.WriteLine("Project " + coriNumber + " inserted into project control 2013 CPRO list.");
                                //Create record in the CPRO Statefiling list 2013 for corresponding CNUmber/Inumber
                                isStateFIlingSuccess = InsertDataintoSFList(coriNumber, desContext);
                                migrationLogWrtr.WriteLine("Project " + coriNumber + " inserted into state filing 2013 CPRO list.");
                                //Create Folders in CPRO document library 2013
                                addDocs = CreateFoldersinLibrary(newItem, desContext, coriNumber);
                                string libraryName2010 = GetDocumentLibraryName(coriNumber,sourceContext);
                                bool processFiles = true;

                                //Still Working
                                //if (isProjCtrlSuccess && addDocs && libraryName2010!=null)
                                if (processFiles)
                                {
                                    Web souweb = sourceContext.Web;
                                    Web desweb = desContext.Web;
                                    //Get Aprroved documents from CPRO 2010 library and move 2013
                                    #region Copying Documents
                                    try
                                    {
                                        var getApprovCurrFol = souweb.GetFolderByServerRelativeUrl("/ao/cpro/" + libraryName2010 + "/" + coriNumber + "/Approved/Documents");
                                        var getapprovAllfiles = getApprovCurrFol.Files;
                                        sourceContext.Load(getapprovAllfiles);
                                        sourceContext.ExecuteQuery();
                                        if (sourceContext.HasPendingRequest)
                                            sourceContext.ExecuteQuery();
                                        var folderApprovedLocation = "/Sites/CPRO/CPRO Documents/" + coriNumber + "/Approved";
                                        if (getapprovAllfiles.Count > 0)
                                        {
                                            foreach (var file in getapprovAllfiles)
                                            {

                                                FileInformation fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(sourceContext, file.ServerRelativeUrl);
                                                Microsoft.SharePoint.Client.File.SaveBinaryDirect(desContext, folderApprovedLocation + "/" + file.Name, fileInfo.Stream, true);
                                                migrationLogWrtr.WriteLine("Project " + coriNumber + " 'approved' document '" + file.Name + "' migrated into 2013 CPRO document library.");
                                                desContext.ExecuteQuery();
                                            }
                                            // cb (10/4/16) - Update Approved documents Metadata
                                          
                                                UpdateMetadataofFiles(desContext, newItem, coriNumber, folderApprovedLocation, "Approved");
                                         
                                        }
                                        
                                       
                                    }
                                    catch (Exception ex)
                                    {
                                        exceptionWrtr.WriteLine("Error Migrating Approved Files; Project ID: " + coriNumber + "; Message: " + ex.Message + "Exception Type: " + ex.GetType().ToString());
                                    }
                                    // Chaitu (10/4/16) - Get Aprroved Communications documents from CPRO 2010 library and move 2013

                                    try
                                    {                                        
                                        var getApprovCurrFol = souweb.GetFolderByServerRelativeUrl("/ao/cpro/" + libraryName2010 + "/" + coriNumber + "/Approved/Communications");
                                        var getapprovAllcommfiles = getApprovCurrFol.Files;
                                        sourceContext.Load(getapprovAllcommfiles);
                                        sourceContext.ExecuteQuery();
                                        if (sourceContext.HasPendingRequest)
                                            sourceContext.ExecuteQuery();
                                        // Chaitu (10/5/16) - Creates Communications folder under Approved folder
                                        if (getapprovAllcommfiles.Count > 0)
                                        {
                                            var getApprovCurrFolcomm = desweb.GetFolderByServerRelativeUrl("/Sites/CPRO/CPRO Documents/" + coriNumber + "/Approved");
                                            desContext.Load(getApprovCurrFolcomm);
                                            desContext.ExecuteQuery();
                                            getApprovCurrFolcomm.Folders.Add("Communications");
                                            desContext.ExecuteQuery();
                                            var folderApprovedLocation = "/Sites/CPRO/CPRO Documents/" + coriNumber + "/Approved/Communications";
                                            foreach (var file in getapprovAllcommfiles)
                                            {

                                                FileInformation fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(sourceContext, file.ServerRelativeUrl);
                                                Microsoft.SharePoint.Client.File.SaveBinaryDirect(desContext, folderApprovedLocation + "/" + file.Name, fileInfo.Stream, true);
                                                migrationLogWrtr.WriteLine("Project " + coriNumber + " 'approved' document '" + file.Name + "' migrated into 2013 CPRO document library.");
                                                desContext.ExecuteQuery();
                                            }
                                            // cb (10/4/16) - Update Approved Communications documents Metadata
                                            UpdateMetadataofFiles(desContext, newItem, coriNumber, folderApprovedLocation, "Approved");
                                        }
                                       
                                    }
                                    // cb (10/4/16) - Ignore if comms folder does not exist
                                    catch (Microsoft.SharePoint.Client.ServerException fnfEx)
                                    {
                                        if (fnfEx.ServerErrorTypeName != "System.IO.FileNotFoundException")
                                            exceptionWrtr.WriteLine("Error Migrating Approved Files; Project ID: " + coriNumber + "; Message: " + fnfEx.Message + "Exception Type: " + fnfEx.GetType().ToString());
                                    }
                                    catch (Exception ex)
                                    {
                                        exceptionWrtr.WriteLine("Error Migrating Approved Files; Project ID: " + coriNumber + "; Message: " + ex.Message + "Exception Type: " + ex.GetType().ToString());
                                    }
                                    //Get Draft documents from CPRO 2010 library and move 2013
                                    try
                                    {
                                        var getDraftCurrFol = souweb.GetFolderByServerRelativeUrl("/ao/cpro/" + libraryName2010 + "/" + coriNumber + "/Draft/Documents");
                                        var getDraftAllfiles = getDraftCurrFol.Files;
                                        sourceContext.Load(getDraftAllfiles);
                                        sourceContext.ExecuteQuery();
                                        string folderDraftLocation = "/Sites/CPRO/CPRO Documents/" + coriNumber + "/Draft";
                                        if (sourceContext.HasPendingRequest)
                                            sourceContext.ExecuteQuery();
                                        if (getDraftAllfiles.Count > 0)
                                        {
                                            foreach (var file in getDraftAllfiles)
                                            {
                                                var fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(sourceContext, file.ServerRelativeUrl);
                                                Microsoft.SharePoint.Client.File.SaveBinaryDirect(desContext, folderDraftLocation + "/" + file.Name, fileInfo.Stream, true);
                                                migrationLogWrtr.WriteLine("Project " + coriNumber + " 'draft' document '" + file.Name + "' migrated into 2013 CPRO document library.");
                                                desContext.ExecuteQuery();
                                            }
                                            // cb (10/4/16) - Update Draft documents Metadata
                                            UpdateMetadataofFiles(desContext, newItem, coriNumber, folderDraftLocation, "Draft");
                                        }
                                       
                                    }
                                    catch (Exception ex)
                                    {
                                        exceptionWrtr.WriteLine("Error Migrating Draft Files; Project ID: " + coriNumber + "; Message: " + ex.Message + "Exception Type: " + ex.GetType().ToString());
                                    }

                                    // Chaitu (10/4/16) - Get Draft Communications documents from CPRO 2010 library and move 2013
                                    try
                                    {
                                        var getDraftCurrFol = souweb.GetFolderByServerRelativeUrl("/ao/cpro/" + libraryName2010 + "/" + coriNumber + "/Draft/Communications");
                                        var getDraftAllfiles = getDraftCurrFol.Files;
                                        sourceContext.Load(getDraftAllfiles);
                                        sourceContext.ExecuteQuery();
                                        if (sourceContext.HasPendingRequest)
                                            sourceContext.ExecuteQuery();
                                        // Chaitu (10/5/16) - Creates Communications folder under Draft folder
                                        if (getDraftAllfiles.Count > 0)
                                        {
                                            var getDraftCurrFolcomm = desweb.GetFolderByServerRelativeUrl("/Sites/CPRO/CPRO Documents/" + coriNumber + "/Draft");
                                            desContext.Load(getDraftCurrFolcomm);
                                            desContext.ExecuteQuery();
                                            getDraftCurrFolcomm.Folders.Add("Communications");
                                            desContext.ExecuteQuery();
                                            string folderDraftLocation = "/Sites/CPRO/CPRO Documents/" + coriNumber + "/Draft/Communications";
                                            foreach (var file in getDraftAllfiles)
                                            {
                                                var fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(sourceContext, file.ServerRelativeUrl);
                                                Microsoft.SharePoint.Client.File.SaveBinaryDirect(desContext, folderDraftLocation + "/" + file.Name, fileInfo.Stream, true);
                                                migrationLogWrtr.WriteLine("Project " + coriNumber + " 'draft' document '" + file.Name + "' migrated into 2013 CPRO document library.");
                                                desContext.ExecuteQuery();
                                            }
                                            // cb (10/4/16) - Update Draft Communications documents Metadata
                                            UpdateMetadataofFiles(desContext, newItem, coriNumber, folderDraftLocation, "Draft");
                                        }
                                    }
                                    // cb (10/4/16) - Ignore if comms folder does not exist
                                    catch (Microsoft.SharePoint.Client.ServerException fnfEx)
                                    {
                                        if (fnfEx.ServerErrorTypeName != "System.IO.FileNotFoundException")
                                            exceptionWrtr.WriteLine("Error Migrating Approved Files; Project ID: " + coriNumber + "; Message: " + fnfEx.Message + "Exception Type: " + fnfEx.GetType().ToString());
                                    }
                                    catch (Exception ex)
                                    {
                                        exceptionWrtr.WriteLine("Error Migrating Draft Files; Project ID: " + coriNumber + "; Message: " + ex.Message + "Exception Type: " + ex.GetType().ToString());
                                    }

                                    //Get Final documents from CPRO 2010 library and move 2013
                                    try
                                    {

                                        var getFinalCurrFol = souweb.GetFolderByServerRelativeUrl("/ao/cpro/" + libraryName2010 + "/" + coriNumber + "/Final/Documents");
                                        var getFinalAllfiles = getFinalCurrFol.Files;
                                        sourceContext.Load(getFinalAllfiles);
                                        sourceContext.ExecuteQuery();
                                        string folderFinalLocation = "/Sites/CPRO/CPRO Documents/" + coriNumber + "/Final";
                                        if (sourceContext.HasPendingRequest)
                                            sourceContext.ExecuteQuery();
                                        if (getFinalAllfiles.Count > 0)
                                        {
                                            foreach (var file in getFinalAllfiles)
                                            {
                                                var fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(sourceContext, file.ServerRelativeUrl);
                                                Microsoft.SharePoint.Client.File.SaveBinaryDirect(desContext, folderFinalLocation + "/" + file.Name, fileInfo.Stream, true);
                                                migrationLogWrtr.WriteLine("Project " + coriNumber + " 'final' document '" + file.Name + "' migrated into 2013 CPRO document library.");
                                                desContext.ExecuteQuery();
                                            }
                                            // cb (10/4/16) -Update Final documents Metadata
                                            UpdateMetadataofFiles(desContext, newItem, coriNumber, folderFinalLocation, "Final");
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        exceptionWrtr.WriteLine("Error Migrating Final Files; Project ID: " + coriNumber + "; Message: " + ex.Message + "Exception Type: " + ex.GetType().ToString());
                                    }

                                    // Chaitu (10/4/16) - Get Final Communications documents from CPRO 2010 library and move 2013
                                    try
                                    {

                                        var getFinalCurrFol = souweb.GetFolderByServerRelativeUrl("/ao/cpro/" + libraryName2010 + "/" + coriNumber + "/Final/Communications");
                                        var getFinalAllfiles = getFinalCurrFol.Files;
                                        sourceContext.Load(getFinalAllfiles);
                                        sourceContext.ExecuteQuery();
                                        if (sourceContext.HasPendingRequest)
                                            sourceContext.ExecuteQuery();
                                        // Chaitu (10/5/16) - Creates Communications folder under Draft folder
                                        if (getFinalAllfiles.Count > 0)
                                        {
                                            var getDraftCurrFolcomm = desweb.GetFolderByServerRelativeUrl("/Sites/CPRO/CPRO Documents/" + coriNumber + "/Final");
                                            desContext.Load(getDraftCurrFolcomm);
                                            desContext.ExecuteQuery();
                                            getDraftCurrFolcomm.Folders.Add("Communications");
                                            desContext.ExecuteQuery();
                                            string folderFinalLocation = "/Sites/CPRO/CPRO Documents/" + coriNumber + "/Final/Communications";
                                            foreach (var file in getFinalAllfiles)
                                            {
                                                var fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(sourceContext, file.ServerRelativeUrl);
                                                Microsoft.SharePoint.Client.File.SaveBinaryDirect(desContext, folderFinalLocation + "/" + file.Name, fileInfo.Stream, true);
                                                migrationLogWrtr.WriteLine("Project " + coriNumber + " 'final' document '" + file.Name + "' migrated into 2013 CPRO document library.");
                                                desContext.ExecuteQuery();
                                            }
                                            // cb (10/4/16) - Update Final Communications documents Metadata
                                            UpdateMetadataofFiles(desContext, newItem, coriNumber, folderFinalLocation, "Final");
                                        }
                                       
                                    }
                                    // cb (10/4/16) - Ignore if comms folder does not exist
                                    catch (Microsoft.SharePoint.Client.ServerException fnfEx)
                                    {
                                        if (fnfEx.ServerErrorTypeName != "System.IO.FileNotFoundException")
                                            exceptionWrtr.WriteLine("Error Migrating Approved Files; Project ID: " + coriNumber + "; Message: " + fnfEx.Message + "Exception Type: " + fnfEx.GetType().ToString());
                                    }
                                    catch (Exception ex)
                                    {
                                        exceptionWrtr.WriteLine("Error Migrating Final Files; Project ID: " + coriNumber + "; Message: " + ex.Message + "Exception Type: " + ex.GetType().ToString());
                                    }
                                   
                                    #endregion
                                    desContext.ExecuteQuery();

                                }

                            }

                        }
                        else
                            exceptionWrtr.WriteLine("Project Record Already Exists in Destination; CPRO Project ID: " + projIdentifier);
                    }
                    catch (Microsoft.VisualBasic.FileIO.MalformedLineException ex) { }
                }
            }
        }

        private static void UpdateMetadataofFiles(ClientContext desContext, ListItem newItem, string coriNumber, string folderPath,string doctype)
        {
            var getFolder2013 = desContext.Web.GetFolderByServerRelativeUrl(folderPath);
            var getFiles2013 = getFolder2013.Files;
            desContext.Load(getFiles2013);
            desContext.ExecuteQuery();
            foreach (var file in getFiles2013)
            {
                var item = file.ListItemAllFields;
                item["Title"] = coriNumber;
                item["Project_x0020_Name"] = newItem["Title"];
                if (newItem["Date"] != "" && newItem["Date"] != null)
                {
                    item["Project_x0020_Created_x0020_Date"] = newItem["Date"];
                }
                item["Doc_x0020_Type"] = doctype;
                item.Update();
                desContext.Load(item);
                desContext.ExecuteQuery();
            }
        }

        private static string GetDocumentLibraryName(string coriNumber, ClientContext sourceContext)
        {
            CamlQuery libraryQuery = new CamlQuery();
            string libraryname="";
            List oldDocLibrary2010 = sourceContext.Web.Lists.GetByTitle(ConfigurationManager.AppSettings["oldDocLibrary2010"]);
            List newDocLibrary2010 = sourceContext.Web.Lists.GetByTitle(ConfigurationManager.AppSettings["newDocLibrary2010"]);
            libraryQuery.ViewXml =
                           @"<View><Query><Where><Eq><FieldRef Name='Title'/><Value Type='Text'>" + coriNumber + "</Value></Eq></Where></Query></View>";
            ListItemCollection oldDocLibraryColl = oldDocLibrary2010.GetItems(libraryQuery);
            sourceContext.Load(oldDocLibraryColl);
            sourceContext.ExecuteQuery();
            ListItemCollection newDocLibraryColl = newDocLibrary2010.GetItems(libraryQuery);
            sourceContext.Load(newDocLibraryColl);
            sourceContext.ExecuteQuery();
            if (oldDocLibraryColl.Count > 0)
            {
                return libraryname = "ProjectDocumentLibrary";
            }
            else if (newDocLibraryColl.Count > 0)
            {
                return libraryname = "ProjectDocumentsLibrary2013";

            }
            else
            {
                return null;
            }

        }

        private static bool InsertDataintoControlList(string coriNumber, ClientContext desContext)
        {
            string[] currentRow;
            using (TextFieldParser inputProjReader = new TextFieldParser(ConfigurationManager.AppSettings["projectCtrlInputWrtrPath"]))
            {
                inputProjReader.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited;
                inputProjReader.HasFieldsEnclosedInQuotes = true;
                inputProjReader.TrimWhiteSpace = false;
                inputProjReader.SetDelimiters(",");
                List newProjList = desContext.Web.Lists.GetByTitle(ConfigurationManager.AppSettings["desProjControlListName"]);
                currentRow = inputProjReader.ReadFields();
                while (!inputProjReader.EndOfData)
                {
                    try
                    {

                        currentRow = inputProjReader.ReadFields();

                        if (currentRow[1] == coriNumber)
                        {
                            ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                            desContext.Load(newProjList);
                            desContext.ExecuteQuery();
                            ListItem newItem = newProjList.AddItem(itemCreateInfo);
                            newItem["Title"] = currentRow[1];
                            newItem["IsCreateProjectLocked"] = currentRow[2];
                            newItem["IsProjectInformationLocked"] = currentRow[3];
                            newItem["IsComplianceReviewLocked"] = currentRow[4];
                            newItem["IsApprovalLocked"] = currentRow[5];
                            // Chaitu (10/5/16) -IsApprovalLocked is "yes" then IsCheckedLocked should be "Yes"
                            if (currentRow[5] == "Yes")
                            {

                                newItem["IsCheckedLocked"] = "Yes";
                            }
                            newItem["IsFINRALocked"] = currentRow[6];
                            newItem["IsStateFilingLocked"] = currentRow[7];
                            newItem["UnLockRequest"] = currentRow[8];
                            newItem["Month_x0020_created"] = currentRow[9];
                            if (currentRow[10] != "")
                            {
                                newItem["Month"] = currentRow[10];
                            }
                            if (currentRow[11] != "")
                            {
                                newItem["Year"] = currentRow[11];
                            }
                            newItem.Update();
                            desContext.ExecuteQuery();
                            break;
                        }

                    }
                    catch (Microsoft.VisualBasic.FileIO.MalformedLineException ex)
                    {
                        return false;
                    }
                }
                return true;
            };
        }

        private static bool InsertDataintoSFList(string coriNumber, ClientContext desContext)
        {
            string[] currentRow;
            string coriNumberSF;
            if (System.IO.File.Exists(ConfigurationManager.AppSettings["stateFilingInputWrtrPath"]))
            {
                using (TextFieldParser inputProjReader = new TextFieldParser(ConfigurationManager.AppSettings["stateFilingInputWrtrPath"]))
                {
                    inputProjReader.TextFieldType = Microsoft.VisualBasic.FileIO.FieldType.Delimited;
                    inputProjReader.HasFieldsEnclosedInQuotes = true;
                    inputProjReader.TrimWhiteSpace = false;
                    inputProjReader.SetDelimiters(",");
                    List newProjList = desContext.Web.Lists.GetByTitle(ConfigurationManager.AppSettings["desStateFilingListName"]);
                    currentRow = inputProjReader.ReadFields();
                    while (!inputProjReader.EndOfData)
                    {
                        try
                        {

                            currentRow = inputProjReader.ReadFields();
                            if (currentRow[1] != "")
                            {
                                coriNumberSF = currentRow[1];
                            }
                            else
                            {
                                coriNumberSF = currentRow[2];
                            }
                            if (coriNumberSF == coriNumber)
                            {
                                ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                                desContext.Load(newProjList);
                                desContext.ExecuteQuery();
                                ListItem newItem = newProjList.AddItem(itemCreateInfo);
                                newItem["Title"] = coriNumberSF;
                                newItem["State"] = currentRow[3];
                                newItem["Comment"] = currentRow[4];
                                if (currentRow[5] != "" && currentRow[5] != "1/1/0001")
                                {
                                    newItem["Date_x0020_Approved"] = currentRow[5];
                                }
                                if (currentRow[6] != "" && currentRow[6] != "1/1/0001")
                                {
                                    newItem["Date_x0020_Filed"] = currentRow[6];
                                }
                                newItem.Update();
                                desContext.ExecuteQuery();
                            }

                        }
                        catch (Microsoft.VisualBasic.FileIO.MalformedLineException ex)
                        {
                            return false;
                        }
                    }
                    return true;
                };
            }
            else
                return false;
        }


        private static void GetValidADUsers(string[] currentRow, UserFieldValues oUFV, ClientContext desContext)
        {
            if (currentRow[5] != "")
            {
                InsertdisADUser(currentRow[5], desContext, "Submitter",oUFV);

            }
            else
            {
                oUFV.SubmitterVal = currentRow[5];
            }
            if (currentRow[11] != "")
            {
                InsertdisADUser(currentRow[11], desContext, "ApprovingManager", oUFV);

            }
            else
            {
                oUFV.ApprovingManagerVal = currentRow[11];
            }
            if (currentRow[20] != "")
            {
                //InsertdisADUser(currentRow[20], "CoordinatingReviewers", "CoordinatingReviewersVal", context, newItem);
                InsertdisADUser(currentRow[20], desContext, "Reviewers", oUFV);

            }
            else
            {
                //newItem["CoordinatingReviewersVal"] = currentRow[20];
                oUFV.ReviewersVal = currentRow[20];
            }
            if (currentRow[36] != "")
            {
                InsertdisADUser(currentRow[36], desContext, "FiledBy", oUFV);
            }
            else
            {
                oUFV.FiledByVal = currentRow[36];
            }
            // cb (9/26/16) - Updated to map 2010 reviewers to 2013 secondary reviewers
            if (currentRow[80] != "")
            {
                //InsertdisADUser(currentRow[80], "Reviewers", "ReviewersVal", context, newItem);
                InsertdisADUser(currentRow[80], desContext, "SecondaryReviewer", oUFV);
            }
            else
            {
                //newItem["ReviewersVal"] = currentRow[80];
                oUFV.SecondaryReviewerVal = currentRow[80];
            }
            if (currentRow[86] != "")
            {
                InsertdisADUser(currentRow[86], desContext, "StateFiler", oUFV);
            }
            else
            {
                oUFV.StateFilerVal = currentRow[86];
            }

        }

        // Chaitu (10/5/16) - Ensure AD users 
        private static void InsertdisADUser(string fieldValue, ClientContext desContext, string fieldName, UserFieldValues oUFV)
        {
            User userLoginname = null;
            try
            {
                userLoginname = desContext.Web.EnsureUser(fieldValue);
                desContext.Load(userLoginname);
                desContext.ExecuteQuery();
                if (fieldName == "Submitter")
                {
                    oUFV.Submitter = userLoginname;
                }
                else if(fieldName=="ApprovingManager")
                {
                    oUFV.ApprovingManager = userLoginname;
                }
                else if (fieldName == "Reviewers")
                {
                    oUFV.Reviewers = userLoginname;
                }
                else if (fieldName == "FiledBy")
                {
                    oUFV.FiledBy = userLoginname;
                }
                else if (fieldName == "SecondaryReviewer")
                {
                    oUFV.SecondaryReviewer = userLoginname;
                }
                else if (fieldName == "StateFiler")
                {
                    oUFV.StateFiler = userLoginname;
                }

            }
            catch (ServerException ex)
            {
                if (fieldName == "Submitter")
                {
                    oUFV.SubmitterVal = fieldValue;
                }
                else if (fieldName == "ApprovingManager")
                {
                    oUFV.ApprovingManagerVal = fieldValue;
                }
                else if (fieldName == "Reviewers")
                {
                    oUFV.ReviewersVal = fieldValue;
                }
                else if (fieldName == "FiledBy")
                {
                    oUFV.FiledByVal = fieldValue;

                }
                else if (fieldName == "SecondaryReviewer")
                {
                    oUFV.SecondaryReviewerVal = fieldValue;
                }
                else if (fieldName == "StateFiler")
                {
                    oUFV.StateFilerVal = fieldValue;
                }
            }

        }

        //Chaitu - Creates Folder in the CPRO document 2013 library to copy docs from 2010
        private static bool CreateFoldersinLibrary(ListItem newItem, ClientContext desContext, string coriNumber)
        {
           
            string[] folderNames = new string[] { "Draft", "Approved", "Final" };
            try
            {
                List newCPRODocLib = desContext.Web.Lists.GetByTitle(ConfigurationManager.AppSettings["destDocLibraryName"]);
                var rootFolder = newCPRODocLib.RootFolder;
                var topFolder = rootFolder.Folders.Add(coriNumber);
                desContext.Load(topFolder);
                var item = topFolder.ListItemAllFields;
                item["Project_x0020_Name"] = newItem["Title"];
                item["Project_x0020_Created_x0020_Date"] = newItem["Date"];
                item.Update();
                desContext.Load(item);
                desContext.ExecuteQuery();
                foreach (var foldername in folderNames)
                {
                    topFolder.Folders.Add(foldername);
                    desContext.ExecuteQuery();
                }
                return true;
            }
           catch(Exception ex)
            {
                return false;
            }
        }

        //Insert data into CPRO 2013 List
        private static bool InsertDataintoCPROList(string[] currentRow, ListItem newItem, ClientContext context, UserFieldValues oUFV)
        {
            string typeOfProject = "";
            try
            {
                if (currentRow[1] != "")
                {
                    newItem["Date"] = currentRow[1];
                }
                newItem["Title"] = currentRow[2];
                newItem["CNumber"] = currentRow[3];
                newItem["INumber"] = currentRow[4];
                newItem["CategoryOfMaterial"] = currentRow[16];

                //"Category Description" not equal to "None of the Above"
                if (currentRow[16] != "")
                {
                    if (currentRow[16] != "None of the above")
                    {
                        newItem["TypeOfProject"] = "Streamlined";
                        typeOfProject = "Streamlined";
                    }
                    else
                    {
                        newItem["TypeOfProject"] = currentRow[94];
                    }
                }
                
                newItem["FilingRequired"] = currentRow[39];
                // Chaitu (10/7/16) -If Inumber then FINRAFilingStatus and StateFilingStatus should be "NA"
                if (currentRow[4] != "" && currentRow[4]!= null)
                {
                    newItem["FINRAFilingStatus"] = "NA";
                    newItem["StateFilingStatus"] = "NA";
                }
                // Chaitu (10/7/16) -If FilingRequired is "None Required" then FINRAFilingStatus and StateFilingStatus should be "NA"
                else if (currentRow[39].Contains("None Required"))
                {
                    newItem["FINRAFilingStatus"] = "NA";
                    newItem["StateFilingStatus"] = "NA";
                }
                else if (currentRow[39].Contains("FINRA") && currentRow[39].Contains("State Insurance Dept"))
                {
                    newItem["FINRAFilingStatus"] = currentRow[41];
                    newItem["StateFilingStatus"] = currentRow[87];
                }

                // Chaitu (10/7/16) -If FilingRequired is only "FINRA" then StateFilingStatus should be "NA"
                else if (currentRow[39].Contains("FINRA"))
                {
                    if (!currentRow[39].Contains("State Insurance Dept"))
                    {
                        newItem["StateFilingStatus"] = "NA";
                        newItem["FINRAFilingStatus"] = currentRow[41];
                    }
                    
                }
                // Chaitu (10/7/16) -If FilingRequired is only "State Insurance Dept" then FINRA should be "NA"
                else if (currentRow[39].Contains("State Insurance Dept"))
                {
                    if (!currentRow[39].Contains("FINRA"))
                    {
                        newItem["FINRAFilingStatus"] = "NA";
                        newItem["StateFilingStatus"] = currentRow[87];
                    }
                }
                // Chaitu (10/5/16) -If Streamlined then FINRAFilingStatus and StateFilingStatus should be "NA"
                else if (typeOfProject == "Streamlined")
                {
                    newItem["FINRAFilingStatus"] = "NA";
                    newItem["StateFilingStatus"] = "NA";
                }
                else
                {
                    newItem["FINRAFilingStatus"] = currentRow[41];
                    newItem["StateFilingStatus"] = currentRow[87];
                }



                if (currentRow[5] != "")
                {
                    if (oUFV.Submitter != null)
                    {
                        newItem["Writer"] = oUFV.Submitter;
                        newItem["Submitter_val"] = oUFV.Submitter.Title;
                    }
                    else
                    {
                        newItem["Submitter_val"] = oUFV.SubmitterVal;
                    }


                }
                else
                {
                    newItem["Submitter_val"] = currentRow[5];
                }

                newItem["AcknowledgeDetailsSubmitted"] = currentRow[6];
                newItem["AdditionalInformation"] = currentRow[7];
                newItem["StateAdditionalInfo"] = currentRow[8];
                newItem["ApprovalComments"] = currentRow[9];
                if (currentRow[10] != "")
                {
                    newItem["ApprovalDate"] = currentRow[10];
                }
                if (currentRow[11] != "")
                {
                    if (oUFV.ApprovingManager != null)
                    {
                        newItem["ApprovingManager"] = oUFV.ApprovingManager;
                        newItem["ApprovingManagerVal"] = oUFV.ApprovingManager.Title;
                    }
                    else
                    {
                        newItem["ApprovingManagerVal"] = oUFV.ApprovingManagerVal;
                    }
                }
                else
                {
                    newItem["ApprovingManagerVal"] = currentRow[11];
                }
                newItem["AttorneyName"] = currentRow[12];
                // cb (10/4/16) - updated to handle multi-select values
                if (currentRow[13] != "")
                {
                    newItem["Audience"] = GetSemiColonSepValues(currentRow[13]);
                }
                if (currentRow[14] != "")
                {
                    newItem["BusinessArea"] = GetSemiColonSepValues(currentRow[14]);
                }
                newItem["isApproved"] = currentRow[15];
               

                newItem["ComplianceComment"] = currentRow[17];
                if (currentRow[18] != "")
                {
                    newItem["ComplianceReviewCompletedDate"] = currentRow[18];
                }
                // cb (10/7/16)If TypeofProject is ‘Streamlined’,then ComplianceReviewStatus = ‘NA’
                if (typeOfProject == "Streamlined")
                {

                    newItem["ComplianceReviewStatus"] = "NA";

                }
                else
                {
                    newItem["ComplianceReviewStatus"] = currentRow[19];
                }
                
                // cb (9/26/16) - Updated to map 2010 coordinating reviewer to 2013 reviewer (aka coordinating reviewer)
                if (currentRow[20] != "")
                {
                    //InsertdisADUser(currentRow[20], "CoordinatingReviewers", "CoordinatingReviewersVal", context, newItem);
                    if (oUFV.Reviewers != null)
                    {
                        newItem["Reviewers"] = oUFV.Reviewers;
                        newItem["ReviewersVal"] = oUFV.Reviewers.Title;
                    }
                    else
                    {
                        newItem["ReviewersVal"] = oUFV.ReviewersVal;
                    }
                

                }
                else
                {
                    //newItem["CoordinatingReviewersVal"] = currentRow[20];
                    newItem["ReviewersVal"] = currentRow[20];
                }
               
                newItem["CreateProjectStatus"] = currentRow[21];
                if (currentRow[22] != "")
                {
                    newItem["DateAssigned"] = currentRow[22];
                }
                if (currentRow[23] != "")
                {
                    newItem["DateOfFirstUse"] = currentRow[23];
                }
                if (currentRow[24] != "")
                {
                    newItem["DateSubmitted"] = currentRow[24];
                }
                if (currentRow[25] != "")
                {
                    newItem["Date_x0020_Submitted_x0020_to_x0"] = currentRow[25];
                }
                if (currentRow[26] != "")
                {
                    newItem["DateCommentsReceivedFromLaw"] = currentRow[26];
                }
                if (currentRow[27] != "")
                {
                    newItem["DateOfVerification"] = currentRow[27];
                }
                if (currentRow[28] != "")
                {
                    newItem["DateSentToLaw"] = currentRow[28];
                }
                newItem["DiscontinuedComments"] = currentRow[29];
                if (currentRow[30] != "")
                {
                    newItem["DateDiscontinued"] = currentRow[30];
                }
                newItem["DocumentUploadedInDrafts"] = currentRow[31];
                newItem["EligibleForStreamlinedReview"] = currentRow[32];

                if (currentRow[33] != "")
                {
                    newItem["ExpirationDate"] = currentRow[33];
                }
                newItem["ExpirationNotificationsRequired"] = currentRow[34];
                newItem["FINRARule"] = currentRow[35];
                if (currentRow[36] != "")
                {
                    
                    if (oUFV.FiledBy != null)
                    {
                        newItem["FiledBy"] = oUFV.FiledBy;
                        newItem["FiledByVal"] = oUFV.FiledBy.Title;
                    }
                    else
                    {
                        newItem["FiledByVal"] = oUFV.FiledByVal;
                    }
                }
                else
                {
                    newItem["FiledByVal"] = currentRow[36];
                }
                if (currentRow[37] != "")
                {
                    newItem["FilingDueDate"] = currentRow[37];
                }
                if (currentRow[38] != "")
                {
                    newItem["FilingSubmittedOn"] = currentRow[38];
                }
               
                newItem["FINFRAFilingComment"] = currentRow[40];
              
                
                if (currentRow[42] != "")
                {
                    newItem["Location"] = GetSemiColonSepValues(currentRow[42]);
                }
                if (currentRow[43] != "")
                {
                    newItem["From_x0020_Intended_x0020_Usage_"] = currentRow[43];
                }
                // cb (9/26/16) - Adding logic to translate 2010 "No" dropdown to 2013 "unchecked"
                newItem["IsPreviouslyApprovedBySME"] = currentRow[44] == "No" ? "" : currentRow[44];
                newItem["IsPreviouslyApproved"] = currentRow[45] == "No" ? "" : currentRow[45];
                if (currentRow[46] != "")
                {
                    newItem["DistributionMethod"] = GetSemiColonSepValues(currentRow[46]);
                }
                if (currentRow[47] != "")
                {
                    newItem["StateFilingsRequired"] = GetSemiColonSepValues(currentRow[47]);
                }
                newItem["DistributionGroupOtherSelected"] = currentRow[48];
                newItem["From"] = currentRow[49];
                newItem["Subject"] = currentRow[50];
                newItem["To"] = currentRow[51];
                newItem["AudienceOtherSelected"] = currentRow[52];
                newItem["NoFilingReasonsSelectedOther"] = currentRow[53];
                newItem["StateFilingsSelectedOther"] = currentRow[54];
                newItem["TypeOfMaterialOtherSelected"] = currentRow[55];
                newItem["InternalUseOnly"] = currentRow[56];
                newItem["IsRegisteredPrincipal"] = currentRow[57];
                newItem["ComplianceReviewComplete"] = currentRow[58];
                if (currentRow[59] != "")
                {
                    newItem["MaterialReference"] = GetSemiColonSepValues(currentRow[59]);
                }
                newItem["MaterialSentToApprover"] = currentRow[60];
                newItem["MaterialSubmittedIsWebContent"] = currentRow[61];
                newItem["Moved"] = currentRow[62];
                newItem["NewReview"] = currentRow[63];
                if (currentRow[64] != "")
                {
                    newItem["NoFilingReasons"] = GetSemiColonSepValues(currentRow[64]);
                }
                newItem["NoCommentsReceivedFromLaw"] = currentRow[65];
                newItem["PagesReviewed"] = currentRow[66];
                // cb (9/26/16) - Adding logic to translate 2010 "No" dropdown to 2013 "unchecked"
                newItem["PerformanceVerification"] = currentRow[67] == "No" ? "" : currentRow[67];
                if (currentRow[68] == "Not applicable")
                {
                    newItem["Preceded"] = "Not Applicable";
                }
                else
                {
                    newItem["Preceded"] = currentRow[68];
                }
                newItem["PreviousAttorneyName"] = currentRow[69];
                if (currentRow[70] != "")
                {
                    newItem["PreviousReviewDate"] = currentRow[70];
                }
                newItem["PreviousSMEName"] = currentRow[71];
                newItem["ApprovalStatus"] = currentRow[72];
                // Chaitu (10/5/16) -If ApprovalStatus is "Submitted' or "Saved" then RevisionStatus should be "Submitted"
                if (currentRow[72] == "Submitted" || currentRow[72] == "Saved")
                {
                    newItem["RevisionStatus"] = "Submitted";
                }
                newItem["ProjectInformationStatus"] = currentRow[73];
                newItem["DistributeMaterialOtherSelected"] = currentRow[74];
                newItem["ProjectDocumentLibraryName"] = currentRow[75];
                newItem["ReasonForChangeInExpirationDate"] = currentRow[76];
                if (currentRow[77] != "")
                {
                    newItem["FilingReplyDate"] = currentRow[77];
                }
                newItem["ReplyStatus"] = currentRow[78];
                newItem["Re_x002d_Review"] = currentRow[79];
                // cb (9/26/16) - Updated to map 2010 reviewers to 2013 secondary reviewers
                if (currentRow[80] != "")
                {
                    
                    
                    if (oUFV.SecondaryReviewer != null)
                    {
                        newItem["SecondaryReviewer"] = oUFV.SecondaryReviewer;
                        newItem["SecondaryReviewerVal"] = oUFV.SecondaryReviewer.Title;
                    }
                    else
                    {
                        newItem["SecondaryReviewerVal"] = oUFV.SecondaryReviewerVal;
                    }
                }
                else
                {
                    //newItem["ReviewersVal"] = currentRow[80];
                    newItem["SecondaryReviewerVal"] = currentRow[80];
                }
                newItem["ReviewersAssessmentOfMarketingMa"] = currentRow[81];
                if (currentRow[82] != "")
                {
                    newItem["RevisedExpirationDate"] = currentRow[82];
                }
                newItem["RevisionRequired"] = currentRow[83];
                newItem["SectionNumber"] = currentRow[84];
                if (currentRow[85] != "")
                {
                    newItem["SMEPReviousReviewDate"] = currentRow[85];
                }
                if (currentRow[86] != "")
                {
                    if (oUFV.StateFiler != null)
                    {
                        newItem["StateFiler"] = oUFV.StateFiler;
                        newItem["StateFilerVal"] = oUFV.StateFiler.Title;
                    }
                    else
                    {
                        newItem["StateFilerVal"] = oUFV.StateFilerVal;
                    }
                }
                else
                {
                    newItem["StateFilerVal"] = currentRow[86];
                }
                
                // cb (9/26/16) - Adding logic to translate 2010 "No" dropdown to 2013 "unchecked"
                newItem["SubmittedToLawForReview"] = currentRow[88] == "No" ? "" : currentRow[88];
                if (currentRow[89] != "")
                {
                    newItem["TIAA_x002d_CREF_x0020_Entity"] = GetSemiColonSepValues(currentRow[89]);
                }
                newItem["To_x0020_Intended_x0020_Usage_x0"] = currentRow[90];
                newItem["Turnaround"] = currentRow[91];
                newItem["FilingType"] = currentRow[92];
                if (currentRow[93] != "")
                {
                    newItem["TypeOfMaterial"] = GetSemiColonSepValues(currentRow[93]);
                }

                //newItem["TypeOfProject"] = currentRow[94];
                newItem["TypeOfReview"] = currentRow[95];
                newItem["UnLockComments"] = currentRow[96];
                // newItem["UnlockProject"] = currentRow[97];
                if (currentRow[98] != "")
                {
                    newItem["DistributionGroup"] = GetSemiColonSepValues(currentRow[98]);
                }
                newItem["OtherMaterialsIncluded"] = currentRow[99];
                // newItem["CreatedBy"] = currentRow[100];
                // newItem["ModifiedBy"] = currentRow[101];

                // cb (10/3/16) - Updated to track migrated records
                newItem["Migrated"] = "True";

                // cb (10/4/16) - Added related C number
                newItem["ProjectCNumber"] = currentRow[102];

                // cb (10/7/16) - Set default for Moved (Mobius)
                newItem["Moved"] = "Yes";

              newItem.Update();
               
               context.ExecuteQuery();
                return true;
            }
                catch (Microsoft.VisualBasic.FileIO.MalformedLineException ex) {
                    return false;
                }
            catch (ServerException ex)
            {
                return false;
            }
                
        }

        private static string GetSemiColonSepValues(string fieldValue)
        {
            string fieldvalues = "";
            string[] fieldValueColl = fieldValue.Split('|');
            foreach(var f in fieldValueColl)
            {
                // cb (10/4/16) - added space to fix issue in sp app
                fieldvalues += f + "; ";
            }
            return fieldvalues.Length > 0 ? fieldvalues.Remove(fieldvalues.Length - 2, 2) : String.Empty;
        }
        // Insert disabled AD accounts into CPRO 2013 list
        private static void InsertdisADUser(string fieldValue, string fieldname, string fieldnameval, ClientContext context, ListItem newItem)
        {
           
            User userLoginname = null;
            try
            {
                userLoginname = context.Web.EnsureUser(fieldValue);
                context.Load(userLoginname);
                context.ExecuteQuery();
                newItem[fieldname] = userLoginname;
              
            }
            catch (ServerException ex)
            {
                newItem[fieldnameval] = fieldValue;
            }
        }

        #region List Lookup Values
        static string GetLookupValues(ListItem lookupListItem, string fieldName)
        {
            try
            {
                // Check for multi-value
                FieldLookupValue[] flv = (FieldLookupValue[])lookupListItem[fieldName];
                return GetLookupValues(flv);
            }
            catch (InvalidCastException ex)
            {
                // Handle single value
                FieldLookupValue flv = (FieldLookupValue)lookupListItem[fieldName];
                return GetLookupValues(flv);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        static string GetLookupValues(FieldLookupValue flv)
        {
            return flv.LookupValue;
        }

        static string GetLookupValues(FieldLookupValue[] flv)
        {
            string lookupValues = "";

            foreach (FieldLookupValue f in flv)
            {
                lookupValues += f.LookupValue + "|";
            }

            return lookupValues.Length > 0 ? lookupValues.Remove(lookupValues.Length - 1, 1) : String.Empty;
        }
        #endregion

        #region AD Account Lookups
        // Get AD account name based on people picker value(s)
        static private string GetUserAcctName (ListItem userListItem, string fieldName)
        {
            try
            {
                // Check for multi-value
                FieldUserValue[] fuv = (FieldUserValue[])userListItem[fieldName];
                
                return GetUserAcctName(fuv);
            }
            catch (InvalidCastException ex)
            {
                // Handle single value
                FieldUserValue fuv = (FieldUserValue)userListItem[fieldName];
                return GetUserAcctName(fuv);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // Return single acct name
        static private string GetUserAcctName(FieldUserValue ufv)
        {
            try
            {
                ListItem principal = siteUsers.GetById(ufv.LookupId);

                sourceContext.Load(principal);
                sourceContext.ExecuteQuery();
                return principal["Name"].ToString();
            }
            catch (ServerException ex)
            {
                return ufv.LookupValue;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }

        // Overloaded for multi-value people pickers
        static private string GetUserAcctName(FieldUserValue[] fuv)
        {
            string acctName = "";
            int i = 0;
            try
            {
                // Go through values
                ListItem[] principals = new ListItem[fuv.Length];
                for (i = 0; i < fuv.Length; i++)
                {
                    principals[i] = siteUsers.GetById(fuv[i].LookupId);
                    sourceContext.Load(principals[i]);
                    sourceContext.ExecuteQuery();
                    Console.WriteLine(principals[i]["Name"]);
                    acctName += principals[i]["Name"] + "|";
                }

                return acctName.Length > 0 ? acctName.Remove(acctName.Length - 1, 1) : String.Empty;
            }
            catch(ServerException ex)
            {
                return fuv[i].LookupValue;
            }
             catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        static void LoadSiteUsers()
        {
            List userList = sourceContext.Web.SiteUserInfoList;
            sourceContext.Load(userList);

            siteUsers = userList.GetItems(CamlQuery.CreateAllItemsQuery());

            sourceContext.Load(siteUsers, items => items.Include(
                item => item.Id, item => item["Name"]));

            sourceContext.ExecuteQuery();
        }
    }
}
