﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPRODataMigration.Utility
{
    public  class UserFieldValues
    {
        public  User Submitter { get; set; }
        public  User ApprovingManager { get; set; }
        public User Reviewers { get; set; }
        public User FiledBy { get; set; }
        public User SecondaryReviewer { get; set; }
        public User StateFiler { get; set; }
        public string SubmitterVal { get; set; }
        public string ApprovingManagerVal { get; set; }
        public string ReviewersVal { get; set; }
        public string FiledByVal { get; set; }
        public string SecondaryReviewerVal { get; set; }
        public string StateFilerVal { get; set; }

    }
}
