﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CPRODataMigration.Utility
{
    public enum Abbreviation
    {
        GA, NC, OR, CA, MI, CT, MD, MN, MS, NV, OK, WV,[Display(Name="Other 1")]other1, [Display(Name="Other 2")]other2, [Display(Name="Other 3")]other3

    }

    public class FilingState
    {
        public Abbreviation Abbreviation {get; set;}
        public string Comments { get; set; }
        public DateTime DateApproved { get; set; }
        public DateTime DateFiled { get; set; }
    }
}
