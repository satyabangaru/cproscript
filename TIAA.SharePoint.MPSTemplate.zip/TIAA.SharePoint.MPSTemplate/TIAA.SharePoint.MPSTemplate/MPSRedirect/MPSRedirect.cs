﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI;
using Microsoft.SharePoint;

namespace TIAA.SharePoint.MPSTemplate.MPSRedirect
{
    public class MPSRedirect : UserControl
    {
        protected override void OnInit(EventArgs e)
        {
            //not necessary, the new id of the web templates is 2
            //if (//template picker
            //    Page.Request.Path.ToLower().EndsWith("/_layouts/15/templatepick.aspx") && 
            //    //2=> MPS Templates
            //    Page.Request.QueryString["ID"] == "2")
            //{
            //    //Redirect to 72742 (SapiensMPS) templates, see webtemp_SapiensMPS.xml
            //    Page.Response.Redirect(Page.Request.RawUrl.Substring(0, Page.Request.RawUrl.IndexOf("?")) + "?" +
            //        string.Join("&", 
            //        Page.Request.QueryString.AllKeys.Select(
            //        //change ID to 72742, the rest stays the same
            //        k => k + "=" + (k.ToLower() == "id" ? "72742" : Page.Request.QueryString[k])
            //        ).ToArray()));
            //}
            base.OnInit(e);
        }
    }
}
