﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint;

namespace TIAA.SharePoint.MPSTemplate
{
    public class ProvisioningProvider : SPWebProvisioningProvider
    {
        public override void Provision(SPWebProvisioningProperties props)
        {
            SPWeb web = props.Web;
            //apply SharePoint Meeting Workspace template
            //the provistioning data contains the name of the site definition. E.g. MPS#0, MPS#1, ...
            //see webtemp_SapiensMPS.xml
            web.ApplyWebTemplate(props.Data);
        }
    }
}
