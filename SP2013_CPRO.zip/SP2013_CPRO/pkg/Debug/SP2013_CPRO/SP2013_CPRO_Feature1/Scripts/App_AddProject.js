﻿//'use strict';


// Get user variables
var context = SP.ClientContext.get_current();
// Get the URI decoded URLs
var hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
var appUrl = decodeURIComponent(getQueryStringParameter("SPAppWebUrl"));
var scriptbase = appUrl + '/_layouts/15/';
// Define lists
var listName = 'Compliance PRO List';
var listName_metadata = listName.replace(/\ /g, '_x0020_');
var listName2 = 'CPRO Project Control List';
var listName2_metadata = listName2.replace(/\ /g, '_x0020_');
// Define the folder path  
var docPath = 'CPRO Documents';

/* getting division property */
getCurrentUserArea();

var test = false;
// display test value based on url value
var full_url = document.referrer; // Get url from form action
var checkDebug = getUrlParameters("debug", full_url, true); 
if (checkDebug) {
    test = true;
}

// set defaults
var myItems = Backbone.Model.extend({
    defaults: {
        /* ----> add entries below ------------------------------------------------------------ */
        name: '',
        size: ''
    },
    initialize: function () {
        // add variables to data-binding
        this.on("add", function (model) {
            /* ----> add entries below ------------------------------------------------------------ */
            //var name = model.get("name");
            //var size = model.get("size");
        });
    }
});
viewItems = new Backbone.Collection();



// This code runs when the DOM is ready and creates a context object which is needed to use the SharePoint object model
$(function () {

    // remove user and add people picker back in
    $(".replaceUser").click(function () {
        var userType = $(this).data('usertype');
        if (test) {
            console.log('replace user: ' + userType);
        }
        // remove user
        $('.display_' + userType).addClass('hidden');
        $('.display_' + userType).html('');
        // reveal people picker
        $('[data-person="' + userType + '"]').removeClass('hidden');
        // focus on input
        $('[data-person="' + userType + '"] input').focus();
    });

    // fill in date
    fillDate('#display_date');

    // autopopulate submitter
    checkCurrentUser();

    // add required symbol for required fields
    $('input, select, div').each(function () {
        if ($(this).data('validate') != null) {
            // add required icon to field
            $(this).addClass('requiredText');
            // add class to previous div
            $(this).parent().prev('.col-xs-4').addClass('requiredCell');
        }
    });

    // project input field .. lowercase only
    $('input#projectName').keyup(function () {
        this.value = this.value.toLowerCase();
        this.value = this.value.replace(/[^a-za-z0-9._ ]/g, '');
        this.value = this.value.replace(/[ ]/g, '_');
    });

    // cancel button function
    $('#cancel-input').click(function () {
        //SP.UI.ModalDialog.commonModalDialogClose(1, 1);
        window.parent.location = hostUrl + '/Lists/' + listName + '/AllItems.aspx';
    });

    // load itemlist backbone collection
    ItemList = Backbone.Collection.extend({
        initialize: function () {
            // 
        }
    });
    ItemView = Backbone.View.extend({
        tagName: '',
        events: {
            'click #add-input': 'getItem'
        },
        initialize: function () {
            var thisView = this;
            this.itemlist = new ItemList;
            _.bindAll(this, 'render');
            this.itemlist.bind("add", function (model) {
                thisView.render(model);
            })
        },
        getItem: function () {
            // reveal loading icon
            $('.uploadLoading').removeClass('hidden');
            // change buttons status
            $('#add-input').prop('disabled', true);
            $('#cancel-input').prop('disabled', true);
            // hide error message
            $('.error').addClass('hidden');
            // check required fields
            var fail = false;
            // loop all input fields
            $('input').each(function () {
                // check for validation data tag
                if ($(this).data('validate') == 'required') {
                    // check if input value found
                    if ($(this).val() == false) {
                        fail = true;
                        $(this).after('<span class="validation">required</span>');
                    } else {
                        $(this).next('span.validation').hide();
                    }
                }
            });
            // validate for people picker error
            $('.sp-peoplepicker-errorMsg').each(function () {
                fail = true;
            });
            // validate if people picker results exists
            $('.peoplepicker[data-validate="required"]').each(function () {
                var personLabel = $(this).data('person');
                var ppContent = $('.display_' + personLabel + ' span').html();
                if (ppContent == '' || ppContent == null) {
                    ppContent = $(this).find('.ms-entity-resolved').html();
                    if (ppContent == '' || ppContent == null) {
                        fail = true;
                        if (test) {
                            console.log('Fail: PP no person picked');
                        }
                        $('.pp_error[data-validatepp="writer"]').removeClass('hidden');
                    } else {
                        $('.pp_error[data-validatepp="writer"]').addClass('hidden');
                    }
                }
            });

            // get values
            var item_Name = $('#projectName').val();
            var item_Name2 = false;
            if ($('#internalUse').is(':checked')) {
                item_Name2 = true;
            }
            if (fail == false) {
                this.itemlist.add({
                    projectName: item_Name,
                    internalUse: item_Name2
                });
            } else {
                $('.error .error_msg').html('Validation failed');
                $('.error').removeClass('hidden');
                // hide loading icon
                $('.uploadLoading').addClass('hidden');
                // change buttons status
                $('#add-input').prop('disabled', false);
                $('#cancel-input').prop('disabled', false);
            }
        },
        render: function (model) {
            // add to sharepoint list
            var passVar = {
                projectName: model.get("projectName"),
                internalUse: model.get("internalUse")
            };
            addListItem(passVar, 0);
        }
    });
    var view = new ItemView({ el: 'body' });


});

function checkCurrentUser() {
    var currentWriter = '';
    if (test) {
        console.log('Checking current user');
    }
    
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(appUrl + '/_layouts/15/SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });

    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/Web/CurrentUser?$expand=Groups&@target='" + hostUrl + "'";
        if (test) {
            console.log(domain);
        }
        executor.executeAsync({
            url: domain,
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: function (data, status, headers, config) {
                var body = jQuery.parseJSON(data.body);
                var currentUserID = body.d.Id;
                var currentUserTitle = body.d.Title;
                var currentUserArea = '';
                var groupNames = ['CPRO Approvers', 'CPRO MRU Group', 'CPRO Reviewers', 'CPRO Writers', 'CPRO Administrators'];
                var userGroups = body.d.Groups.results;
                $.each(userGroups, function (index, value) {
                    var properties = userGroups[index];
                    var groupName = properties.LoginName;
                    if (groupName == 'CPRO Writers' || groupName == 'CPRO Administrators') {
                        currentWriter = 'y';
                    }
                });


                if (currentWriter == 'y') {

                    // load people picker
                    var pp_multi = '';
                    var pp_person = '';
                    var pp_group;
                    $('.peoplepicker').each(function () {
                        pp_multi = $(this).data('multiple');
                        pp_person = $(this).data('person');
                        pp_group = $(this).data('group');
                        loadPeoplePickerScripts(pp_person, pp_multi, pp_group);
                    });

                    // display user inplace of peoplepicker
                    $('.display_writer span.name').html(currentUserTitle);
                    $('.display_writer span.id').html(currentUserID);
                   // $('.display_writer span.area').html(currentUserArea);
                    //$('.display_writer span').html(currentUserTitle + '<span class="">' + currentUserID + '</span>');

                    // set focus
                    $('#projectName').focus();
                    // remove loading cover
                    $('.loading-container').css('display', 'none');
                } else {
                    // not a writer
                    $('.loading-container .messaging h1').html('Permission Access Denied: Only Submitters allowed to create projects');
                    $('.loading-container .messaging').css('background', 'none');
                }
            },
            error: function (data, errorCode, errorMessage) {
                $('.error .error_msg').html('Failed on User Lookup ' + errorMessage + '');
                $('.error').removeClass('hidden');
                $('#add-input').prop('disabled', false).html('Create New Project');
                $('#cancel-input').prop('disabled', false);
                // hide loading icon
                $('.uploadLoading').addClass('hidden');
            },
            state: "Get List Data"
        });
    }
}

/* getting division property */
function getCurrentUserArea() {
    var domain = appUrl + "/_api/SP.UserProfiles.PeopleManager/GetMyProperties";
    if (test) {
        console.log(domain);
    }
    $.ajax({
        url: domain,
        type: "GET",
        headers: { "Accept": "application/json; odata=verbose" },
        success: function (data) {
            try {
                //Get properties from user profile Json response  
                //  userDisplayName = data.d.DisplayName;
                //AccountName = data.d.AccountName;
                var properties = data.d.UserProfileProperties.results;
                for (var i = 0; i < properties.length; i++) {
                    if (properties[i].Key == "Division") {
                        Division = properties[i].Value;
                    }

                }
                $('.display_writer span.area').html(Division);


            } catch (err2) {
                $('.error .error_msg').html('ERROR A: ' + JSON.stringify(err2) + '');
                $('.error').removeClass('hidden');
                $('#add-input').prop('disabled', false).html('Create New Project');
                $('#cancel-input').prop('disabled', false);
                // hide loading icon
                $('.uploadLoading').addClass('hidden');
            }
        },
        error: function (jQxhr, errorCode, errorThrown) {
            $('.error .error_msg').html('ERROR B: ' + errorThrown + '');
            $('.error').removeClass('hidden');
            $('#add-input').prop('disabled', false).html('Create New Project');
            $('#cancel-input').prop('disabled', false);
            // hide loading icon
            $('.uploadLoading').addClass('hidden');
        }
    });
}
/* adding item to sp list */
function addListItem(passVar, retry) {
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });

    // After the cross-domain library is loaded, execution 
    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items?$orderby=Number%20desc&$top=1&@target='" + hostUrl + "'";
        if (test) {
            console.log(domain);
        }
        executor.executeAsync({
            url: domain,
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: function (data, status, headers, config) {
                var body = jQuery.parseJSON(data.body);
                var results = body.d.results;
                var number;
                var properties
                $.each(results, function (index, value) {
                    properties = results[index];
                    number = parseInt(properties.Number) + 1;
                    if (retry > 0) {
                        number++;
                    }
                    number = pad(number, 10); // add leading zeros
                });
                if (test) {
                    console.log('Number: ' + number);
                }
                getPeople(number);
            },
            error: function (data, errorCode, errorMessage) {
                $('.error .error_msg').html('ERROR 1: ' + errorMessage + '');
                $('.error').removeClass('hidden');
                $('#add-input').prop('disabled', false).html('Create New Project');
                $('#cancel-input').prop('disabled', false);
                // hide loading icon
                $('.uploadLoading').addClass('hidden');
            },
            state: "Get List Data"
        });
    }

    function getPeople(number) {
        // get People Picker
        var writer = '';
        var writerId = '';
        var key = '';
        $('.peoplepicker[data-person="writer"] .sp-peoplepicker-userSpan').each(function () {
            writer = $(this).children('.ms-entity-resolved').html();
            key = $(this).children('.ms-entity-resolved').attr('id');
            key = key.split('_')[2];
            if (test) {
                console.log('People Scrape: ' + key);
            }
            GetUserId(key, writer);
        });
        if (writer == '' || writer == null) {
            writer = $('.display_writer span.name').html();
            writerId = $('.display_writer span.id').html();
            writerBusinessArea = $('.display_writer span.area').html();
            // add to list
            addList(number, writer, writerId, writerBusinessArea)
        }

        function GetUserId(userName, writer) {
            var website = context.get_web();
            var currentUser = website.ensureUser(userName);

            context.load(website);
            context.load(currentUser);
            context.executeQueryAsync(onRequestSucceeded, onRequestFailed);

            function onRequestSucceeded() {
                var userId = currentUser.get_id();
                //var messageText = " \"DisplayName\" property is " + personProperties.get_displayName();
                //messageText += "<br />\"Department\" property is " + personProperties.get_userProfileProperties()['Department'];
                if (test) {
                    //console.log(messageText);
                }
                getReplacedUserArea(number, writer, userId, userName);
                //var writerBusinessArea = '';
                //addList(number, writer, userId, writerBusinessArea)
            }

            function onRequestFailed(sender, args) {
                $('.error .error_msg').html('ERROR 2: ' + args.get_message() + '');
                $('.error').removeClass('hidden');
                $('#add-input').prop('disabled', false).html('Create New Project');
                $('#cancel-input').prop('disabled', false);
                // hide loading icon
                $('.uploadLoading').addClass('hidden');
            }

        }

    }

    function addList(number, writer, writerId, writerBusinessArea) {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items?@target='" + hostUrl + "'";
        if (test) {
            console.log(domain);
            //console.log('Submitter: ' + passVar.submitter);
        }

        // set compliance #
        var cNumber = '';
        var iNumber = '';
        var passControlNumber;
        var internalResponse;
        if (passVar.internalUse == false) {
            cNumber = 'C' + number; 
            passControlNumber = cNumber;
            internalResponse = 'No';
        } else {
            // internal use
            iNumber = 'I' + number;
            passControlNumber = iNumber;
            internalResponse = 'Yes';
        }
        var exeBody = "{'__metadata': { 'type': 'SP.Data." + listName_metadata + "ListItem' }," +
            "'Title': '" + passVar.projectName + "', " +
            "'CNumber': '" + cNumber + "', " +
            "'INumber': '" + iNumber + "', " +
            "'Number': '" + number + "', " +
            "'InternalUseOnly': '" + internalResponse + "', " +
            "'Date': '" + fillDate() + "', " +
            "'SectionNumber': '1', " +
            "'Submitter_val': '" + writer + "', " +
            "'WriterId': " + writerId + ", " +
            "'BusinessArea': '" + writerBusinessArea + "', " +

            "'CreateProjectStatus': 'Submitted', " +
            "'ProjectInformationStatus': 'Not Started', " +
            "'ComplianceReviewStatus': 'Not Started', " +
            "'RevisionStatus': 'Not Started', " + 
            "'ApprovalStatus': 'Not Started', " +
            "'FINRAFilingStatus': '', " +
            "'StateFilingStatus': '' " +
        
        

        "}";

        if (test) {
            console.log(exeBody);
        }

        // Add to list
        executor.executeAsync({
            url: domain,
            method: "POST",
            contentType: "application/json;odata=verbose",
            headers: { "content-type": "application/json; odata=verbose" },
            body: exeBody,
            success: function (data, status, headers, config) {
                var status = true;
                if (test) {
                    console.log('SUCCESS: item created');
                }
                // add project control
                addProjectControl(passControlNumber, number, passVar);
            },
            error: function (data, errorCode, errorMessage) {
                $('.error .error_msg').html('ENTRY ERROR: ' + errorMessage + '');
                $('.error').removeClass('hidden');
                $('#add-input').prop('disabled', false).html('Create New Project');
                $('#cancel-input').prop('disabled', false);
                // hide loading icon
                $('.uploadLoading').addClass('hidden');
            },
            state: "Add List Item"
        });
    }  
   
    // create project control list item
    function addProjectControl(passControlNumber, number, passVar) {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName2 + "')/items?@target='" + hostUrl + "'";
        if (test) {
            console.log('Project Control Domain: ' + domain);
        }
        var rest_data = JSON.stringify({
            '__metadata': { 'type': 'SP.Data.' + listName2_metadata + 'ListItem' },
            'Title': passControlNumber,
            'IsCreateProjectLocked': 'Yes'
        });
        if (test) {
            console.log('REST: ' + rest_data);
        }
        // Add to list
        executor.executeAsync({
            url: domain,
            method: "POST",
            contentType: "application/json;odata=verbose",
            headers: { "content-type": "application/json; odata=verbose" },
            body: rest_data,
            success: function (data, status, headers, config) {

                if (test) {
                    console.log('SUCCESS: project item created');
                }

                // redirect to project information page
                redirectPage(number);
            },
            error: function (data, errorCode, errorMessage) {
                if (test) {
                    console.log('MESSAGE: ' + data.body);
                }

                if (data.body.search('[Project Reference]') >= 0) {
                    deleteProject(passControlNumber, (number + 1), passVar);
                } else {
                    deleteProject(passControlNumber, '', '');
                }
                    
                // remove project so there are replicated projects
                
            },
            state: "Add Project Control list Item"
        });
    }

    
    /* getting division property */
    function getReplacedUserArea(number, writer, userId, userName) {
        var domain = appUrl + "/_api/SP.UserProfiles.PeopleManager/GetUserProfilePropertyFor(accountName=@v,propertyName='Division')?@v='" + userName.split('|')[1] + "'";
        if (test) {
            console.log(domain);
        }
        $.ajax({
            url: domain,
            type: 'GET',
            headers: { 'Accept': 'application/json; odata=verbose' },
            success: function (data) {
                try {
                    //Get properties from user profile Json response
                    var Division = data.d.GetUserProfilePropertyFor;
                    addList(number, writer, userId, Division)
                } catch (err2) {
                    $('.error .error_msg').html('ERROR C: ' + JSON.stringify(err2) + '');
                    $('.error').removeClass('hidden');
                    $('#add-input').prop('disabled', false).html('Create New Project');
                    $('#cancel-input').prop('disabled', false);
                    // hide loading icon
                    $('.uploadLoading').addClass('hidden');
                }
            },
            error: function (jQxhr, errorCode, errorThrown) {
                $('.error .error_msg').html('ERROR D: ' + errorThrown + '');
                $('.error').removeClass('hidden');
                $('#add-input').prop('disabled', false).html('Create New Project');
                $('#cancel-input').prop('disabled', false);
                // hide loading icon
                $('.uploadLoading').addClass('hidden');
            }
        });
    }

    /* redirect logic */
    function redirectPage(number) {
        $.getScript(appUrl + '/_layouts/15/SP.RequestExecutor.js', execCrossDomainRequest2);

        // After the cross-domain library is loaded, execution 
        function execCrossDomainRequest2() {
            var executor = new SP.RequestExecutor(appUrl);
            var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items?$filter=Number eq '" + number + "'&@target='" + hostUrl + "'";
            if (test) {
                console.log(domain);
            }
            executor.executeAsync({
                url: domain,
                method: 'GET',
                headers: { 'Accept': 'application/json; odata=verbose' },
                success: function (data, status, headers, config) {
                    var body = jQuery.parseJSON(data.body);
                    var results = body.d.results;
                    var id;
                    var properties;
                    $.each(results, function (index, value) {
                        properties = results[index];
                        id = properties.Id;
                        if (test) {
                            console.log('ID: ' + id);
                        }
                        // display success message
                        $('.success').removeClass('hidden');
                        // redirect to edit page
                        //parent.document.location.href
                        window.top.location.href = hostUrl + '/Lists/' + listName + '/Item/editifs.aspx?ID=' + id + ''; //&IsDlg=1
                        //window.location = 'listform.aspx?PageType=6&ListId=%7B134E1225%2DC2C5%2D4F46%2D85F7%2D070D913E83F9%7D&ID=' + id;
                    });
                },
                error: function (data, errorCode, errorMessage) {
                    $('.error .error_msg').html('ERROR Getting ID: ' + errorMessage + '');
                    $('.error').removeClass('hidden');
                    $('#add-input').prop('disabled', false).html('Create New Project');
                    $('#cancel-input').prop('disabled', false);
                    // hide loading icon
                    $('.uploadLoading').addClass('hidden');
                },
                state: "Get List Data"
            });
        }
    }
}

// Get List Item Type metadata
function GetItemTypeForListName(name) {
    return "SP.Data." + name.charAt(0).toUpperCase() + name.split(" ").join("").slice(1) + "ListItem";
}

//  handle the query string
function getQueryStringParameter(paramToRetrieve) {
    var params =
        document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] == paramToRetrieve)
            return singleParam[1];
    }
}

function deleteProject(passControlNumber, number, passVar) {
    $.getScript(appUrl + '/_layouts/15/SP.RequestExecutor.js', execCrossDomainRequest);
    // After the cross-domain library is loaded, execution 
    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = '';
        if (passControlNumber.charAt(0) == 'C') {
            domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items?&$filter=CNumber eq '" + passControlNumber + "'&@target='" + hostUrl + "'";
        } else {
            domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items?&$filter=INumber eq '" + passControlNumber + "'&@target='" + hostUrl + "'";
        }
        if (test) {
            console.log(domain);
        }
        executor.executeAsync({
            url: domain,
            method: 'GET',
            headers: { 'Accept': 'application/json; odata=verbose' },
            success: function (data) {
                var body = jQuery.parseJSON(data.body);
                var results = body.d.results;
                var itemId = results[0].ID;
                $.getScript(appUrl + "/_layouts/15/SP.RequestExecutor.js", execCrossDomainRequest2);
                function execCrossDomainRequest2() {
                    var executor = new SP.RequestExecutor(appUrl);
                    var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items(" + itemId + ")?@target='" + hostUrl + "'";
                    if (test) {
                        console.log(domain);
                    }
                    executor.executeAsync({
                        url: domain,
                        method: 'POST',
                        contentType: 'application/json;odata=verbose',
                        headers: {
                            'IF-MATCH': '*',
                            'X-HTTP-Method': 'DELETE',
                            'content-type': 'application/json; odata=verbose'
                        },
                        success: function (data, status, headers, config) {
                           
                            if (number > 0) {
                                addListItem(passVar, number);
                            } else {
                                $('.error .error_msg').html('The App had an issue creating the project, please try again.');
                                $('.error').removeClass('hidden');
                                $('#add-input').prop('disabled', false).html('Create New Project');
                                $('#cancel-input').prop('disabled', false);
                                // hide loading icon
                                $('.uploadLoading').addClass('hidden');
                            }
                            
                        },
                        error: function (data, errorCode, errorMessage) {
                            $('.error .error_msg').html('Duplicate entries, please reload page and try again.');
                            $('.error').removeClass('hidden');
                            $('#add-input').prop('disabled', false).html('Create New Project');
                            $('#cancel-input').prop('disabled', false);
                            // hide loading icon
                            $('.uploadLoading').addClass('hidden');
                        },

                    });
                }
            },
            error: function (err) {
                console.log("error: " + JSON.stringify(err));
            }
        });
    }
}

function pad(num, size) {
    var s = '000000000' + num;
    return s.substr(s.length - size);
}

/* populate date into html */
function fillDate(htmlVar) {
    var d = new Date();
    var month = d.getMonth() + 1;
    month = (('' + month).length < 2 ? '0' : '') + month;
    var day = d.getDate();
    day = (('' + day).length < 2 ? '0' : '') + day;
    var year = d.getFullYear();
    var date = month + '/' + day + '/' + year
    if (htmlVar) {
        $(htmlVar).html(date);
    } else {
        return date;
    }

}


function getUrlParameters(parameter, staticURL, decode) {

    var currLocation = (staticURL.length) ? staticURL : window.location.search,
        parArr = currLocation.split("?")[1].split("&"),
        returnBool = true;

    for (var i = 0; i < parArr.length; i++) {
        parr = parArr[i].split("=");
        if (parr[0] == parameter) {
            return (decode) ? decodeURIComponent(parr[1]) : parr[1];
            returnBool = true;
        } else {
            returnBool = false;
        }
    }

    if (!returnBool) return false;
}