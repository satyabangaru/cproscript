﻿//'use strict';

// Get user variables
var context = SP.ClientContext.get_current();
var user = context.get_web().get_currentUser();

// Get the URI decoded URLs
var hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"))
var appUrl = decodeURIComponent(getQueryStringParameter("SPAppWebUrl"));

// Test list variables
var siteCol = 'AppDev';
var listName = 'Knockout Test';
var divName = '#kbvm_bb_model';
var passvalues = 'Title,Size';

// set defaults
var myItems = Backbone.Model.extend({
    defaults: {
        /* ----> add entries below ------------------------------------------------------------ */
        name: '',
        size: ''
    },
    initialize: function () {
        // add variables to data-binding
        this.on("add", function (model) {
            /* ----> add entries below ------------------------------------------------------------ */
            var name = model.get("name");
            var size = model.get("size");
        });
    }
});
viewItems = new Backbone.Collection();



// This code runs when the DOM is ready and creates a context object which is needed to use the SharePoint object model
$(function () {
    getUserName();

    // load itemlist backbone collection
    ItemList = Backbone.Collection.extend({
        initialize: function () {
            // 
        }
    });
    ItemView = Backbone.View.extend({
        tagName: 'li',
        events: {
            'click #add-input': 'getItem'
        },
        initialize: function () {
            var thisView = this;
            this.itemlist = new ItemList;
            _.bindAll(this, 'render');
            this.itemlist.bind("add", function (model) {
                thisView.render(model);
            })
        },
        getItem: function () {
            var item_Name = $('#input').val();
            var item_Name2 = $('#input2').val();
            this.itemlist.add({ name: item_Name, size: item_Name2 });
        },
        render: function (model) {
            // load values into model on render
            /*$("#item-list").append("<li>" +
               model.get("name") + "</li>");
            console.log('rendered')*/

            // add to sharepoint list
            var passVar1 = model.get("name");
            var passVar2 = model.get("size");
            var listName = 'Knockout Test';
            addListItem(hostUrl, appUrl, siteCol, listName, passVar1, passVar2);
        }
    });
    var view = new ItemView({ el: 'body' });

    // display list
    setHostVariables(hostUrl, appUrl, listName, passvalues);

});

/* adding item to sp list */
function addListItem(hostUrl, appUrl, siteCol, listName, titleVal, sizeVal) {
    var scriptbase = appUrl + "/_layouts/15/";
    $.getScript(scriptbase + "SP.RequestExecutor.js", execCrossDomainRequest);

    // After the cross-domain library is loaded, execution 
    // continues to this function. 


    //  SharePoint data
    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items?@target='" + hostUrl + "'";
        console.log(domain);
        //var itemType = GetItemTypeForListName(listName);
        var rest_data = JSON.stringify({
            '__metadata': { 'type': 'SP.Data.Knockout_x0020_TestListItem' },
            'Title': titleVal,
            'Size': sizeVal
        });

        executor.executeAsync(
            {
                url: domain,
                method: "POST",
                contentType: "application/json;odata=verbose",
                headers: { "content-type": "application/json; odata=verbose" },
                body: rest_data,
                success: successHandler_addlist,
                error: errorhandler_addlist
            }
        );
    }

    function successHandler_addlist(passVal, data, status, headers, config) {
        console.log(data);
        alert('success');
        createFolder(titleVal, siteCol);
    }
    function errorhandler_addlist(data, errorCode, errorMessage) {
        console.log("ERROR: " + errorMessage);
        alert(errorMessage);
    }

}

/*
copy/paste into browser to get type value in body
http://app-5ebab5f97a9eea.apps-sp-at.test.tiaa-cref.org/sites/AppDev/_api/web/lists('6942F7EB-864F-4007-8F33-790623D939DF')/listItemEntityTypeFullName
*/


// Success Handler
function successHandler(data, status, headers, config) {
    var body = jQuery.parseJSON(data.body);
    var results = body.d.results;
    var properties;
    var title;
    var size;
    $.each(results, function (index, value) {
        properties = results[index];
        /* ***** start list of variables ***** */

        /* ----> add entries below <------------------------------------------------------------ */
        title = properties.Title;
        size = properties.Size;

        /* ----> add items to array ------------------------------------------------------------ */
        var newItem = new myItems({ name: title, size: size });

        /* ***** end list of variables ***** */
        viewItems.push(newItem);

    });
    var view_model = {
        viewItems: kb.collectionObservable(viewItems, { view_model: kb.ViewModel })
    };
    ko.applyBindings(view_model, $(divName)[0])
}


function setHostVariables(hostweburl, appweburl, listname, passvalues) {
    var scriptbase = hostweburl + "/_layouts/15/";
    $.getScript(scriptbase + "SP.RequestExecutor.js", execCrossDomainRequest);

    //  SharePoint data
    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appweburl);
        var domain = appweburl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listname + "')/items?&$select=" + passvalues + "&@target='" + hostweburl + "'";
        //console.log(domain)
        executor.executeAsync(
            {
                url: domain,
                method: "GET",
                headers: { "Accept": "application/json; odata=verbose" },
                success: successHandler,
                error: errorhandler
            }
        );
    }
}
// handle the errors
function errorhandler(data, errorCode, errorMessage) {
    console.log("ERROR: " + errorMessage);
}

// Get List Item Type metadata
function GetItemTypeForListName(name) {
    return "SP.Data." + name.charAt(0).toUpperCase() + name.split(" ").join("").slice(1) + "ListItem";
}

//  handle the query string
function getQueryStringParameter(paramToRetrieve) {
    var params =
        document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] == paramToRetrieve)
            return singleParam[1];
    }
}

function createFolder(titleVal, siteCol) {
    var hostUrl;
    var appUrl;

    //Get the URI decoded URLs. 
    hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
    appUrl = decodeURIComponent(getQueryStringParameter("SPAppWebUrl"));

    var scriptbase = appUrl + "/_layouts/15/";
    $.getScript(scriptbase + "SP.RequestExecutor.js", execCrossDomainRequest);

    // After the cross-domain library is loaded, execution 
    // continues to this function. 


    //  SharePoint data
    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/Folders?@target='" + hostUrl + "'";
        var rest_data = "{ '__metadata': { 'type': 'SP.Folder' }, 'ServerRelativeUrl': '/sites/" + siteCol + "/Shared%20Documents1/" + titleVal + "'}"


        executor.executeAsync(
            {
                url: domain,
                method: "POST",
                contentType: "application/json;odata=verbose",
                headers: { "Accept": "application/json; odata=verbose", "content-type": "application/json; odata=verbose", "content-length": rest_data.length },
                body: rest_data,
                success: successHandler_folder,
                error: errorHandler_folder
            }
        );



    }

    function successHandler_folder() {
        alert('folder created');
    }

    function errorHandler_folder() {
        alert('folder NOT created');
    }
}



// This function prepares, loads, and then executes a SharePoint query to get the current users information
function getUserName() {
    context.load(user);
    context.executeQueryAsync(onGetUserNameSuccess, onGetUserNameFail);
}

// This function is executed if the above call is successful
// It replaces the contents of the 'message' element with the user name
function onGetUserNameSuccess() {
    $('#message').text('Hello ' + user.get_title());
}

// This function is executed if the above call fails
function onGetUserNameFail(sender, args) {
    alert('Failed to get user name. Error:' + args.get_message());
}




