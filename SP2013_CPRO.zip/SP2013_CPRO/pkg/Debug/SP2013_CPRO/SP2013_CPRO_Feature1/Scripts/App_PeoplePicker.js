﻿var hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
var enviro;
// get enviro
if (hostUrl.search('silver-sp-at.test.') >= 0) {
    enviro = 'uat';
} else if (hostUrl.search('silver-sp.') >= 0) {
    enviro = 'prod';
}
// default is VM 08's group Ids

function initializePeoplePicker(peoplePickerElementId, multiple, GroupName) {
    var GroupId;
    var schema = {};
    schema['PrincipalAccountType'] = 'User'; //User,DL,SecGroup,SPGroup
    schema['SearchPrincipalSource'] = 15;
    schema['ResolvePrincipalSource'] = 15;
    schema['Required'] = true,
    schema['MaximumEntitySuggestions'] = 5;
    if (multiple) {
        schema['AllowMultipleValues'] = true;
    } else {
        schema['AllowMultipleValues'] = false;
    }
    if (GroupName) {
        if (GroupName == 'CPRO Writers') {
            switch (enviro) {
                case "uat":
                    GroupId = '15';
                    break;
                case "prod":
                    GroupId = '30';
                    break;
                default:
                    GroupId = '9';
            }
        } else if (GroupName == 'CPRO MRU Group') {
            switch (enviro) {
                case "uat":
                    GroupId = '13';
                    break;
                case "prod":
                    GroupId = '28';
                    break;
                default:
                    GroupId = '10';
            }
        } else if (GroupName == 'CPRO Approvers') {
            switch (enviro) {
                case "uat":
                    GroupId = '12';
                    break;
                case "prod":
                    GroupId = '27';
                    break;
                default:
                    GroupId = '11';
            }
        }
        schema['SharePointGroupID'] = GroupId;
    }
    schema['Width'] = '100%';

    //init(peoplePickerDiv, schema);
    this.SPClientPeoplePicker_InitStandaloneControlWrapper(peoplePickerElementId, null, schema);

}

function getUsersInfo() {

    // Get the people picker object from the page.
    var peoplePicker = this.SPClientPeoplePicker.SPClientPeoplePickerDict.peoplePickerDiv_TopSpan;
    var arrayPeople = [];

    // Get information about selected users.
    var users = peoplePicker.GetAllUserInfo();

    for (var i = 0; i < users.length; i++) {

        var user = users[i];
        var filtereduser = $.grep(user_list, function (item, i) {
            return item.Name == user['Key'];
        });

        if (filtereduser.length > 0) {
            arrayPeople.push(filtereduser[0].Id)
        }

    }



    return arrayPeople;

}

document.onsubmit = function () {

    var getSelectedUsers = getUsersInfo();

};

function getAllUsers() {

    var userInfoList = context.get_site().get_rootWeb().get_siteUserInfoList();



    var camlQuery = new SP.CamlQuery();

    camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name=\'ID\' /></OrderBy></Query></View>');

    userListItemCollection = userInfoList.getItems(camlQuery);



    context.load(userListItemCollection);

    //context.load(userListItemCollection, 'Include(Title,ID,Name,EMail)');



    context.executeQueryAsync(onGetAllUsersSuccess, onGetAllUsersFail);

}

function onGetAllUsersSuccess() {

    var userArr = [];

    var arrNames = [];

    var listEnumerator = userListItemCollection.getEnumerator();



    while (listEnumerator.moveNext()) {

        var oList = listEnumerator.get_current();



        //avoid duplicates

        var index = $.inArray(oList.get_item('Title'), arrNames);

        if (index == -1) {

            userArr.push({

                Id: oList.get_item('ID'),

                Title: oList.get_item('Title'),

                Name: oList.get_item('Name'),

                EMail: oList.get_item('EMail')

            });

            arrNames.push(oList.get_item('Title'));

        }

    }



    user_list = userArr;

}

function onGetAllUsersFail(sender, args) {

    alert("Unable to load user information: " + args.get_message());

}

function getUsers() {

    var pUrl = _spPageContextInfo.webAbsoluteUrl + "/_api/site/rootweb/lists/getByTitle('User Information List')/items?$orderby=Id";

    //var pUrl = _spPageContextInfo.webAbsoluteUrl + "/_api/site/rootweb/lists/getByTitle('User Information List')/items?$orderby=Id&$select=Id,Title,Name,EMail";

    $.ajax(pUrl, { method: "GET", headers: { "accept": "application/json;odata=verbose" } }).done(storeUsers).fail(getUserError);

}

function storeUsers(data) {

    var responseParse = JSON.parse(data.body);

    user_list = responseParse.d.results;

}

function getUserError(jqXHR, textStatus) {

    alert(textStatus);

}

// This function prepares, loads, and then executes a SharePoint query to get the current users information
function getUserName() {
    context.load(user);
    context.executeQueryAsync(onGetUserNameSuccess, onGetUserNameFail);
}

// This function is executed if the above call is successful
// It replaces the contents of the 'message' element with the user name
function onGetUserNameSuccess() {
    $('#message').text('Hello ' + user.get_title());
}

// This function is executed if the above call fails
function onGetUserNameFail(sender, args) {
    alert('Failed to get user name. Error:' + args.get_message());
}

function loadPeoplePickerScripts(peoplePickerElementId, multiple, GroupId) {

    spHostUrl = decodeURIComponent(getQueryStringParameter('SPHostUrl'));
    appWebUrl = decodeURIComponent(getQueryStringParameter('SPAppWebUrl'));
    scriptBase = spHostUrl + '/_layouts/15/';

    if (spHostUrl != '') {
        //<script type="text/javascript" src="/_layouts/15/MicrosoftAjax.js"></script>
        //<script type="text/javascript" src="/_layouts/15/sp.core.js"></script>
        //<script type="text/javascript" src="/_layouts/15/sp.runtime.js"></script>
        //<script type="text/javascript" src="/_layouts/15/sp.js"></script>
        //'<script type="text/javascript" src="' + spHostUrl + '/_layouts/15/autofill.js"></script>'
        //'<script type="text/javascript" src="' + spHostUrl + '/_layouts/15/clientpeoplepicker.js"></script>'
        //'<script type="text/javascript" src="' + spHostUrl + '/_layouts/15/clientforms.js"></script>'
        //'<script type="text/javascript" src="' + spHostUrl + '/_layouts/15/clienttemplates.js"></script>'

        $.getScript(scriptBase + "MicrosoftAjax.js", function () {
            $.getScript(scriptBase + "sp.core.js", function () {
                $.getScript(scriptBase + "SP.Runtime.js", function () {
                    $.getScript(scriptBase + "SP.js", function () {

                        ExecuteOrDelayUntilScriptLoaded(function () { initializePeoplePicker(peoplePickerElementId, multiple, GroupId) }, 'clientpeoplepicker.js');

                    });
                });
            });

        });
    }


}

function getQueryStringParameter(paramToRetrieve) {
    var params =
        document.URL.split("?")[1].split("&");
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] == paramToRetrieve)
            return singleParam[1];
    }
}


function getScripts() {
    //var script = "<script type='text/javascript'>SP.SOD.registerSod('clientpeoplepicker.js', '/_layouts/15/clientpeoplepicker.js');</script>";
    //script += "<script type='text/javascript'>SP.SOD.registerSod('clientforms.js', '/_layouts/15/clientforms.js');</script>";
    //script += "<script type='text/javascript'>SP.SOD.registerSod('autofill.js', '/_layouts/15/autofill.js');</script>";
    //script += "<script type='text/javascript'>ExecuteOrDelayUntilScriptLoaded(initializePeoplePicker, 'clientpeoplepicker.js');</script>";
    //document.write(script);
}

$(document).ready(function () {
    //loadPeoplePickerScripts(peoplePickerElementId, multiple, GroupId);
});
