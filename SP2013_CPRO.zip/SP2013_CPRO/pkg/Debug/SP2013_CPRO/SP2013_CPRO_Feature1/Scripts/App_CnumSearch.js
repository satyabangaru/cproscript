﻿var test = true;
// Get the URI decoded URLs
var hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
var appUrl = decodeURIComponent(getQueryStringParameter("SPAppWebUrl"));
var scriptbase = appUrl + '/_layouts/15/';
// Define the folder path  
var docPath = 'CPRO Documents';
var listName = 'Compliance PRO List';
var listName_metadata = listName.replace(/\ /g, '_x0020_');
var searchtype='';
var displayLimit = 20;
var currentContext = new SP.ClientContext.get_current();
// disable test if URL has TEST in url = UAT
if (hostUrl.search('silver-sp-at.test.') >= 0) {
    // uat
    test = false; // disable console.log display
} else if (hostUrl.search('silver-sp.') >= 0) {
    // production
    test = false; // disable console.log display
}

$(function () {
    $('#searchTextBox').focus();
    $("#searchTextBox").keyup(function (event) {
        if (event.keyCode == 13) {
            search(1);
        }
    });
});

// on button submit
function search(page) {
    $('#CnumSearchDiv .error, #CnumSearchDiv .notice').addClass('hidden');
    $('#dis_projects').html('');
    $('#CnumSearchDiv .uploadLoading').removeClass('hidden'); // display loading graphic
    $('#searchButton').prop('disabled', true); // disable button when searching
    getProject(page);
    
}

function getProject(page) {

    var cNumber = $('#searchTextBox').val();
    var filter = '';
    // check for c and i numbers
    var cOrI = cNumber.slice(0,1).toLowerCase();
    var remaining = cNumber.slice(1,9999);
    if (cOrI == 'c') {
        filter = "substringof('" + cOrI + "',CNumber) and substringof('" + remaining + "', CNumber)";
    } else if (cOrI == 'i') {
        filter = "substringof('" + cOrI + "',INumber) and substringof('" + remaining + "', INumber)";
    }else{
        filter = "substringof('" + cNumber + "',CNumber) or substringof('" + cNumber + "', INumber)";
    }

    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });

    function execCrossDomainRequest() {

        var executor;
        executor = new SP.RequestExecutor(appUrl);        

        var queryUrl = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items?$select=Title,CNumber,INumber,ID,EncodedAbsUrl&$filter=" + filter + "&$top=" + displayLimit + "&$orderby=Number asc&@target='" + hostUrl + "'";
        if (test) {
            console.log(queryUrl);
        }
        executor.executeAsync(
            {
                url: queryUrl,
                method: "GET",
                headers: {
                    "accept": "application/json;odata=verbose",
                    "X-RequestDigest": jQuery("#__REQUESTDIGEST").val()
                },
                success: projectSuccessHandler,
                error: projecterrorHandler
            }
        );
    }
    function projectSuccessHandler(data) {       
        var jsonObject = JSON.parse(data.body);
        var results = jsonObject.d.results;
        if (results.length > 0) {
            displayNumber(results);
        } else {
            // error message
            $('#CnumSearchDiv .error .error_msg').html('Project for this C/I Number "' + cNumber + '" does not exist');
            $('#CnumSearchDiv .error').removeClass('hidden');
            $('#dis_projects').html('');
            // reset
            $('#searchButton').prop('disabled', false); // enable search button
            $('#CnumSearchDiv .uploadLoading').addClass('hidden'); // hidden loading icon
        }
    }

    function projecterrorHandler(data, errorCode, errorMessage) {
        console.log(data + ' >> ' + errorCode + ' >> ' + errorMessage);
    }    
}


function displayNumber(results) {

    var name = '';
    var projectname = '';
    var url = '';
    

    var addItem = '<div class="row" style="font-size:.9em;font-weight:bold;">' +
                '<div class="col-xs-2">Control Number</div>' +
                '<div class="col-xs-10">Project Name</div>' +
            '</div>';
    $('#dis_projects').append(addItem);


    for (i = 0; i < results.length; i++) {

        if (results[i].CNumber != null && results[i].CNumber) {
            name = results[i].CNumber;
        } else if (results[i].INumber != null && results[i].INumber) {
            name = results[i].INumber;
        }
        var IDVal = results[i].ID;
        var url = hostUrl + '/Lists/' + listName + '/Item/editifs.aspx?ID=' + IDVal;
        projectname = results[i].Title;

        // check if folder exists
        var docLink = '';
        var documentPath = hostUrl + '/' + docPath + '/' + name + '/';

        checkFolder(name, projectname, url);


        
    }
}

function checkFolder(name, projectname, url) {

    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });

    function execCrossDomainRequest() {
        var executor;
        executor = new SP.RequestExecutor(appUrl);
        var queryUrl = appUrl + "/_api/SP.AppContextSite(@target)/web/getfolderbyserverrelativeurl('" + docPath + "')/Folders?$select=Name&$filter=substringof('" + name + "',Name)&$top=1&skip=0&@target='" + hostUrl + "'";
        if (test) {
            console.log(queryUrl);
        }
        executor.executeAsync(
            {
                url: queryUrl,
                method: "GET",
                headers: {
                    "accept": "application/json;odata=verbose",
                    "X-RequestDigest": jQuery("#__REQUESTDIGEST").val()
                },
                success: SuccessHandler,
                error: errorHandler
            }
        );
    }
    function SuccessHandler(data) {
        var documentPath = hostUrl + '/' + docPath + '/' + name + '/';
        var docLink = '';

        var jsonObject = JSON.parse(data.body);
        var results = jsonObject.d.results;
        if (results.length > 0) {
            docLink = '<a href="' + documentPath + '" id="" target="_blank"><span class="glyphicon glyphicon-paperclip" aria-hidden="true" /></a>';
        } else {
            docLink = '<span class="glyphicon glyphicon-paperclip" aria-hidden="true" />';
        }

        

        addItem = '<div class="row row-top">' +
                '<div class="col-xs-2">' + docLink + '&nbsp; ' +
                    '<a href="' + url + '" id="" target="_blank">' + name + '</a></div>' +
                '<div class="col-xs-10"><a href="' + url + '" id="" target="_blank">' + projectname + '</a></div>' +
            '</div>';
        $('#dis_projects').append(addItem);

        pagination();

        // reset
        $('#searchButton').prop('disabled', false); // enable search button
        $('#CnumSearchDiv .uploadLoading').addClass('hidden'); // hidden loading icon


    }

    function errorHandler(data, errorCode, errorMessage) {
        
    }

}
function pagination() {
    var cNumber = $('#searchTextBox').val();

    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });

    function execCrossDomainRequest() {

        var executor;
        executor = new SP.RequestExecutor(appUrl);

        var queryUrl = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items?$select=CNumber,INumber&$filter=substringof('" + cNumber + "',CNumber) or substringof('" + cNumber + "',INumber)&@target='" + hostUrl + "'";
        if (test) {
            console.log(queryUrl);
        }
        executor.executeAsync(
            {
                url: queryUrl,
                method: "GET",
                headers: {
                    "accept": "application/json;odata=verbose",
                    "X-RequestDigest": jQuery("#__REQUESTDIGEST").val()
                },
                success: SuccessHandler,
                error: errorHandler
            }
        );
    }
    function SuccessHandler(data) {
        var jsonObject = JSON.parse(data.body);
        var results = jsonObject.d.results;
        var resultsCount = results.length;
        var totalPages = resultsCount / displayLimit;

        if (resultsCount > displayLimit) {
            $('.notice').removeClass('hidden');
            $('.notice .notice_msg').html('Search returned more than 20 results, please narrow your search.')
            /*
            $('#pagination').removeClass('hidden');
            var addPages = '';
            for (var i = 1; i <= totalPages; i ++) {
                addPages += '<li><a href="#" data-page="' + i + '">' + i + '</a></li>';
            }
            $(addPages).insertAfter('.p_prev');
            // enable onclick
            $(document).on('click', 'ul.pagination > li > a', function () {
                var dataPage = $(this).data('page');
                getProject(dataPage);
            });
            */
        }
    }

    function errorHandler(data, errorCode, errorMessage) {
        console.log(data + ' >> ' + errorCode + ' >> ' + errorMessage);
    }
}
function Clear() {
    $('#searchTextBox').val('');
    $('#dis_projects, #dis_documents').empty();
    $('#CnumSearchDiv .error').addClass('hidden');
    $('#searchButton').prop('disabled', false); // enable search button
    // focus
    $('#searchTextBox').focus();
}
//  handle the query string
function getQueryStringParameter(paramToRetrieve) {
    var params =
        document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] == paramToRetrieve)
            return singleParam[1];
    }
}
