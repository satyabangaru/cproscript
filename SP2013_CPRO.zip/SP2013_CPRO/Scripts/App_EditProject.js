﻿//'use strict';
/*
// get id from webpart properties
var sProp = decodeURIComponent(getQueryStringParameter("passID"));
if (test) {
    console.log('ID from Web Part: ' + sProp);
}
*/

var validatedFiles = [];
var myData = [];
var availableTags = [];
var checkItem = false;
var submitterKey = '';
var discontinueStatus = '';
var isAdmin = false;
var filingStates_Update = [];

// Get user variables
var context = SP.ClientContext.get_current();
//var user = context.get_web().get_currentUser();
// Get the URI decoded URLs
var hostUrl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
var hostSite = hostUrl.replace('/sites', '').replace('/cpro', '');
//var hostUrl = decodeURIComponent('http://' + document.referrer.split('/')[2] + '/sites/cpro');
var appUrl = decodeURIComponent(getQueryStringParameter("SPAppWebUrl"));
//appUrl = appUrl.replace(':82', '');
var siteCol = _spPageContextInfo.webServerRelativeUrl.split('/')[2];
var scriptbase = appUrl + '/_layouts/15/';
// item ID from URL
var full_url = document.referrer; // Get url from form action, which includes the ID of the modal window opened
var idParameter = getUrlParameters("ID", full_url, true); // get ID
Sys.Application.add_load(wireEvents);

var serviceUrl = 'http://dendvb3swsdc08.cloud.tiaa-cref.org:7001'; // for VM 08 testing - document upload
//var serviceUrl = 'http://dendvb3swsdc16.cloud.tiaa-cref.org:7001'; // for VM 16 testing - document upload

var test = false;
// display test value based on url value
var checkDebug = getUrlParameters("debug", full_url, true); 
if (checkDebug) {
    test = true;
}

// domain adjustments
if (hostUrl.search('silver-sp-at.test.') >= 0) {
    // uat
    serviceUrl = 'http://dendvb3prpps01.cloud.tiaa-cref.org:7001'; // document upload
} else if (hostUrl.search('silver-sp.') >= 0) {
    // production
    serviceUrl = 'http://chapdc3ptpps01.ad.tiaa-cref.org:7001';  // document upload 
}

// check for local storage
var localStorageCheck = '';
if (('localStorage' in window) && window.localStorage !== null) {
    localStorageCheck = 'y';
    if (test) {
        console.log('Local Storage Available')
    }
    // resest localstorage every day
    var today = new Date();
    var month = today.getUTCMonth() + 1; //months from 1-12
    var day = today.getUTCDate();
    var year = today.getUTCFullYear();
    today = day + "/" + month + "/" + year;
    if (localStorage.getItem('date') != null) {
        if (localStorage.getItem('date') == today) {
            // check for url variable and force Local Storage Clear
            var checkLocal = getUrlParameters("local", full_url, true); 
            if (checkLocal) {
                window.localStorage.clear();
            }
        } else {
            window.localStorage.clear();
        }
    } else {
        localStorage.setItem('date', today);
    }
}

// Define lists
var listName = 'Compliance PRO List';
var listName_metadata = listName.replace(/\ /g, '_x0020_');
var listName2 = 'CPRO Project Control List';
var listName2_metadata = listName2.replace(/\ /g, '_x0020_');
var StateFilingList = 'CPRO State Filing';
var StateFilingList_metadata = StateFilingList.replace(/\ /g, '_x0020_');
var projControlNotificationList = 'Project Control Notifications';
var projControlNotificationList_metadata = projControlNotificationList.replace(/\ /g, '_x0020_');
var docPath = 'CPRO Documents';

// set defaults
var myItems = Backbone.Model.extend({
    defaults: {},
    initialize: function () {
        // add variables to data-binding
        this.on("add", function (model) {
        });
    }
});

var viewItems = new Backbone.Collection();
var view_model = '';

// This code runs when the DOM is ready and creates a context object which is needed to use the SharePoint object model
$(function () {
    
    if (idParameter) {

        // disable all
        $('input, select, textarea, button').prop('disabled', true);
        $('button#cancel-A-input, button#cancel-B-input, button#cancel-C-input, button#cancel-C2-input, button#cancel-D-input, button#cancel-E-input, button#cancel-F-input, button#upload-F-input, select#fileDocType, #sectionH textarea, #sectionH button, #sectionH select, #sectionG textarea').prop('disabled', false);
        $('.replaceUser, .peoplepicker').addClass('hidden');

        // reveal test divs
        if (test) {
            $('.testAlert').removeClass('hidden');
        }
        //add link next to Audience dropdown
        var url = hostUrl + '/Pages/Audience.aspx';
        var text = "Info";
        //$('#divAudience').after('<a href="' + url + '" target="_blank" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span></a>');
        $('.Audience_label').after(' <a href="' + url + '" target="_blank" style="text-decoration:none;"><span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span></a>');


        // fill dropdown menus
        fillLookups();

        // add required symbol for required fields
        $('input, select, div, textarea').each(function () {
            if ($(this).data('validate') != null) {
                // add required icon to field
                $(this).addClass('requiredText');
                // add class to previous div
                $(this).parent().prev('.col-xs-4').addClass('requiredCell');
            }
        });

        // load itemlist backbone collection
        ItemList = Backbone.Collection.extend({
            initialize: function () {
                // 
            }
        });
        ItemView = Backbone.View.extend({
            tagName: '',
            events: {
                'click #save-A-input': 'editproject',
                'click #submit-A-input': 'submitproject',
                'click #save-B-input': 'editreview',
                'click #submit-B-input': 'submitreview',
                'click #save-C-input': 'editrevision',
                'click #submit-C-input': 'submitrevision',
                'click #save-C2-input': 'editapproval',
                'click #submit-C2-input': 'submitapproval',
                'click #save-D-input': 'editfinra',
                'click #submit-D-input': 'submitfinra',
                'click #save-E-input': 'editstate',
                'click #submit-E-input': 'submitstate',
                'click #unlock-H-input': 'unlock',
                'click #discontinue-H-input': 'discontinue'
            },
            initialize: function () {
                var thisView = this;
                this.itemlist = new ItemList;
                _.bindAll(this, 'render');
                this.itemlist.bind("add", function (model) {
                    thisView.render(model);
                })
            },
            editproject: function () {
                editList('project');
            },
            submitproject: function () {
                // reveal loading icon
                $('#sectionA .uploadLoading').removeClass('hidden');
                // hide success message
                $('#sectionA .success').addClass('hidden');
                // change buttons
                $('#submit-A-input, #save-A-input, #cancel-A-input').prop('disabled', true);
                $('#submit-A-input').html('Submitting...');

                setControlID('project'); // get list id, then submit
            },
            editreview: function () {
                editList('review');
            },
            submitreview: function () {
                // reveal loading icon
                $('#sectionB .uploadLoading').removeClass('hidden');
                // hide success message
                $('#sectionB .success').addClass('hidden');
                // change buttons
                $('#submit-B-input, #save-B-input, #cancel-B-input').prop('disabled', true);
                $('#submit-B-input').html('Submitting...');

                setControlID('review'); // get list id, then submit
            },
            editrevision: function () {
                editList('revision');
            },
            submitrevision: function () {
                // reveal loading icon
                $('#sectionC .uploadLoading').removeClass('hidden');
                // hide success message
                $('#sectionC .success').addClass('hidden');
                // change buttons
                $('#submit-C-input, #save-C-input, #cancel-C-input').prop('disabled', true);
                $('#submit-C-input').html('Submitting...');

                setControlID('revision'); // get list id, then submit
            },
            editapproval: function () {
                editList('approval');
            },
            submitapproval: function () {
                // reveal loading icon
                $('#sectionC2 .uploadLoading').removeClass('hidden');
                // hide success message
                $('#sectionC2 .success').addClass('hidden');
                // change buttons
                $('#submit-C2-input, #save-C2-input, #cancel-C2-input').prop('disabled', true);
                $('#submit-C2-input').html('Submitting...');

                setControlID('approval'); // get list id, then submit
            },
            editfinra: function () {
                editList('finra');
            },
            submitfinra: function () {
                // reveal loading icon
                $('#sectionD .uploadLoading').removeClass('hidden');
                // hide success message
                $('#sectionD .success').addClass('hidden');
                // change buttons
                $('#submit-D-input, #save-D-input, #cancel-D-input').prop('disabled', true);
                $('#submit-D-input').html('Submitting...');

                setControlID('finra'); // get list id, then submit
            },
            editstate: function () {
                editList('state');
            },
            submitstate: function () {
                // reveal loading icon
                $('#sectionE .uploadLoading').removeClass('hidden');
                // hide success message
                $('#sectionE .success').addClass('hidden');
                // change buttons
                $('#submit-E-input, #save-E-input, #cancel-E-input').prop('disabled', true);
                $('#submit-CE2-input').html('Submitting...');

                setControlID('state'); // get list id, then submit
            },
            unlock: function () {                
                var section = 'section_h1';
                // disable unlock button
                $('#unlock-H-input').prop('disabled', true);
                // hide error message
                $('#' + section + ' .error, #' + section + ' span.validation').addClass('hidden');
                // show loading graphic
                $('#' + section + ' .uploadLoading').removeClass('hidden');
                // hide success message
                $('#' + section + ' .success').addClass('hidden');

                if (validation(section) == 'no') {                    
                    saveProjectControlInfo(section, 'unlock'); 
                } else {
                    $('#unlock-H-input').prop('disabled', false);
                    // hide loading graphic
                    $('#' + section + ' .uploadLoading').addClass('hidden');
                    // error message
                    $('#' + section + ' .error .error_msg').html('Validation failed');
                    $('#' + section + ' .error').removeClass('hidden');
                }

            },
            discontinue: function () {
                var section = 'section_h2';
                //disable discontinue button
                $('#discontinue-H-input').prop('disabled', true);
                // hide error message
                $('#' + section + ' .error, #' + section + ' span.validation').addClass('hidden');
                // show loading graphic
                $('#' + section + ' .uploadLoading').removeClass('hidden');
                // hide success message
                $('#' + section + ' .success').addClass('hidden');

                if (validation(section) == 'no') {
                    saveProjectControlInfo(section, 'discontinue');
                } else {
                    $('#discontinue-H-input').prop('disabled', false);
                    // hide loading graphic
                    $('#' + section + ' .uploadLoading').addClass('hidden');
                    // error message
                    $('#' + section + ' .error .error_msg').html('Validation failed');
                    $('#' + section + ' .error').removeClass('hidden');
                }
            },
            render: function (model) {

            }
        });
        var view = new ItemView({ el: 'body' });

    } else {
        console.log('ID Not Found');
        $('.loading-container .messaging h1').html('Error: ID Not Found');
        $('.loading-container .messaging').css('background', 'none');
    }

});


function setWorkflowStatus(discontinueStatus) {
    var discontinuestatus = discontinueStatus;
    var controlNumber = $('span.controlNumber').html(); // get control # 
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });
    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName2 + "')/items?$filter=Title eq '" + controlNumber + "'&@target='" + hostUrl + "'";
        if (test) {
            console.log('Get Workflow');
            console.log(domain);
        }
        executor.executeAsync({
            url: domain,
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: function (data, status, headers, config) {
                var body = jQuery.parseJSON(data.body);
                var results = body.d.results;
                var workflowStatus = '';
                $.each(results, function (index, value) {
                    workflowStatus = 'Info';
                    var section;
                    var properties = results[index];

                    var IsCreateProjectLocked = properties.IsCreateProjectLocked;
                    var IsProjectInformationLocked = properties.IsProjectInformationLocked;
                    var IsComplianceReviewLocked = properties.IsComplianceReviewLocked;
                    var IsCheckedLocked = properties.IsCheckedLocked;
                    var IsApprovalLocked = properties.IsApprovalLocked;
                    var IsFINRALocked = properties.IsFINRALocked;
                    var IsStateFilingLocked = properties.IsStateFilingLocked;
                    var discontinue = $('.projectDiscontinued_dis').text();

                    // display discontinued reason
                    if (discontinuestatus == 'discontinued') {
                        $('#DivdiscontinueReason').removeClass('hidden');
                    }

                    /////////////////////////// 
                    /// PROJECT INFORMATION ///
                    ///////////////////////////
                    if (IsProjectInformationLocked == 'Yes' || IsProjectInformationLocked == 'Reset' || discontinuestatus == 'discontinued') {
                        section = 'sectionA';
                        // enable tabs
                        $('#reviewTab').removeClass('disabled');
                        $('#reviewTab a').attr('data-toggle', 'tab');
                        // disable fields
                        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea').prop('disabled', true);
                        $('#' + section + ' .multiselect').addClass('disable_ms'); // disable UI by default
                        // hide People Picker replace 
                        $('#' + section + ' .replaceUser').addClass('hidden');
                        $('#' + section + ' .peoplepicker').addClass('hidden');
                        // set buttons
                        $('#save-A-input, #submit-A-input').prop('disabled', true);
                    } else if (IsProjectInformationLocked == 'No') {
                        // enable tabs
                        $('#reviewTab').removeClass('disabled');
                        $('#reviewTab a').attr('data-toggle', 'tab');
                        // if unlocked
                        $('#ProjectInformationStatus').prev().removeClass('glyphicon-ok-sign').addClass('glyphicon-plus-sign');
                        $('#ProjectInformationStatus').closest('.alert-success').removeClass('alert-success').addClass('alert-info');
                        $('#ProjectInformationStatus').text('Unlocked');
                        $('#infoTab').children().children().removeClass('glyphicon-lock').addClass('glyphicon-check');
                        $('#unlock-A').addClass('hidden');
                    }
                    // delete permissions
                    if ((IsProjectInformationLocked == 'No' || IsProjectInformationLocked == '' || IsProjectInformationLocked == null) && (discontinue == '' || discontinue == null || (typeof discontinue == 'undefined'))) {
                        // reveal delete by permissions // 
                        if ($('.currentUserGroup').html().search('CPRO Writers') >= 0) {
                            $('.documents_display_draft .delete').removeClass('hidden');
                        }
                    } 

                    /////////////////////////
                    /// COMPLIANCE REVIEW ///
                    /////////////////////////
                    if (IsComplianceReviewLocked == 'Yes' || IsComplianceReviewLocked == 'Reset' || discontinuestatus == 'discontinued') {
                        section = 'sectionB';
                        // enable tabs
                        $('#revisionTab').removeClass('disabled');
                        $('#revisionTab a').attr('data-toggle', 'tab');
                        // disable fields
                        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea').prop('disabled', true);
                        $('#' + section + ' .multiselect').addClass('disable_ms'); // disable UI by default
                        // hide People Picker replace 
                        $('#' + section + ' .replaceUser').addClass('hidden');
                        $('#' + section + ' .peoplepicker').addClass('hidden');
                        // set buttons
                        $('#save-B-input, #submit-B-input').prop('disabled', true);
                    } else if (IsComplianceReviewLocked == 'No') {
                        // enable tabs
                        $('#revisionTab').removeClass('disabled');
                        $('#revisionTab a').attr('data-toggle', 'tab');
                        // if unlocked
                        $('#ComplianceReviewStatus').prev().removeClass('glyphicon-ok-sign').addClass('glyphicon-plus-sign');
                        $('#ComplianceReviewStatus').closest('.alert-success').removeClass('alert-success').addClass('alert-info');
                        $('#ComplianceReviewStatus').text('Unlocked');
                        $('#reviewTab').children().children().removeClass('glyphicon-lock').addClass('glyphicon-check');
                        $('#unlock-B').addClass('hidden');
                    }

                    ////////////////
                    /// REVISION ///
                    ////////////////
                    if (IsCheckedLocked == 'Yes' || IsCheckedLocked == 'Reset' || discontinuestatus == 'discontinued') {
                        section = 'sectionC';
                        // enable tabs
                        $('#ApprovalTab').removeClass('disabled');
                        $('#ApprovalTab a').attr('data-toggle', 'tab');
                        // disable fields
                        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea').prop('disabled', true);
                        $('#' + section + ' .multiselect').addClass('disable_ms'); // disable UI by default
                        // hide People Picker replace 
                        $('#' + section + ' .replaceUser').addClass('hidden');
                        $('#' + section + ' .peoplepicker').addClass('hidden');
                        // set buttons
                        $('#save-C-input, #submit-C-input').prop('disabled', true);
                    } else if (IsCheckedLocked == 'No') {
                        // enable tabs
                        $('#ApprovalTab').removeClass('disabled');
                        $('#ApprovalTab a').attr('data-toggle', 'tab');
                        // if unlocked
                        $('#RevisionStatus').prev().removeClass('glyphicon-ok-sign').addClass('glyphicon-plus-sign');
                        $('#RevisionStatus').closest('.alert-success').removeClass('alert-success').addClass('alert-info');
                        $('#RevisionStatus').text('Unlocked');
                        $('#revisionTab').children().children().removeClass('glyphicon-lock').addClass('glyphicon-check');
                        $('#unlock-C').addClass('hidden');
                    }
                    // delete permissions
                    if ((IsCheckedLocked == 'No' || IsCheckedLocked == '' || IsCheckedLocked == null) && (discontinue == '' || discontinue == null || (typeof discontinue == 'undefined'))) {
                        // reveal delete by permissions // 
                        if ($('.currentUserGroup').html().search('CPRO Writers') >= 0) {
                            $('.documents_display_approved a.delete').removeClass('hidden');
                        }
                    } 

                    ////////////////
                    /// APPROVAL ///
                    ////////////////
                    if (IsApprovalLocked == 'Yes' || IsApprovalLocked == 'Reset' || discontinuestatus == 'discontinued') {
                        section = 'sectionC2';
                        // enable tabs
                        if ($('#FINRAFilingStatus').html() && $('#FINRAFilingStatus').html() != 'N/A') {
                            $('#FINRATab').removeClass('disabled');
                            $('#FINRATab a').attr('data-toggle', 'tab');
                        }
                        if ($('#StateFilingStatus').html() && $('#StateFilingStatus').html() != 'N/A') {
                            $('#stateTab').removeClass('disabled');
                            $('#stateTab a').attr('data-toggle', 'tab');
                        }
                        // disable fields
                        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea').prop('disabled', true);
                        $('#' + section + ' .multiselect').addClass('disable_ms'); // disable UI by default
                        // hide People Picker replace 
                        $('#' + section + ' .replaceUser').addClass('hidden');
                        $('#' + section + ' .peoplepicker').addClass('hidden');
                        // set buttons
                        $('#save-C2-input, #submit-C2-input').prop('disabled', true);
                    } else if (IsApprovalLocked == 'No') {
                        // enable tabs
                        if ($('#FINRAFilingStatus').html() && $('#FINRAFilingStatus').html() != 'N/A') {
                            $('#FINRATab').removeClass('disabled');
                            $('#FINRATab a').attr('data-toggle', 'tab');
                        }
                        if ($('#StateFilingStatus').html() && $('#StateFilingStatus').html() != 'N/A') {
                            $('#stateTab').removeClass('disabled');
                            $('#stateTab a').attr('data-toggle', 'tab');
                        }
                        // if unlocked
                        $('#ApprovalStatus').prev().removeClass('glyphicon-ok-sign').addClass('glyphicon-plus-sign');
                        $('#ApprovalStatus').closest('.alert-success').removeClass('alert-success').addClass('alert-info');
                        $('#ApprovalStatus').text('Unlocked');
                        $('#ApprovalTab').children().children().removeClass('glyphicon-lock').addClass('glyphicon-check');
                        $('#unlock-C2').addClass('hidden');
                        $('#ApprovalDate').val(now());
                    }
                    // delete permissions
                    if ((IsApprovalLocked == 'No' || IsApprovalLocked == '' || IsApprovalLocked == null) && (discontinue == '' || discontinue == null || (typeof discontinue == 'undefined'))) {
                        
                        // reveal delete by permissions // 
                        if ($('.currentUserGroup').html().search('CPRO Approvers') >= 0) {
                            $('.documents_display_approved a.delete').removeClass('hidden');
                        }
                    } 
                    // check if current user is approving manager
                    if ($('span#CurrentUser').text() && $('.display_ApprovingManager span.name').text()) {
                        if ($('span#CurrentUser').text().split(',')[0] == $('.display_ApprovingManager span.name').text().split(',')[0] || $('.currentUserGroup').html().search('CPRO Administrators') >= 0) {
                            
                        } else {
                            $('#save-C2-input, #submit-C2-input').prop('disabled', true);
                            $('#sectionC2 .notice.alert .notice_msg').html('You have not been selected as the Approving Manager for this project');
                            $('#sectionC2 .notice.alert').removeClass('hidden');
                            // disable Approved document deletion
                            $('.documents_display_approved a.delete').addClass('hidden');
                        }
                    }

                    /////////////
                    /// FINRA ///
                    /////////////
                    if (IsFINRALocked == 'Yes' || IsFINRALocked == 'Reset' || discontinuestatus == 'discontinued') {
                        section = 'sectionD';
                        // disable fields
                        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea').prop('disabled', true);
                        $('#' + section + ' .multiselect').addClass('disable_ms'); // disable UI by default
                        // hide People Picker replace 
                        $('#' + section + ' .replaceUser').addClass('hidden');
                        $('#' + section + ' .peoplepicker').addClass('hidden');
                        // set buttons
                        $('#save-D-input, #submit-D-input').prop('disabled', true);
                    } else if (IsFINRALocked == 'No') {
                        // if unlocked
                        $('#FINRAFilingStatus').prev().removeClass('glyphicon-ok-sign').addClass('glyphicon-plus-sign');
                        $('#FINRAFilingStatus').closest('.alert-success').removeClass('alert-success').addClass('alert-info');
                        $('#FINRAFilingStatus').text('Unlocked');
                        $('#FINRATab').children().children().removeClass('glyphicon-lock').addClass('glyphicon-check');
                        $('#unlock-D').addClass('hidden');
                    }
                    // delete permissions
                    if ((IsFINRALocked == 'No' || IsFINRALocked == '' || IsFINRALocked == null) && (discontinue == '' || discontinue == null || (typeof discontinue == 'undefined'))) {
                        // reveal delete by permissions // 
                        if ($('.currentUserGroup').html().search('CPRO MRU Group') >= 0) {
                            $('.documents_display_approved a.delete').removeClass('hidden');
                        }
                    }
                
                    /////////////
                    /// STATE ///
                    /////////////
                    if (IsStateFilingLocked == 'Yes' || IsStateFilingLocked == 'Reset' || discontinuestatus == 'discontinued') {
                        section = 'sectionE';
                        // disable fields
                        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea').prop('disabled', true);
                        $('#' + section + ' .multiselect').addClass('disable_ms'); // disable UI by default
                        // hide People Picker replace 
                        $('#' + section + ' .replaceUser').addClass('hidden');
                        $('#' + section + ' .peoplepicker').addClass('hidden');
                        // set buttons
                        $('#save-E-input, #submit-E-input').prop('disabled', true);
                    } else if (IsStateFilingLocked == 'No') {
                        // if unlocked
                        $('#StateFilingStatus').prev().removeClass('glyphicon-ok-sign').addClass('glyphicon-plus-sign');
                        $('#StateFilingStatus').closest('.alert-success').removeClass('alert-success').addClass('alert-info');
                        $('#StateFilingStatus').text('Unlocked');
                        $('#stateTab').children().children().removeClass('glyphicon-lock').addClass('glyphicon-check');
                        $('#unlock-E').addClass('hidden');
                    }
                    // delete permissions
                    if ((IsStateFilingLocked == 'No' || IsStateFilingLocked == '' || IsStateFilingLocked == null) && (discontinue == '' || discontinue == null || (typeof discontinue == 'undefined'))) {
                        // reveal delete by permissions // 
                        if ($('.currentUserGroup').html().search('CPRO MRU Group') >= 0) {
                            $('.documents_display_approved a.delete').removeClass('hidden');
                        }
                    }
                    var action = '';
                    getStateFilingDetails(action);

                    ////////////////////
                    /// ADMIN RIGHTS ///
                    ////////////////////
                    if (($('.currentUserGroup').html().search('CPRO Administrators') >= 0) && (discontinue == '' || discontinue == null || (typeof discontinue == 'undefined'))) {
                        // admin can always delete
                        $('.documents_display_draft a.delete, .documents_display_final a.delete, .documents_display_approved a.delete').removeClass('hidden');
                    }

                    ///////////////////////////////
                    /// FILE UPLOAD PERMISSIONS ///
                    ///////////////////////////////
                    if ((IsProjectInformationLocked == 'Yes' || IsProjectInformationLocked == 'Reset') && (IsComplianceReviewLocked == 'Yes' || IsComplianceReviewLocked == 'Reset')) {
                        // disable DRAFT upload
                        $('#sectionF select#fileDocType option:contains("Draft")').attr('disabled', true);
                        $('#sectionF input[value="Draft"]').attr('disabled', 'disabled');
                        $('#sectionF ul li:nth-child(2)').addClass('disabled');
                    }

                    //////////////////////
                    /// SET ACTIVE TAB ///
                    //////////////////////
                    var currentActive = '';
                    // set focus
                    $('#projectName').focus();

                    if (discontinuestatus == 'discontinued') {
                        $('#infoTab').removeClass('active');
                        $('#sectionA').removeClass('in active');
                        /**** set STATUS tab ****/
                        $('#sectionG').addClass('in active');
                        currentActive = 'G';
                        $('#statusTab').addClass('active');
                        //adjustTabIcons();
                        // disable all tab controls
                        $('input, select, textarea, button').prop('disabled', true);
                        $('button#cancel-A-input, button#cancel-B-input, button#cancel-C-input, button#cancel-C2-input, button#cancel-D-input, button#cancel-E-input, button#cancel-F-input, button#upload-F-input, button#discontinue, button#cancelDiscontinue, select#fileDocType, #sectionH textarea, #sectionH button, #sectionH select, #sectionG textarea ,#sectionG button, #sectionE table').prop('disabled', true);
                        $('.replaceUser, .peoplepicker').addClass('hidden');
                        // set workflow
                        workflowStatus = 'Discontinued';
                    } else {
                        currentActive = 'A';
                        if (IsApprovalLocked) {
                            /**** set CHECK tab ****/
                            $('#infoTab').removeClass('active');
                            $('#sectionA').removeClass('in active');
                            // activate section
                            var FilingRequiredSelectionText = $('#FilingRequired option:selected').text();
                            if ($('#TypeOfProject').val() != 'Streamlined') {
                                if (FilingRequiredSelectionText.search('FINRA') >= 0 && (IsFINRALocked == '' || IsFINRALocked == 'No' || IsFINRALocked == null)) {
                                    // set FINRA tab
                                    $('#sectionD').addClass('in active');
                                    // set focus
                                    $('#FilingSubmittedOn').focus();
                                    currentActive = 'D';
                                    $('#FINRATab').addClass('active');
                                    // set workflow
                                    workflowStatus = 'FINRA';
                                } else if (FilingRequiredSelectionText.search('State') >= 0 && (IsStateFilingLocked == '' || IsStateFilingLocked == 'No' || IsStateFilingLocked == null)) {
                                    // or set State tab
                                    $('#sectionE').addClass('in active');
                                    // set focus
                                    $('#StateFiler').focus();
                                    currentActive = 'E';
                                    $('#stateTab').addClass('active');
                                    // set workflow
                                    workflowStatus = 'State';
                                } else {
                                    // or set Status tab
                                    $('#sectionG').addClass('in active');
                                    currentActive = 'G';
                                    $('#statusTab').addClass('active');
                                    // set workflow
                                    workflowStatus = 'Complete';
                                    // disable upload
                                    if (!isAdmin) {
                                        $('#sectionF button, #sectionF input, #sectionF select').prop('disabled', true);
                                    }
                                }
                            } else {
                                // or set Status tab
                                $('#sectionG').addClass('in active');
                                currentActive = 'G';
                                $('#statusTab').addClass('active');
                                // set workflow
                                workflowStatus = 'Complete';
                                // disable upload
                                if (!isAdmin) {
                                    $('#sectionF button, #sectionF input, #sectionF select').prop('disabled', true);
                                }
                            }

                        } else if (IsCheckedLocked) {
                            /**** set CHECK tab ****/
                            $('#infoTab').removeClass('active');
                            $('#sectionA').removeClass('in active');
                            // activate section
                            $('#sectionC2').addClass('in active');
                            // set focus                           
                            //$('#ApprovalDate').focus();
                            //set Approval date as current date and make it readonly
                            $('#ApprovalDate').val(now());
                            $('#ApprovalDate').prop('disabled', true);

                            currentActive = 'C2';
                            $('#ApprovalTab').addClass('active');
                            // set workflow
                            workflowStatus = 'Approval';

                        } else if (IsComplianceReviewLocked) {
                            /**** set CHECK tab ****/
                            $('#infoTab').removeClass('active');
                            $('#sectionA').removeClass('in active');
                            // activate section
                            $('#sectionC').addClass('in active');
                            // set focus
                            $('#DateOfFirstUse2').focus();
                            currentActive = 'C';
                            $('#revisionTab').addClass('active');
                            // set workflow
                            workflowStatus = 'Revision';
                        } else if (IsProjectInformationLocked) {
                            /**** set REVIEW tab ****/
                            $('#infoTab').removeClass('active');
                            $('#sectionA').removeClass('in active');
                            // activate section
                            $('#sectionB').addClass('in active');
                            // set focus
                            $('#TypeOfReview_s').focus();
                            currentActive = 'B';
                            $('#reviewTab').addClass('active');
                            // set workflow
                            workflowStatus = 'Review';
                        } else {
                            /**** set REVIEW tab ****/
                            //$('#infoTab').removeClass('active');
                            //$('#sectionA').removeClass('in active');
                            // activate section
                            ////$('#sectionG').addClass('in active');
                            //currentActive = 'G';
                            //$('#statusTab').addClass('active');
                            // set workflow
                            //workflowStatus = 'Status';
                        }

                        if (workflowStatus != 'Complete') {
                            // allow deletion of files in final folder
                            if ($('.currentUserGroup').html().search('CPRO Writers') >= 0 || $('.currentUserGroup').html().search('CPRO Approvers') >= 0 || $('.currentUserGroup').html().search('CPRO MRU Group') >= 0) {
                                $('.documents_display_final .delete').removeClass('hidden');
                            }
                        }

                        // set starting tab in html to reference later
                        $('#StartingTab').html(currentActive);
                        // DISABLE SUBMIT IF PREVIOUS TABS ARE UNLOCKED
                        checkUnlockedTabs();
                    }

                    if (test) {
                        console.log('Workflow Status: ' + workflowStatus);
                    }

              
                    // disable discontinue option
                    var hideDisc = 'y';
                    if ($('span#CurrentUser').text() && $('.display_submitter span.name').text()) {
                        if ($('span#CurrentUser').text().split(',')[0] == $('.display_submitter span.name').text().split(',')[0]) { // || $('.currentUserGroup').html().search('CPRO Administrators') >= 0
                            hideDisc = '';
                        } else {
                            hideDisc = 'y';
                        }
                    } 
                    if ($('span#CurrentUser').text() && $('.display_ApprovingManager span.name').text() && hideDisc) {
                        if ($('span#CurrentUser').text().split(',')[0] == $('.display_ApprovingManager span.name').text().split(',')[0]) { // || $('.currentUserGroup').html().search('CPRO Administrators') >= 0
                            hideDisc = '';
                        } else {
                            hideDisc = 'y';
                        }
                    }
                    if (workflowStatus == 'Complete' || IsApprovalLocked) {
                        hideDisc = 'y';
                    }
                    if (hideDisc) {
                        // $('#discontinue, #cancelDiscontinue, #DiscontinuedComments, #discontinue-H-input').attr('disabled', true);
                        $('#DiscontinuedComments, #discontinue-H-input').attr('disabled', true);
                    }

                    // disable Review tab if Type of Project = Streamlined
                    if ($('#TypeOfProject').val() == 'Streamlined') {
                        // enable tabs
                        $('#reviewTab').addClass('disabled').removeClass('active');
                        $('#reviewTab a').attr('data-toggle', '');
                    }

                    // handle display of people pickers
                    $('.displayPerson').each(function () {
                        var userType = $(this).children('button').data('usertype');
                        if ($('.display_' + userType + ' span').html()) { // user is filled in
                            $('.display_' + userType + '').removeClass('hidden'); // display users name
                            $('[data-person="' + userType + '"]').addClass('hidden'); // hide people picker
                        }
                    });


                    // load people picker
                    var pp_multi = '';
                    var pp_person = '';
                    var pp_group;
                    $('.peoplepicker').each(function () {
                        pp_multi = $(this).data('multiple');
                        pp_person = $(this).data('person');
                        pp_group = $(this).data('group');
                        loadPeoplePickerScripts(pp_person, pp_multi, pp_group);
                    });

                    // remove user and add people picker back in
                    $('.replaceUser').click(function () {
                        var userType = $(this).data('usertype');
                        if (test) {
                            console.log('replace user: ' + userType);
                        }
                        // remove user
                        $('.display_' + userType).addClass('hidden').html('');
                        // reveal people picker
                        $('[data-person="' + userType + '"]').removeClass('hidden');
                        // focus on people picker field
                        $('[data-person="' + userType + '"] input').focus();

                    });

                    // validate status
                    // loop all status markers and validate percentage
                    var updateStatus;
                    var ch_ProjectInformationStatus = $('#ProjectInformationStatus').html();
                    var ch_ComplianceReviewStatus = $('#ComplianceReviewStatus').html();
                    var ch_RevisionStatus = $('#RevisionStatus').html();
                    var ch_ApprovalStatus = $('#ApprovalStatus').html();
                    var ch_FINRAFilingStatus = $('#FINRAFilingStatus').html();
                    var ch_StateFilingStatus = $('#StateFilingStatus').html();
                    if (ch_ProjectInformationStatus == 'Saved' || ch_ProjectInformationStatus == 'Not Started' || ch_ProjectInformationStatus == 'Unlocked') {
                        updateStatus = 1; // 25
                    } else if (ch_ComplianceReviewStatus == 'Saved' || ch_ComplianceReviewStatus == 'Not Started' || ch_ComplianceReviewStatus == 'Unlocked') {
                        updateStatus = 2; // 50
                    } else if (ch_RevisionStatus == 'Saved' || ch_RevisionStatus == 'Not Started' || ch_RevisionStatus == 'Unlocked') {
                        updateStatus = 3; // 75
                    } else if (ch_ApprovalStatus == 'Saved' || ch_ApprovalStatus == 'Not Started' || ch_ApprovalStatus == 'Unlocked') {
                        updateStatus = 4; // 90
                    } else if (ch_ApprovalStatus == 'Submitted' && ((ch_FINRAFilingStatus == 'N/A' || ch_FINRAFilingStatus == 'Submitted') && (ch_StateFilingStatus == 'N/A' || ch_StateFilingStatus == 'Submitted'))) {
                        updateStatus = 5; // 100
                    } else {
                        updateStatus = 4; // 90
                    }
                    if ($('#SectionNumber').html() != updateStatus) {
                        // update list
                        updateStatusFunc(updateStatus);
                    }
                    // Submitted, Saved, Not Started

                    // remove loading cover
                    $('.loading-container').css('display', 'none');
                });
                if (workflowStatus == '') {
                    // could not find corresponding Control Value
                    $('.loading-container .messaging h1').html('ERROR: Unable to find Project Control');
                    $('.loading-container .messaging').css('background', 'none');
                }
            },
            error: function (data, errorCode, errorMessage) {
                console.log("ERROR set permissions : " + errorMessage);
            },
            state: "Get List Data"
        });
    }
}

function updateStatusFunc(getStatus) {
    exeBody = "{'__metadata': { 'type': 'SP.Data." + listName_metadata + "ListItem' }," +
        "'SectionNumber': '" + getStatus + "'" +
            "}";
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
           function () {
               $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest2);
           });
    });
    function execCrossDomainRequest2() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items(" + idParameter + ")?@target='" + hostUrl + "'";

        executor.executeAsync({
            url: domain,
            method: 'POST',
            contentType: 'application/json;odata=verbose',
            headers: {
                'IF-MATCH': '*',
                'X-HTTP-Method': 'MERGE',
                'content-type': 'application/json; odata=verbose'
            },
            body: exeBody,
            success: function (data, status, headers, config) {
                if (test) {
                    console.log('status fix updated');
                }
                var percent;
                // adjust graphic //
                if (getStatus == '1') {
                    percent = '25%';
                } else if (getStatus == '2') {
                    percent = '50%';
                } else if (getStatus == '3') {
                    percent = '75%';
                } else if (getStatus == '4') {
                    percent = '90%';
                } else if (getStatus == '5') {
                    percent = '100%';
                } else if (getStatus == '100') {
                    percent = '100%'; // discontinued
                }
                ProjectStatus1 = percent;
                ProjectStatus2 = percent; // duplicated for 'discontinue status'
                discontinueStatus = percent;
                ProjectStatusNum = ProjectStatus1.replace('%', '');
                // if discontinued
                if (getStatus == '100') {
                    ProjectStatusNum = '100';
                    ProjectStatus1 = '100%';
                    ProjectStatus2 = 'Discontinued';
                }
                $('.progress-bar').css('width', ProjectStatus1).attr('aria-valuenow', ProjectStatusNum).html(ProjectStatus2);
                if (getStatus == '5') {
                    //$('#discontinue, #cancelDiscontinue, #DiscontinuedComments, #discontinue-H-input').attr('disabled', true);
                    $('.progress-bar').addClass('progress-bar-success');
                }
                if (getStatus == '100') {
                    $('.progress-bar').addClass('progress-bar-danger');
                    $('.projectDiscontinued_dis').css('color', 'd9534f').css('font-weight', 'bold');
                }
            },
            error: function (jqXHR, exception) {

                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connected.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.\n' + jqXHR.responseText;
                }
                addLog(msg, section, 'Error updating section vaue');

            }
        });

    }
}

// check if there are unlocked tabs, if so, disable submit option on current/active tab
function checkUnlockedTabs() {
    var currentActive = $('#StartingTab').html();
    var checkStatus;
    var checkSection;
    $('.unlockBtn').each(function () {
        checkStatus = $(this).prev().attr('id');
        checkSection = $(this).attr('id').split('-')[1];
        if ($('#' + checkStatus).text() == 'Unlocked' && checkSection != currentActive) {
            $('#submit-' + currentActive + '-input').prop('disabled', true); // disable submit button on active tab
            // set alert message
            $('#section' + currentActive + ' .notice.alert .notice_msg').html('A previous section is unlocked. The submit button is disabled until the section is submitted.');
            $('#section' + currentActive + ' .notice.alert').removeClass('hidden');
            
        }
    });
}

function setControlID(action) {
    var controlNumber = $('span.controlNumber').html(); // get control # 
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });

    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName2 + "')/items?$filter=Title eq '" + controlNumber + "'&@target='" + hostUrl + "'";
        executor.executeAsync({
            url: domain,
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: function (data, status, headers, config) {
                var body = jQuery.parseJSON(data.body);
                var results = body.d.results;
                $.each(results, function (index, value) {
                    var properties = results[index];
                    var controlID = properties.Id;
                    // change status so workflow doesn't initiate email
                    if (action == 'project' && properties.IsProjectInformationLocked == 'No') {
                        var unlockRequest = action;
                    } else if (action == 'review' && properties.IsComplianceReviewLocked == 'No') {
                        var unlockRequest = action;
                    } else if (action == 'revision' && properties.IsCheckedLocked == 'No') {
                        var unlockRequest = action;
                    } else if (action == 'approved' && properties.IsApprovalLocked == 'No') {
                        var unlockRequest = action;
                    } else if (action == 'finra' && properties.IsFINRALocked == 'No') {
                        var unlockRequest = action;
                    } else if (action == 'state' && properties.IsStateFilingLocked == 'No') {
                        var unlockRequest = action;
                    }
                    
                    if (test) {
                        console.log('get ID of the project')
                    }
                    submitList(action, controlID, unlockRequest)


                });
            },
            error: function (data, errorCode, errorMessage) {
                console.log("ERROR getting : " + errorMessage);
            },
            state: "Get List Data"
        });
    }
}
function checkCurrentUser() {
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });

    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/Web/CurrentUser?$expand=Groups&$select=Id,Groups,Title,LoginName&@target='" + hostUrl + "'";
        if (test) {
            console.log(domain);
        }
        executor.executeAsync({
            url: domain,
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: function (data, status, headers, config) {
                var body = jQuery.parseJSON(data.body);
                var currentUserID = body.d.Id;
                var currentUserTitle = body.d.Title;
                var currentUserLogin = body.d.LoginName;
                // set value in html
                $('span#CurrentUser').html(currentUserTitle);
                $('span#CurrentUserLogin').html(currentUserLogin);
                if (test) {
                    console.log('Current User: ' + currentUserID + ' ' + currentUserTitle);
                }
                var groupNames = ['CPRO Approvers', 'CPRO MRU Group', 'CPRO Reviewers', 'CPRO Writers', 'CPRO Administrators'];
                var userGroups = body.d.Groups.results;
                var allGroups = [];
                var groups = '';
                $.each(userGroups, function (index, value) {
                    var properties = userGroups[index];
                    var groupName = properties.LoginName;
                    allGroups.push(groupName);
                    groups = groups + groupName + ' ';
                    if (test) {
                        console.log(groupName);
                    }
                });
                /* set permissions */
                var section = '';
                if ($.inArray("CPRO Writers", allGroups) >= 0 || $.inArray("CPRO Administrators", allGroups) >= 0) {
                    // Info Tab
                    section = 'sectionA';
                    $('#save-A-input, #submit-A-input, #' + section + ' .replaceUser').prop('disabled', false);
                    $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea, #sectionF input').prop('disabled', false);
                    $('#' + section + ' .multiselect').removeClass('disable_ms'); // remove background color
                    $('#' + section + ' .replaceUser, #' + section + ' .peoplepicker').removeClass('hidden');

                    // Revision Tab
                    section = 'sectionC';
                    $('#save-C-input, #submit-C-input, #' + section + ' .replaceUser').prop('disabled', false);
                    $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea').prop('disabled', false);
                    $('#' + section + ' .multiselect').removeClass('disable_ms'); // remove background color
                    $('#' + section + ' .replaceUser, #' + section + ' .peoplepicker').removeClass('hidden');
                    // display user inplace of peoplepicker if no value is present
                    $('#' + section + ' #Submitter.peoplepicker').addClass('hidden');
                    $('#' + section + ' .display_Submitter').removeClass('hidden');
                    // enable upload options
                    $('#sectionF select#fileDocType option:contains("Draft")').attr('disabled', false); // enable Draft
                    $('#sectionF select#fileDocType option:contains("Final")').attr('disabled', false); // enable Final
                    $('#sectionF select#fileDocType option:contains("Approved")').attr('disabled', false); // enable Approved
                }
                if ($.inArray("CPRO MRU Group", allGroups) >= 0 || $.inArray("CPRO Administrators", allGroups) >= 0) {
                    // Review Tab
                    section = 'sectionB';
                    $('#save-B-input, #submit-B-input, #' + section + ' .replaceUser').prop('disabled', false);
                    $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea, #sectionF input').prop('disabled', false);
                    $('#' + section + ' .multiselect').removeClass('disable_ms'); // remove background color
                    $('#' + section + ' .replaceUser, #' + section + ' .peoplepicker').removeClass('hidden');
                    // display user inplace of peoplepicker if no value is present
                    if ($('.display_Reviewers span.name').html() == '') {
                        if (test) {
                            console.log('Display Reviewer Name');
                        }
                        $('.display_Reviewers span.name').html(currentUserTitle);
                        $('.display_Reviewers span.id').html(currentUserID);
                        $('#' + section + ' #Reviewers.peoplepicker').addClass('hidden');
                        $('#' + section + ' .display_Reviewers').removeClass('hidden');
                    }
                    // FINRA Tab
                    // Review Tab
                    section = 'sectionD';
                    $('#save-D-input, #submit-D-input, #' + section + ' .replaceUser').prop('disabled', false);
                    $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea, #sectionF input').prop('disabled', false);
                    $('#' + section + ' .multiselect').removeClass('disable_ms'); // remove background color
                    $('#' + section + ' .replaceUser, #' + section + ' .peoplepicker').removeClass('hidden');

                    // State Tab
                    // Review Tab
                    section = 'sectionE';
                    $('#save-E-input, #submit-E-input, #' + section + ' .replaceUser').prop('disabled', false);
                    $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea, #sectionF input').prop('disabled', false);
                    $('#' + section + ' .multiselect').removeClass('disable_ms'); // remove background color
                    $('#' + section + ' .replaceUser, #' + section + ' .peoplepicker').removeClass('hidden');
                    // enable upload options
                    $('#sectionF select#fileDocType option:contains("Final")').attr('disabled', false); // enable Final
                    $('#sectionF select#fileDocType option:contains("Approved")').attr('disabled', false); // enable Approved
                        
                }
                if ($.inArray("CPRO Approvers", allGroups) >= 0 || $.inArray("CPRO Administrators", allGroups) >= 0) {
                    // Approval Tab
                    section = 'sectionC2';
                    $('#save-C2-input, #submit-C2-input, #' + section + ' .replaceUser').prop('disabled', false);
                    $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea, #sectionF input').prop('disabled', false);
                    $('#' + section + ' .multiselect').removeClass('disable_ms'); // remove background color
                    $('#' + section + ' .replaceUser, #' + section + ' .peoplepicker').removeClass('hidden');

                    $('#' + section + ' input, #' + section + ' textarea').prop('disabled', false);
                    // enable upload options
                    $('#sectionF select#fileDocType option:contains("Final")').attr('disabled', false); // enable Final
                    $('#sectionF select#fileDocType option:contains("Approved")').attr('disabled', false); // enable Approved
                }
                if ($.inArray("CPRO Administrators", allGroups) >= 0) {
                    // Unlock Buttons
                    isAdmin = true;
                }
                // set group flag
                $('span.currentUserGroup').html(groups);
            },
            error: function (data, errorCode, errorMessage) {

                console.log('Error: ' + errorMessage);
                $('.loading-container .messaging h1').html('Error: Fail user info lookup, please try again later');
                $('.loading-container .messaging').css('background', 'none');
                
            },
            state: "Get List Data"
        });
    }
}

function editList(action) {
    var shortSection;
    if (action == 'project') {
        shortSection = 'A';
    } else if (action == 'review') {
        shortSection = 'B';
    } else if (action == 'revision') {
        shortSection = 'C';
    } else if (action == 'approval') {
        shortSection = 'C2';
    } else if (action == 'finra') {
        shortSection = 'D';
    } else if (action == 'state') {
        shortSection = 'E';
    }
    var section = 'section' + shortSection;
    
    // change buttons
    $('#save-' + shortSection + '-input, #submit-' + shortSection + '-input, #cancel-' + shortSection + '-input').prop('disabled', true);
    $('#save-' + shortSection + '-input').html('Saving...');

    // reveal loading icon
    $('#' + section + ' .uploadLoading').removeClass('hidden');
    // hide alert messages
    $('#' + section + ' .error.alert, #' + section + ' span.validation').addClass('hidden');

    // validate form
    if (validation(section) == 'no') {
        editListItem(section, 'edit', '', '');
    } else {
        // enable buttons
        $('#save-' + shortSection + '-input, #submit-' + shortSection + '-input, #cancel-' + shortSection + '-input').prop('disabled', false);
        if (action == 'project') {
            // change buttons
            $('#save-A-input').html('Save Project Information');
            $('#submit-A-input').html('Submit Project Information');
        } else if (action == 'review') {
            // change buttons
            $('#save-B-input').html('Save Review');
            $('#submit-B-input').html('Submit Review');
        } else if (action == 'revision') {
            // change buttons
            $('#save-C-input').html('Save Material');
            $('#submit-C-input').html('Material is Ready (Send Notification to Approver)');
        } else if (action == 'approval') {
            // change buttons
            $('#save-C2-input').html('Save Approval');
            $('#submit-C2-input').html('Submit Approval');
        } else if (action == 'finra') {
            // change buttons
            $('#save-D-input').html('Save FINRA Filing');
            $('#submit-D-input').html('Submit FINRA Filing');
        } else if (action == 'state') {
            // change buttons
            $('#save-E-input').html('Save State Filing');
            $('#submit-E-input').html('Submit State Filing');
        }
        // check for unlocked sections and disable submit if applicable
        checkUnlockedTabs();
        // hide loading icon
        $('#' + section + ' .uploadLoading').addClass('hidden');
        // error message
        $('#' + section + ' .error .error_msg').html('Validation failed');
        $('#' + section + ' .error').removeClass('hidden');
    }

}


function submitList(action, controlID, unlockRequest) {
    
    var section;
    var shortSection;
    if (action == 'project') {
        section = 'sectionA';
        shortSection = 'A';
    } else if (action == 'review') {
        section = 'sectionB';
        shortSection = 'B';
    } else if (action == 'revision') {
        section = 'sectionC';
        shortSection = 'C';
    } else if (action == 'approval') {
        section = 'sectionC2';
        shortSection = 'C2';
    } else if (action == 'finra') {
        section = 'sectionD';
        shortSection = 'D';
    } else if (action == 'state') {
        section = 'sectionE';
        shortSection = 'E';
    } 

    // hide error message
    $('#' + section + ' .error, #' + section + ' span.validation').addClass('hidden');

    // validate form
    if (action.split('-')[0] == 'unlock') {
        unlockStatus(controlID, action.split('-')[1]);
    } else if (validation(section) == 'no') {
        if (section == 'sectionE') {
            var fail = "no";
            var count = 0;
            $('#StateFilingList tbody tr').each(function () {
                dateApproved = $(this).find('.datepicker[id="DateApproved' + count + '"]').val();
                comments = addslashes($(this).find('.stateComments[id="stateFilingComments' + count + '"]').val());

                // check if input value found
                if (dateApproved == false || dateApproved == null) {
                    fail = 'yes';
                    if (test) {
                        console.log('Fail: SelectionText');
                    }
                    $(this).find('.datepicker[id="DateApproved' + count + '"]').after('<span class="validation">required</span>');
                    
                } else if (comments == false || comments == null) {
                    fail = 'yes';
                    if (test) {
                        console.log('Fail: SelectionText');
                    }
                    $(this).find('.stateComments[id="stateFilingComments' + count + '"]').after('<span class="validation">required</span>');
                }
                else {
                    $(this).nextAll('span.validation').hide();
                }
                count++;
            });
            if (fail == 'no') {
                editListItem(section, 'submit', controlID, unlockRequest);
            } else {
                // change buttons
                $('#save-E-input, #submit-E-input, #cancel-E-input').prop('disabled', false);
                $('#save-E-input').html('Save State Filing');
                $('#submit-E-input').html('Submit State Filing');
                // hide loading icon
                $('#' + section + ' .uploadLoading').addClass('hidden');
                // error message
                $('#' + section + ' .error .error_msg').html('Please enter "Date Approved" and "Comment" before submitting');
                $('#' + section + ' .error').removeClass('hidden');
            }
        } else {
            editListItem(section, 'submit', controlID, unlockRequest);
        }
    } else {
        // enable buttons
        $('#save-' + shortSection + '-input, #submit-' + shortSection + '-input, #cancel-' + shortSection + '-input').prop('disabled', false);
        if (action == 'project') {
            // change buttons
            $('#save-A-input').html('Save Project Information');
            $('#submit-A-input').html('Submit Project Information');
        } else if (action == 'review') {
            // change buttons
            $('#save-B-input').html('Save Review');
            $('#submit-B-input').html('Submit Review');
        } else if (action == 'revision') {
            // change buttons
            $('#save-C-input').html('Save Material');
            $('#submit-C-input').html('Material is Ready (Send Notification to Approver)');
        } else if (action == 'approval') {
            // change buttons
            $('#save-C2-input').html('Save Approval');
            $('#submit-C2-input').html('Submit Approval');
        } else if (action == 'finra') {
            // change buttons
            $('#save-D-input').html('Save FINRA Filing');
            $('#submit-D-input').html('Submit FINRA Filing');
        } else if (action == 'state') {
            // change buttons
            $('#save-E-input').html('Save State Filing');
            $('#submit-E-input').html('Submit State Filing');
        }
        // hide loading icon
        $('#' + section + ' .uploadLoading').addClass('hidden');
        // error message
        $('#' + section + ' .error .error_msg').html('Validation failed');
        $('#' + section + ' .error').removeClass('hidden');
        
    }
}


function validation(section) {
    // check required fields
    var fail = "no";
    var validationDependency;
    var getID;
    var selectionText;    
    // loop all input fields
    $('#' + section + ' input[type=text], #' + section + ' select, #' + section + ' textarea').each(function () {
        // check for validation data tag
        if ($(this).data('validate') == 'required') {
            getID = $(this).attr('id');
            selectionText = $(this).val();
            // check if input value found
            if (selectionText == false || selectionText == null) {
                if (test) {
                    console.log('Fail: SelectionText');
                    console.log('Validate Field: ' + getID);
                    console.log('Validate Text: ' + selectionText);
                }
                fail = 'yes';
                $(this).after('<span class="validation">required</span>');
            } else {
                $(this).nextAll('span.validation').hide();
            }
        } else if ($(this).data('validate') != null) { // check for dependency
            validationDependency = $(this).data('validate');
            // special case for 'Category under which your material falls' (#sectionA)
            if ($(this).attr('id') == 'CategoryOfMaterial') {
                var selectionTextCM = $('#CategoryOfMaterial').val();
                if (selectionTextCM == '') {
                    // no validation
                } else {
                    // following checkbox is required
                    if (test) {
                        console.log('CM');
                        console.log('Validate Text: ' + selectionTextCM);
                    }
                    if ($('#AcknowledgeDetailsSubmitted').is(':checked')) {
                        $('#AcknowledgeDetailsSubmitted').nextAll('span.validation').hide();
                    } else {
                        fail = 'yes';
                        if (test) {
                            console.log('Fail: AcknowledgeDetailsSubmitted');
                        }
                        $('#AcknowledgeDetailsSubmitted').after('<span class="validation" style="position:relative">required</span>');
                        $('#AcknowledgeDetailsSubmitted').nextAll('span.validation').show();
                    }
                }
            }
            // split into array to check for other dependencies
            if (validationDependency) {
                var validationDependency_array = [];
                validationDependency_array = validationDependency.split('-');
                if (test) {
                    console.log('Validate Dependency: ' + validationDependency);
                }
                // check if input value found
                if ($('#' + section + ' input[type=checkbox]#' + validationDependency).is(':checked')) {
                    if ($(this).val() == false) {
                        fail = 'yes';
                        if (test) {
                            console.log('Fail: ' + validationDependency);
                        }
                        $(this).after('<span class="validation">required</span>');
                    } else {
                        $(this).nextAll('span.validation').hide();
                    }
                }
                if (validationDependency_array[1]) {
                    var dependencyItem = validationDependency_array[0];
                    var dependencySelect = validationDependency_array[1];
                    var dependencySelect2 = validationDependency_array[2];
                    var dependencyValue = $(this).val();
                    var selectionText = convertDropDown($('#' + dependencyItem + '').val());
                    //var selectionText = $('#' + dependencyItem + '').next().children().attr('title');
                   
                    if (test) {
                        console.log('Dependency Array: ' + selectionText);
                        console.log(dependencyItem);
                        console.log(dependencySelect);
                        console.log(dependencySelect2);
                        console.log(dependencyValue);
                    }
                    if (selectionText != '' && selectionText != null) {
                        
                        if (selectionText.search(dependencySelect) >= 0 && (typeof dependencySelect != 'undefined') && (dependencyValue == '' || dependencyValue == null || dependencyValue == 'None selected')) {
                            fail = 'yes';
                            if (test) {
                                console.log('Dependency 1');
                            }
                            $(this).after('<span class="validation">required</span>');
                        } else if (selectionText.search(dependencySelect2) >= 0 && (typeof dependencySelect2 != 'undefined') && (dependencyValue == '' || dependencyValue == null || dependencyValue == 'None selected')) {
                            fail = 'yes';
                            if (test) {
                                console.log('Dependency 2');
                            }
                            $(this).after('<span class="validation">required</span>');
                        } else {
                            $(this).nextAll('span.validation').hide();
                        }
                    } else {
                        $(this).nextAll('span.validation').hide();
                    }
                    
                }
            }
        }
    });
    // validate for people picker error
    $('#' + section + ' .sp-peoplepicker-errorMsg').each(function () {
        fail = true;
        if (test) {
            console.log('Fail: PP error message');
        }
    });
    // validate if people picker results exists
    $('#' + section + ' .peoplepicker').each(function () {
        var personLabel = $(this).data('person');
        var ppContent = $('.display_' + personLabel + ' span').html();
        var validationDependency = $(this).data('validate');
        if (validationDependency == 'required') {
            if (ppContent == '' || ppContent == null) {
                ppContent = $(this).find('.ms-entity-resolved').html();
                if (ppContent == '' || ppContent == null) {
                    $('.pp_error[data-validatepp="' + personLabel + '"], .pp_error[data-validatepp="' + personLabel + '"] .validation').removeClass('hidden');
                    fail = true;
                    if (test) {
                        console.log('Fail: PP no person picked');
                    }
                } else {
                    $('.pp_error[data-validatepp="' + personLabel + '"]').addClass('hidden');
                }
            }
        } else if (validationDependency != null) {
            if ((ppContent == '' || ppContent == null) && $('#' + validationDependency).is(':checked')) {
                ppContent = $(this).find('.ms-entity-resolved').html();
                if (ppContent == '' || ppContent == null) {
                    $('.pp_error[data-validatepp="' + personLabel + '"], .pp_error[data-validatepp="' + personLabel + '"] .validation').removeClass('hidden');
                    fail = true;
                    if (test) {
                        console.log('Fail: PP no person picked');
                    }
                } else {
                    $('.pp_error[data-validatepp="' + personLabel + '"]').addClass('hidden');
                }
            }
        }
            
            
    });
    // validate radio selections
    $('#' + section + ' input[type=radio]').each(function () {
        if ($(this).data('validate') == 'required') {
            var getName = $(this).attr('name');
            if (!$("#" + section + " input[name='" + getName + "']:checked").val()) {
                $(this).next('label').next('span.validation').removeClass('hidden');
                fail = 'yes';
                if (test) {
                    console.log('Fail: Radio ' + getName);
                }
            } else {
                $(this).next('label').next('span.validation').addClass('hidden');
            }
        }
    });
    // validate checkbox selections
    $('#' + section + ' input[type=checkbox]').each(function () {
        if ($(this).data('validate') == 'required') {
            var getName = $(this).attr('name');
            if (!$("#" + section + " input[name='" + getName + "']").prop('checked')) {
                $(this).next('label').next('span.validation').removeClass('hidden');
                fail = 'yes';
                if (test) {
                    console.log('Fail: Checkbox ' + getName);
                }
            } else {
                $(this).next('label').next('span.validation').addClass('hidden');
            }
        }
    });
    // special case :: check special case in SectionB
    if (section == 'sectionB' && $('#sectionB #SubmittedToLawForReview').is(':checked')) {
        if ($('#sectionB #DateCommentsReceivedFromLaw').val() == false && !$('#sectionB #NoCommentsReceivedFromLaw').is(':checked')) {
            $('#sectionB #NoCommentsReceivedFromLaw').nextAll('span.validation').removeClass('hidden');
            fail = 'yes';
        } else {
            $('#sectionB #NoCommentsReceivedFromLaw').nextAll('span.validation').addClass('hidden');
        }
    }
    // special case :: checking approving manager & submitter validation
    if (section == 'sectionB') {
        // if names are validated
        var Reviewers_name = $('.display_Reviewers > span.name').html();
        if (typeof Reviewers_name == 'undefined' || Reviewers_name == '') {
            // get value from people picker
            Reviewers_name = $("#Reviewers").find('.ms-entity-resolved').html();
        }
        var SecondaryReviewer_name = $('.display_SecondaryReviewer > span.name').html();
        var SecondaryReviewer_nameArray = '';
        if (typeof SecondaryReviewer_name == 'undefined' || SecondaryReviewer_name == '') {
            // get value from people picker
            SecondaryReviewer_name = $("#SecondaryReviewer").find('.ms-entity-resolved').html();
            if (SecondaryReviewer_name) {
                SecondaryReviewer_nameArray = SecondaryReviewer_name.split(';');
            }
        }
        if (Reviewers_name && SecondaryReviewer_name) {
            $.each(SecondaryReviewer_nameArray, function (index, value) {
                if (Reviewers_name.split(',')[0] == value.split(',')[0]) { // account for entering multiple users
                    fail = 'yes';
                    var message = "Secondary Reviewer and Coordinating Reviewer cannot be the same";
                    $('.pp_error[data-validatepp="SecondaryReviewer"]').removeClass('hidden');
                    $('.pp_error[data-validatepp="SecondaryReviewer"] .validation').removeClass('hidden').html(message);
                }
            });
        }
    }
    // special case :: checking approving manager & submitter validation
    if (section == 'sectionC') {
        // if names are validated
        var submitter_name = $('.display_Submitter > span.name').html();
        if (typeof submitter_name == 'undefined' || submitter_name == '') {
            // get value from people picker
            submitter_name = $("#Submitter").find('.ms-entity-resolved').html();
        }
        var approvingmanager_name = $('.display_ApprovingManager > span.name').html();
        if (typeof approvingmanager_name == 'undefined' || approvingmanager_name == '') {
            // get value from people picker
            approvingmanager_name = $("#ApprovingManager").find('.ms-entity-resolved').html();
        }
        if(submitter_name && approvingmanager_name){
            if (submitter_name.split(',')[0] == approvingmanager_name.split(',')[0]) {
                fail = 'yes';
                var message = "Approving Manager and Submitter cannot be the same";
                $('.pp_error[data-validatepp="ApprovingManager"]').removeClass('hidden');
                $('.pp_error[data-validatepp="ApprovingManager"] .validation').removeClass('hidden').html(message);
            }
        }
    }
    // special case :: Turnaround
    if (section == 'sectionA') {
        if (!$("#" + section + " input[name='Turnaround']:checked").val() && $('#TypeOfProject').val() != 'Streamlined') {
            $("#" + section + " input[name='Turnaround']").next('label').next('span.validation').removeClass('hidden');
            fail = 'yes';
            if (test) {
                console.log('Fail: Turnaround Radio');
            }
        } else {
            $("#" + section + " input[name='Turnaround']").next('label').next('span.validation').addClass('hidden');
        }
    }
    // special case for Intended Usage Period
    if (section == 'sectionC') {
        var startDate = new Date($('#DateOfFirstUse2').val());
        var endDate = new Date($('#To_x0020_Intended_x0020_Usage_x0').val());
        if (startDate > endDate) {
            fail = 'yes';
            $('#usageDate').removeClass('hidden').css('display', 'inline');
        } else {
            $('#usageDate').addClass('hidden');
        }
    }
    // special case for Review Dates
    if (section == 'sectionB') {
        var startDate = new Date($('#DateAssigned').val());
        var endDate = new Date($('#ComplianceReviewCompletedDate').val());
        if (startDate > endDate) {
            fail = 'yes';
            $('#reviewDate').removeClass('hidden').css('display', 'inline');
        } else {
            $('#reviewDate').addClass('hidden');
        }
    }
    // special case for Related Control #
    // Ralated Control number should not be the current control number
    if (section == 'sectionA') {
        var getControlNumber = $('span.controlNumber').html();
        var relatedControlNumber = addslashes($('#ProjectCNumber').val());
        if (getControlNumber == relatedControlNumber) {
            fail = 'yes';
            $('#relatedControlNum').removeClass('hidden').css('display', 'inline');
        } else {
            $('#relatedControlNum').addClass('hidden');
        }
    }

    return fail;

}

function fillMaterialList(dataList) {
    // check for existing localstorage
    var mlS_Name = 'buildMaterialList_v1';
    var output = $('#displayMaterialList');
    if (localStorage.getItem(mlS_Name) != null && localStorageCheck == 'y') {
        // remove loading icon
        $('#displayMaterialList').removeClass('sm_loading');
        // add content to page
        output.append(localStorage.getItem(mlS_Name));
        if (test) {
            console.log('Using LocalStorage: ' + mlS_Name);
        }
    } else {
        $.getScript(scriptbase + 'SP.Runtime.js',
        function () {
            $.getScript(scriptbase + 'SP.js',
                function () {
                    $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
                });
        });
        // After the cross-domain library is loaded, execution 
        function execCrossDomainRequest() {
            var executor = new SP.RequestExecutor(appUrl);
            var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + dataList + "')/items?$orderby=Order0 asc'&@target='" + hostUrl + "'";
            executor.executeAsync({
                url: domain,
                method: 'GET',
                headers: { 'Accept': 'application/json; odata=verbose' },
                success: function (data, status, headers, config) {
                    var body = jQuery.parseJSON(data.body);
                    var results = body.d.results;
                    var materialString = '';
                    $.each(results, function (index, value) {
                        properties = results[index];
                        // start fill form
                        materialString = materialString + '<b>' + properties.Title + ':</b> ' + properties.Description + '<br /><br />';
                        // end fill form
                    });
                    // remove loading icon
                    $('#displayMaterialList').removeClass('sm_loading');
                    // add results to page
                    output.append(materialString);
                    /***** set Local Storage ******/
                    if (localStorageCheck == 'y') {
                        localStorage.setItem(mlS_Name, materialString);
                        if (test) {
                            console.log('Setting LocalStorage: ' + mlS_Name);
                        }
                    }
                },
                error: function (data, errorCode, errorMessage) {
                    console.log('ERROR Get List Data: ' + errorMessage);
                },
                state: 'Get List Data'
            });
        }
    }
}

function fillAudience() {
    // check for existing localstorage
    var alS_Name = 'buildAudience_v1';
    var output = $('#displayAudience');   
    /*if (localStorage.getItem(alS_Name) != null && localStorageCheck == 'y') {
        // remove loading icon
        output.removeClass('sm_loading');
        // add content to div
        output.append(localStorage.getItem(alS_Name));
        if (test) {
            console.log('Using LocalStorage: ' + alS_Name);
        }
    } else {*/
        $.getScript(scriptbase + 'SP.Runtime.js',
        function () {
            $.getScript(scriptbase + 'SP.js',
                function () {
                    $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
                });
        });
        // After the cross-domain library is loaded, execution 
        function execCrossDomainRequest() {
            var executor = new SP.RequestExecutor(appUrl);
            var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('Pages')/items?&$filter=Title eq 'Audience'&@target='" + hostUrl + "'";
           
            executor.executeAsync({
                url: domain,
                method: 'GET',
                headers: { 'Accept': 'application/json; odata=verbose' },
                success: function (data, status, headers, config) {
                    var body = jQuery.parseJSON(data.body);
                    var results = body.d.results;
                    var audienceString = '';
                    $.each(results, function (index, value) {
                        properties = results[index];
                        // start fill form
                        audienceString = (properties.PublishingPageContent) + '<br />';
                        // end fill form
                    });
                    // remove loading icon
                    output.removeClass('sm_loading');
                    // add results to page
                    //output.append(audienceString);
                    output.html(audienceString);
                    /***** set Local Storage ******/
                    if (localStorageCheck == 'y') {
                        localStorage.setItem(alS_Name, audienceString);
                        if (test) {
                            console.log('Setting LocalStorage: ' + alS_Name);
                        }
                    }
                },
                error: function (data, errorCode, errorMessage) {
                    console.log('ERROR Get List Data: ' + errorMessage);
                },
                state: 'Get List Data'
            });
        }
    //}
}

function fillLookups() {
    // count 
    var countDiv = 0;
    $('.buildDropdown').each(function () {
        countDiv++;
    });
    var trackDiv = 0;
    // loop all builds
    $('.buildDropdown').each(function () {
        var dataList = $(this).data('list');
        if (dataList) { // check if data available
            var itemId = $(this).attr('id');
            var optionInput = $('#' + itemId);
            // check for existing local storage
            var lS_Name = 'buildDropdown_v5_' + itemId;
            if (localStorage.getItem(lS_Name) != null && localStorageCheck == 'y') {
                if (test) {
                    console.log('Using LocalStorage: ' + lS_Name);
                }
                optionInput.append(localStorage.getItem(lS_Name));
                trackDiv++;
            } else {
                $.getScript(scriptbase + 'SP.Runtime.js',
                function () {
                    $.getScript(scriptbase + 'SP.js',
                        function () {
                            $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
                        });
                });
                // After the cross-domain library is loaded, execution 
                function execCrossDomainRequest() {
                    var executor = new SP.RequestExecutor(appUrl);
                    var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + dataList + "')/items?$orderby=Order0 asc'&@target='" + hostUrl + "'";
                    executor.executeAsync({
                        url: domain,
                        method: 'GET',
                        headers: { 'Accept': 'application/json; odata=verbose' },
                        success: function (data, status, headers, config) {
                            var body = jQuery.parseJSON(data.body);
                            var results = body.d.results;
                            var dropdownString = '';
                            $.each(results, function (index, value) {
                                properties = results[index];
                                // start fill form
                                dropdownString = dropdownString + '<option value="' + properties.Title + '">' + properties.Title + '</option>';
                                // end fill form
                            });
                            // set input value
                            optionInput.append(dropdownString);
                            /***** set Local Storage ******/
                            if (localStorageCheck == 'y') {
                                localStorage.setItem(lS_Name, dropdownString);
                                if (test) {
                                    console.log('Setting LocalStorage: ' + lS_Name);
                                }
                            }
                            trackDiv++;
                        },
                        error: function (data, errorCode, errorMessage) {
                            $('.loading-container .messaging h1').html('Error: ' + errorMessage + ' ' + dataList);
                        },
                        state: 'Get List Data'
                    });
                }
            }
        }
    });
    // pull in attributes after all fills are complete
    var completeCheck = false;
    function checkComplete() {
        setInterval(function () {
            if (trackDiv == countDiv && completeCheck == false) {
                completeCheck = true;
                pullData(1);
                checkCurrentUser();
            } else if (trackDiv < countDiv) {
                if (test) {
                    console.log('check for completed pull: ' + countDiv + ' ' + trackDiv);
                }
            }
        }, 2000);
    }
    setTimeout(checkComplete);

}

/* pull list data */
function pullData(tab) {
    // set all variables
    var ProjectStatus1 = 0;
    var ProjectStatus2 = 0;

    var DateOfFirstUse = '';
    var cNumber;
    var turnaround = '';
    var PreviousReviewDate = '';
    var SMEPReviousReviewDate = '';
    var TypeOfMaterial_items = [];
    var DateOfVerification = '';
    var Audience_items = [];
    var Location_items = [];
    var DistributionGroup_items = [];
    var DistributionMethod_items = [];
    var TypeOfProject_items = [];
    var CategoryOfMaterial_items = [];
    var BusinessArea = '';

    var ReviewersName = '';
    var ReviewersVal = '';
    var AttorneyNameName = '';
    var AttorneyNameVal = '';
    var SecondaryReviewerVal = '';
    var DateSubmitted = '';
    var Date_x0020_Submitted_x0020_to_x0 = '';
    var DateAssigned = '';
    var ComplianceReviewCompletedDate = '';
    var DateSentToLaw = '';
    var DateCommentsReceivedFromLaw = '';
    var FilingRequired_items = [];
    var StateFilingsRequired_items = [];
    var NoFilingReasons_items = [];
    var ReviewersAssessmentOfMarketingMa_items = [];
    var TypeOfReview = '';
    var RevisionRequired = '';
    var ComplianceReviewComplete = '';
    var NewReview = '';
    var Re_x002d_Review = '';
    var Preceded = '';
    var SubmittedToLawForReview = '';
    var NoCommentsReceivedFromLaw = false;
    var TIAA_x002d_CREF_x0020_Entity_items = [];
    var MaterialReference_items = [];
    var AcknowledgeDetailsSubmitted = false;

    //Revision tab
    var From_x0020_Intended_x0020_Usage_ = '';
    var To_x0020_Intended_x0020_Usage_x0 = '';
    var ExpirationDate = '';
    var Submitter_val = '';
    var ApprovingManagerVal = '';
    var MaterialSubmittedIsWebContent = false;

    //Approval Tab
    var ApprovalDate = '';
    var isApproved = false;

    //FINRA Tab
    var FilingSubmittedOn = '';
    var ReplyDate = '';
    var TypeOfFiling = '';
    var ReplyStatus = '';
    var FiledByVal = '';

    //State Tab
    var StateFilerVal = '';    

    //Control Tab
    var UnlockSection_items = [];

    //status tab
    var dateDiscontinue = '';    

    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });

    // After the cross-domain library is loaded, execution 
    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var selectItems = '';
        var expandItems = '';
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items?$select=" + selectItems + "&$expand=" + expandItems + "&$filter=Id eq '" + idParameter + "'&@target='" + hostUrl + "'";
        if (test) {
            console.log(domain);
        }
        executor.executeAsync({
            url: domain,
            method: 'GET',
            headers: { 'Accept': 'application/json; odata=verbose' },
            success: function (data, status, headers, config) {
                var body = jQuery.parseJSON(data.body);
                var results = body.d.results;


                $.each(results, function (index, value) {
                    properties = results[index];

                    //////////////////////
                    /// STATUS SECTION ///
                    //////////////////////
                    if (properties.ProjectStatus) {
                        ProjectStatus1 = properties.ProjectStatus;
                        ProjectStatus2 = properties.ProjectStatus; // duplicated for 'discontinue status'
                        discontinueStatus = properties.ProjectStatus;
                        ProjectStatusNum = ProjectStatus1.replace('%', '');
                        /*
                        // check if sections are unlocked
                        if ($('#ProjectInformationStatus').html() == 'Unlocked') {
                            ProjectStatus1 = '1';
                            ProjectStatusNum = '25';
                            ProjectStatus2 = ProjectStatus1;
                        } else if ($('#ComplianceReviewStatus').html() == 'Unlocked') {
                            ProjectStatus1 = '2';
                            ProjectStatusNum = '50';
                            ProjectStatus2 = ProjectStatus1;
                        } else if ($('#RevisionStatus').html() == 'Unlocked' || $('#ApprovalStatus').html() == 'Unlocked') {
                            ProjectStatus1 = '3';
                            ProjectStatusNum = '75';
                            ProjectStatus2 = ProjectStatus1;
                        } else if ($('#FINRAFilingStatus').html() == 'Unlocked' || $('#StateFilingStatus').html() == 'Unlocked') {
                            ProjectStatus1 = '4';
                            ProjectStatusNum = '90';
                            ProjectStatus2 = ProjectStatus1;
                        }
                        */

                        // set values
                        if (ProjectStatus1 == 'discontinued') {
                            ProjectStatusNum = '100';
                            ProjectStatus1 = '100%';
                            ProjectStatus2 = 'Discontinued';
                        }
                        $('.progress-bar').css('width', ProjectStatus1).attr('aria-valuenow', ProjectStatusNum).html(ProjectStatus2);
                        if($('.progress-bar').text() == '100%'){
                            //$('#discontinue, #cancelDiscontinue, #DiscontinuedComments, #discontinue-H-input').attr('disabled', true);
                            $('.progress-bar').addClass('progress-bar-success');
                        }
                        if ($('.progress-bar').text() == 'Discontinued') {
                            $('.progress-bar').addClass('progress-bar-danger');
                            $('.projectDiscontinued_dis').css('color', 'd9534f').css('font-weight', 'bold');
                        }
                    }

                    ///////////////////////
                    /// OVERVIEW SECTION //
                    ///////////////////////
                    // get cnumber
                    if (properties.CNumber) {
                        cNumber = properties.CNumber;
                    } else if (properties.INumber) {
                        cNumber = properties.INumber;
                    }

                    ////////////////////////
                    /// PROJECT INFO TAB ///
                    ////////////////////////
                    // check for Business Area
                    if (properties.BusinessArea) {
                        BusinessArea = properties.BusinessArea;
                    } else {
                        BusinessArea = 'not available';
                    }
                    // check for turnaround value
                    if (properties.Turnaround) {
                        turnaround = properties.Turnaround;
                    } 
                    // check for TypeOfMaterial value(s)
                    if (properties.TypeOfMaterial) {
                        var TypeOfMaterial = properties.TypeOfMaterial;
                        var TypeOfMaterial_array = TypeOfMaterial.split('; ');
                        $.each(TypeOfMaterial_array, function (i, val) {
                            TypeOfMaterial_items.push($.trim(val));
                        });
                    }
                    // check for PreviousReviewDate value
                    if (properties.PreviousReviewDate) {
                        PreviousReviewDate = convertDate(properties.PreviousReviewDate, "date");
                    }
                    // check for SMEPReviousReviewDate value
                    if (properties.SMEPReviousReviewDate) {
                        SMEPReviousReviewDate = convertDate(properties.SMEPReviousReviewDate, "date");
                    }
                    // check for DateOfVerification value
                    if (properties.DateOfVerification) {
                        DateOfVerification = convertDate(properties.DateOfVerification, "date");
                    }
                    // check for TypeOfProject value
                    if (properties.TypeOfProject) {
                        var TypeOfProject = properties.TypeOfProject;
                        var TypeOfProject_array = TypeOfProject.split('; ');
                        $.each(TypeOfProject_array, function (i, val) {
                            TypeOfProject_items.push($.trim(val));
                        });
                    } 
                    // check for CategoryOfMaterial value
                    if (properties.CategoryOfMaterial) {
                        var CategoryOfMaterial = properties.CategoryOfMaterial;
                        var CategoryOfMaterial_array = CategoryOfMaterial.split('; ');
                        $.each(CategoryOfMaterial_array, function (i, val) {
                            CategoryOfMaterial_items.push($.trim(val));
                        });
                    } 
                    // check for Audience value(s)
                    if (properties.Audience) {
                        var Audience = properties.Audience;
                        var Audience_array = Audience.split('; ');
                        $.each(Audience_array, function (i, val) {
                            Audience_items.push($.trim(val));
                        });
                    }
                    // check for Location value(s)
                    if (properties.Location) {
                        var Location = properties.Location;
                        var Location_array = Location.split('; ');
                        $.each(Location_array, function (i, val) {
                            Location_items.push($.trim(val));
                        });
                    }
                    // check for DistributionGroup value(s)
                    if (properties.DistributionGroup) {
                        var DistributionGroup = properties.DistributionGroup;
                        var DistributionGroup_array = DistributionGroup.split('; ');
                        $.each(DistributionGroup_array, function (i, val) {
                            DistributionGroup_items.push($.trim(val));
                        });
                    }
                    // check for DistributionMethod value(s)
                    if (properties.DistributionMethod) {
                        var DistributionMethod = properties.DistributionMethod;
                        var DistributionMethod_array = DistributionMethod.split('; ');
                        $.each(DistributionMethod_array, function (i, val) {
                            DistributionMethod_items.push($.trim(val));
                        });
                    }

                    //////////////////
                    /// REVIEW TAB ///
                    //////////////////  
                    // check for Reviewers
                    if (properties.ReviewersVal) {
                        //ReviewersName = properties.Reviewers.LastName + ', ' + properties.Reviewers.FirstName;
                        ReviewersVal = properties.ReviewersVal;
                        $('.display_Reviewers span.name').html(ReviewersVal);
                        $('.display_Reviewers span.id').html('');
                    }
                    if (properties.SecondaryReviewerVal) {
                        //ReviewersName = properties.Reviewers.LastName + ', ' + properties.Reviewers.FirstName;
                        SecondaryReviewerVal = properties.SecondaryReviewerVal;
                        $('.display_SecondaryReviewer span.name').html(SecondaryReviewerVal);
                        $('.display_SecondaryReviewer span.id').html('');
                    } else if (properties.ComplianceReviewStatus == 'Submitted' && (properties.SecondaryReviewerVal == '' || properties.SecondaryReviewerVal == null)) {
                        $('.display_SecondaryReviewer span.name').html('<em>none recorded</em>');
                    }
                    // check for Attorney Name
                    if (properties.AttorneyNameVal) {
                        //AttorneyNameName = properties.AttorneyName.LastName + ', ' + properties.AttorneyName.FirstName;
                        AttorneyNameVal = properties.AttorneyNameVal;
                    }


                    // check for dates
                    if (properties.DateOfFirstUse) {
                        DateOfFirstUse = convertDate(properties.DateOfFirstUse, "date");
                    }
                    // check for DateSubmitted value
                    if (properties.DateSubmitted) {
                        DateSubmitted = convertDate(properties.DateSubmitted, "date");
                    }
                    // check for Date Submitted to MRU value
                    if (properties.Date_x0020_Submitted_x0020_to_x0) {
                        Date_x0020_Submitted_x0020_to_x0 = convertDate(properties.Date_x0020_Submitted_x0020_to_x0, "date");
                    }
                    
                    // check for DateAssigned value
                    if (properties.DateAssigned) {
                        DateAssigned = convertDate(properties.DateAssigned, "date");
                    }
                    // check for ComplianceReviewCompletedDate value
                    if (properties.ComplianceReviewCompletedDate) {
                        ComplianceReviewCompletedDate = convertDate(properties.ComplianceReviewCompletedDate, "date");
                    }
                    // check for DateSentToLaw value
                    if (properties.DateSentToLaw) {
                        DateSentToLaw = convertDate(properties.DateSentToLaw, "date");
                    }
                    // check for DateCommentsReceivedFromLaw value
                    if (properties.DateCommentsReceivedFromLaw) {
                        DateCommentsReceivedFromLaw = convertDate(properties.DateCommentsReceivedFromLaw, "date");
                    }
                    // check for FilingRequired value(s)
                    if (properties.FilingRequired) {
                        var FilingRequired = properties.FilingRequired;
                        var FilingRequired_array = FilingRequired.split('; ');
                        $.each(FilingRequired_array, function (i, val) {
                            FilingRequired_items.push($.trim(val));
                        });
                    }
                    // check for TIAA_x002d_CREF_x0020_Entity value(s)
                    if (properties.TIAA_x002d_CREF_x0020_Entity) {
                        var TIAA_x002d_CREF_x0020_Entity = properties.TIAA_x002d_CREF_x0020_Entity;
                        var TIAA_x002d_CREF_x0020_Entity_array = TIAA_x002d_CREF_x0020_Entity.split('; ');
                        $.each(TIAA_x002d_CREF_x0020_Entity_array, function (i, val) {
                            TIAA_x002d_CREF_x0020_Entity_items.push($.trim(val));
                        });
                    }
                    // check for StateFilingsRequired value(s)
                    if (properties.StateFilingsRequired) {
                        var StateFilingsRequired = properties.StateFilingsRequired;
                        var StateFilingsRequired_array = StateFilingsRequired.split('; ');
                        $.each(StateFilingsRequired_array, function (i, val) {
                            StateFilingsRequired_items.push($.trim(val));
                        });
                    }
                    // check for NoFilingReasons value(s)
                    if (properties.NoFilingReasons) {
                        var NoFilingReasons = properties.NoFilingReasons;
                        var NoFilingReasons_array = NoFilingReasons.split('; ');
                        $.each(NoFilingReasons_array, function (i, val) {
                            NoFilingReasons_items.push($.trim(val));
                        });
                    }
                    // check for DistributionMethod value(s)
                    if (properties.MaterialReference) {
                        var MaterialReference = properties.MaterialReference;
                        var MaterialReference_array = MaterialReference.split('; ');
                        $.each(MaterialReference_array, function (i, val) {
                            MaterialReference_items.push($.trim(val));
                        });
                    }
                    // check for DistributionMethod value(s)
                    if (properties.ReviewersAssessmentOfMarketingMa) {
                        var ReviewersAssessmentOfMarketingMa = properties.ReviewersAssessmentOfMarketingMa;
                        var ReviewersAssessmentOfMarketingMa_array = ReviewersAssessmentOfMarketingMa.split('; ');
                        $.each(ReviewersAssessmentOfMarketingMa_array, function (i, val) {
                            ReviewersAssessmentOfMarketingMa_items.push($.trim(val));
                        });
                    }



                    // check for TypeOfReview value
                    if (properties.TypeOfReview) {
                        TypeOfReview = properties.TypeOfReview;
                    } else {
                        TypeOfReview = 'Simple';
                    }
                    // check for RevisionRequired value
                    if (properties.RevisionRequired) {
                        RevisionRequired = properties.RevisionRequired;
                    }
                    else {
                        RevisionRequired = "Yes"; //default value
                    }
                    // check for ComplianceReviewComplete value
                    if (properties.ComplianceReviewComplete) {
                        ComplianceReviewComplete = properties.ComplianceReviewComplete;
                    } else {
                        ComplianceReviewComplete = 'Yes'; //default value
                    }
                    // check for NewReview value
                    if (properties.NewReview) {
                        NewReview = properties.NewReview;
                    } else {
                        NewReview = 'Yes'; //default value
                    }
                    // check for NewReview value
                    if (properties.Re_x002d_Review) {
                        Re_x002d_Review = properties.Re_x002d_Review;
                    } else {
                        Re_x002d_Review = 'No';
                    }
                    // check for Preceded value
                    if (properties.Preceded) {
                        Preceded = properties.Preceded;
                    }
                    // check for SubmittedToLawForReview value
                    if (properties.SubmittedToLawForReview) {
                        SubmittedToLawForReview = properties.SubmittedToLawForReview;
                    }
                    // check for NoCommentsReceivedFromLaw value
                    if (properties.NoCommentsReceivedFromLaw) {
                        NoCommentsReceivedFromLaw = 'Yes';
                    }
                    if (properties.AcknowledgeDetailsSubmitted) {
                        AcknowledgeDetailsSubmitted = true;
                    } 
                        
                    /////////////////////////////////////    
                    /// Section c tab  - Revision tab ///
                    /////////////////////////////////////
                    // dates
                    if (properties.From_x0020_Intended_x0020_Usage_) {
                        From_x0020_Intended_x0020_Usage_ = properties.From_x0020_Intended_x0020_Usage_;
                    } else {
                        From_x0020_Intended_x0020_Usage_ = DateOfFirstUse;
                    }
                    if (properties.To_x0020_Intended_x0020_Usage_x0) {
                        To_x0020_Intended_x0020_Usage_x0 = properties.To_x0020_Intended_x0020_Usage_x0;
                    }
                    if (properties.ExpirationDate) {
                        ExpirationDate = convertDate(properties.ExpirationDate, "date");
                    } else {
                        ExpirationDate = addDays(DateOfFirstUse, 364);
                    }
                    if (properties.MaterialSubmittedIsWebContent) {
                        MaterialSubmittedIsWebContent = 'Yes';
                    }
                    // check for Submitter
                    if (properties.Submitter_val) {                            
                        Submitter_val = properties.Submitter_val;
                        $('.display_Submitter span.name').html(Submitter_val);
                        $('.display_Submitter span.id').html('');
                    }
                    // check for ApprovingManager
                    if (properties.ApprovingManagerVal) {
                        //ApprovingManagerName = properties.ApprovingManager.LastName + ', ' + properties.ApprovingManager.FirstName;
                        ApprovingManagerVal = properties.ApprovingManagerVal;
                        $('.display_ApprovingManager span.name').html(ApprovingManagerVal);
                        $('.display_ApprovingManager span.id').html('');
                    }

                    /////////////////////////////////////
                    /// Section C2 tab - Approval tab ///
                    /////////////////////////////////////
                    if (properties.ApprovalDate) {
                        ApprovalDate = convertDate(properties.ApprovalDate, "date");
                        $('#ApprovalDate').prop('disabled', true)
                    }
                    // check for isApproved value
                    if (properties.isApproved) {
                        isApproved = 'Yes'; 
                    } 

                    /////////////////////////////////
                    /// Section D tab - FINRA tab ///
                    /////////////////////////////////
                    //checking for Filing submitted date
                    if (properties.FilingSubmittedOn) {
                        FilingSubmittedOn = convertDate(properties.FilingSubmittedOn, "date");
                    }
                    // check for Type of Filing value
                    if (properties.FilingType) {
                        TypeOfFiling = properties.FilingType;
                    }
                    // check for FiledBy user
                    if (properties.FiledByVal) {
                        //ApprovingManagerName = properties.ApprovingManager.LastName + ', ' + properties.ApprovingManager.FirstName;
                        FiledByVal = properties.FiledByVal;
                        $('.display_FiledBy span.name').html(FiledByVal);
                        $('.display_FiledBy span.id').html('');
                    }
                    //checking for reply date
                    if (properties.FilingReplyDate) {
                        ReplyDate = convertDate(properties.FilingReplyDate, "date");
                    }
                    else {
                        ReplyDate = properties.FilingReplyDate;
                    }
                    
                    // check for ReplyStatus value
                    if (properties.ReplyStatus) {
                        ReplyStatus = properties.ReplyStatus;
                    }
                    //check for FINRAComments

                    /////////////////////////////
                    /// Section E - State Tab ///
                    /////////////////////////////
                    // check for State Filer user
                    if (properties.StateFilerVal) {
                        //ApprovingManagerName = properties.ApprovingManager.LastName + ', ' + properties.ApprovingManager.FirstName;
                        StateFilerVal = properties.StateFilerVal;
                        $('.display_StateFiler span.name').html(StateFilerVal);
                        $('.display_StateFiler span.id').html('');
                    }

                    //Section Control tab
                    
                    if (properties.DateDiscontinued) {
                        dateDiscontinue = convertDate(properties.DateDiscontinued, "date")
                    }


                    // create array
                    var newItem = new myItems({
                        projectNameT: properties.Title,
                        cNumber: cNumber,
                        date: convertDate(properties.Date, "date"),
                        writer: properties.Submitter_val,
                        contentOwnerT: properties.Content_x0020_Owner_x0020_val,
                        SectionNumber: properties.SectionNumber,
                        dateDiscontinued: dateDiscontinue,

                        DateOfFirstUse: DateOfFirstUse,
                        projectName: properties.Title,
                        contentOwner: properties.Content_x0020_Owner_x0020_val,
                        turnaround: turnaround,
                        ProjectCNumber: properties.ProjectCNumber,
                        IsPreviouslyApproved: properties.IsPreviouslyApproved,
                        PreviousAttorneyName: properties.PreviousAttorneyName,
                        PreviousReviewDate: PreviousReviewDate,
                        IsPreviouslyApprovedBySME: properties.IsPreviouslyApprovedBySME,
                        PreviousSMEName: properties.PreviousSMEName,
                        SMEPReviousReviewDate: SMEPReviousReviewDate,
                        BusinessArea: BusinessArea,
                        CategoryOfMaterial: CategoryOfMaterial_items,
                        TypeOfProject: TypeOfProject_items,
                        AcknowledgeDetailsSubmitted: AcknowledgeDetailsSubmitted,
                        TypeOfMaterial: TypeOfMaterial_items,
                        PerformanceVerification: properties.PerformanceVerification,
                        DateOfVerification: DateOfVerification,
                        To: properties.To,
                        From: properties.From,
                        Subject: properties.Subject,
                        TypeOfMaterialOtherSelected: properties.TypeOfMaterialOtherSelected,
                        Audience: Audience_items,
                        AudienceOtherSelected: properties.AudienceOtherSelected,
                        Location: Location_items,
                        DistributionGroup: DistributionGroup_items,
                        DistributionGroupOtherSelected: properties.DistributionGroupOtherSelected,
                        DistributionMethod: DistributionMethod_items,
                        DistributeMaterialOtherSelected: properties.DistributeMaterialOtherSelected,
                        AdditionalInformation: properties.AdditionalInformation,
                        TIAA_x002d_CREF_x0020_Entity: TIAA_x002d_CREF_x0020_Entity_items,
                        MaterialReference: MaterialReference_items,
                        MaterialReferenceOther: properties.MaterialReferenceOther,

                        TurnaroundR: turnaround,
                        AttorneyName: AttorneyNameVal,
                        DateSubmitted: DateSubmitted,
                        Date_x0020_Submitted_x0020_to_x0: Date_x0020_Submitted_x0020_to_x0,
                        DateAssigned: DateAssigned,
                        ComplianceReviewCompletedDate: ComplianceReviewCompletedDate,
                        DateSentToLaw: DateSentToLaw,
                        DateCommentsReceivedFromLaw: DateCommentsReceivedFromLaw,
                        NoCommentsReceivedFromLaw: NoCommentsReceivedFromLaw,
                        NoFilingReasonsSelectedOther: properties.NoFilingReasonsSelectedOther,
                        StateFilingsSelectedOther: properties.StateFilingsSelectedOther,
                        PagesReviewed: properties.PagesReviewed,
                        ComplianceComment: properties.ComplianceComment,
                        FINRARule: properties.FINRARule,
                        ReviewersAssessmentOfMarketingMa: ReviewersAssessmentOfMarketingMa_items,
                        NoFilingReasons: NoFilingReasons_items,
                        StateFilingsRequired: StateFilingsRequired_items,
                        FilingRequired: FilingRequired_items,
                        TypeOfReview: TypeOfReview,
                        RevisionRequired: RevisionRequired,
                        ComplianceReviewComplete: ComplianceReviewComplete,
                        NewReview: NewReview,
                        Re_x002d_Review: Re_x002d_Review,
                        Preceded: Preceded,
                        SubmittedToLawForReview: SubmittedToLawForReview,

                        DateOfFirstUse2: DateOfFirstUse,
                        From_x0020_Intended_x0020_Usage_: From_x0020_Intended_x0020_Usage_,
                        To_x0020_Intended_x0020_Usage_x0: To_x0020_Intended_x0020_Usage_x0,
                        ExpirationDate: ExpirationDate,
                        IsRegisteredPrincipal: properties.IsRegisteredPrincipal,
                        TIAA_x002d_CREF_x0020_Entity_2: TIAA_x002d_CREF_x0020_Entity_items,
                        MaterialSubmittedIsWebContent: MaterialSubmittedIsWebContent,

                        ApprovalDate: ApprovalDate,
                        isApproved: isApproved,
                        ApprovalComments: properties.ApprovalComments,

                        FilingSubmittedOn: FilingSubmittedOn,
                        TypeOfFiling: TypeOfFiling,
                        FiledBy: FiledByVal,
                        ReplyDate: ReplyDate,
                        ReplyStatus: ReplyStatus,
                        FINRAComments: properties.FINFRAFilingComment,

                        StateFiler: StateFilerVal,
                        AdditionalInformationState: properties.StateAdditionalInfo,

                        CreateProjectStatus: properties.CreateProjectStatus,
                        ProjectInformationStatus: properties.ProjectInformationStatus,
                        ComplianceReviewStatus: properties.ComplianceReviewStatus,
                        RevisionStatus: properties.RevisionStatus,
                        ApprovalStatus: properties.ApprovalStatus,
                        FINRAFilingStatus: properties.FINRAFilingStatus,
                        StateFilingStatus: properties.StateFilingStatus,
                        DiscontinueComments: properties.DiscontinuedComments,


                    });


                    // build out and display on page
                    viewItems.push(newItem);
                    view_model = {
                        viewItems: kb.collectionObservable(viewItems, { view_model: kb.ViewModel })
                    };
                    ko.applyBindings(view_model, $('#kbContent')[0]);

                    if (test) {
                        console.log('List item loaded');
                    }

                    // adjust tab icons
                    adjustTabIcons();

                    // get documents
                    pullDocuments();

                });


            },
            error: function (data, errorCode, errorMessage) {
                console.log('ERROR Get List Data: ' + errorMessage);
            },
            state: 'Get List Data'
        });
    }
}

function adjustTabIcons() {
    // adjust status items
    var discontinue = $('.projectDiscontinued_dis').text();
    var status = '';
    var statusArray = ['CreateProjectStatus', 'ProjectInformationStatus', 'ComplianceReviewStatus', 'RevisionStatus', 'ApprovalStatus', 'FINRAFilingStatus', 'StateFilingStatus', 'ProjectStatus'];
    var tabArray = ['', 'infoTab', 'reviewTab', 'revisionTab', 'ApprovalTab', 'FINRATab', 'stateTab', 'documentsTab', 'statusTab', 'controlTab'];
    $.each(statusArray, function (index, value) {       
        status = properties[value];
        if (status == 'Submitted') {
            $('#' + value).prev().removeClass('glyphicon-ban-circle').addClass('glyphicon-ok-sign');
            $('#' + value).closest('.col-gray').removeClass('col-gray').addClass('alert-success');
            $('#' + tabArray[index]).children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-lock');
            if (tabArray[index] == 'stateTab') {                
                $('#StateFilingList tbody input').prop('disabled', true);
            }
        } else if (status == 'Saved') {
            $('#' + value).prev().removeClass('glyphicon-ban-circle').addClass('glyphicon-plus-sign');
            $('#' + value).closest('.col-gray').removeClass('col-gray').addClass('alert-info');            
            $('#' + tabArray[index]).children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-check');
            if ((discontinue != null) && (typeof discontinue != 'undefined') && discontinue != '') {
                $('#' + tabArray[index]).children().children().removeClass('glyphicon-check').addClass('glyphicon-lock');
            }
        } else if (status == 'Not Started') {
            $('#' + value).prev().removeClass('glyphicon-ban-circle').addClass('glyphicon-remove-sign');
            $('#' + value).closest('.col-gray').removeClass('col-gray').addClass('alert-danger');
            if ((discontinue != null) && (typeof discontinue != 'undefined') && discontinue != '') {
                $('#' + tabArray[index]).children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-lock');
            }
        } else {
            $('#' + value).html('N/A');
        }
        if (test) {
            console.log('** Status Value: ' + status);
        }


    });
}

// date adjustment function
function addDays(date, days) {
    var result = new Date(date);
    result.setDate(result.getDate() + days);
    var dd = result.getDate();
    var mm = result.getMonth() + 1;
    var y = result.getFullYear();
    var formattedDate = mm + '/' + dd + '/' + y;
    return formattedDate;
}

/* pull list data */
function pullDocuments() {
    var getControlNumber = $('span.controlNumber').html();
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });

    // After the cross-domain library is loaded, execution 
    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + docPath + "')/items?$select=File/Name,FileRef,*&$expand=File&$filter=Title eq '" + getControlNumber + "'&@target='" + hostUrl + "'";
        if (test) {
            console.log(domain);
        }
        executor.executeAsync({
            url: domain,
            method: 'GET',
            headers: { 'Accept': 'application/json; odata=verbose' },
            success: function (data, status, headers, config) {
                var body = jQuery.parseJSON(data.body);
                var results = body.d.results;
                var documents_draft = '';
                var documents_final = '';
                var documents_approved = '';
                var addPath = '';
                $.each(results, function (index, value) {
                    properties = results[index];
                    addPath = '';
                    if (properties.FileRef.search('/Communications/') > 0) {
                        addPath = '/communications/';
                    } if (properties.FileRef.search('/Documents/') > 0) {
                        addPath = '/documents/';
                    }
                    if (properties.Doc_x0020_Type == 'Draft') {
                        documents_draft = documents_draft + '<div class="draft_count hidden">1</div><div class="row row-top" data-file="' + properties.File.Name + '" data-path="' + properties.FileRef + '"><div class="col-xs-8"><a target="_blank" href="' + properties.FileRef + '"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> ' + addPath + properties.File.Name + '</a></div>' +
                        '<div class="col-xs-4 pull-right"><a class="delete hidden" data-file="' + properties.File.Name + '" data-path="' + properties.FileRef + '" data-type="Draft"><span class="glyphicon glyphicon-trash" aria-hidden="true" alt="delete"></span></a><div class="deleteloading hidden"></div></div></div>';
                    } else if (properties.Doc_x0020_Type == 'Final') {
                        documents_final = documents_final + '<div class="row row-top" data-file="' + properties.File.Name + '" data-path="' + properties.FileRef + '"><div class="col-xs-8"><a target="_blank" href="' + properties.FileRef + '"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> ' + addPath + properties.File.Name + '</a></div>' +
                        '<div class="col-xs-4 pull-right"><a class="delete hidden" data-file="' + properties.File.Name + '" data-path="' + properties.FileRef + '" data-type="Final"><span class="glyphicon glyphicon-trash" aria-hidden="true" alt="delete"></span></a><div class="deleteloading hidden"></div></div></div>';
                    } else if (properties.Doc_x0020_Type == 'Approved') {
                        documents_approved = documents_approved + '<div class="approved_count hidden">1</div><div class="row row-top" data-file="' + properties.File.Name + '" data-path="' + properties.FileRef + '"><div class="col-xs-8"><a target="_blank" href="' + properties.FileRef + '"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> ' + addPath + properties.File.Name + '</a></div>' +
                        '<div class="col-xs-4 pull-right"><a class="delete hidden" data-file="' + properties.File.Name + '" data-path="' + properties.FileRef + '" data-type="Approved"><span class="glyphicon glyphicon-trash" aria-hidden="true" alt="delete"></span></a><div class="deleteloading hidden"></div></div></div>';
                    }


                });
                // add formatting
                if (documents_draft) {
                    $('.documents_display_draft').append(documents_draft);
                }
                if (documents_final) {
                    $('.documents_display_final').append(documents_final);
                }
                if (documents_approved) {
                    $('.documents_display_approved').append(documents_approved);
                }


                if (test) {
                    console.log('Pulled Documents');
                }

                afterLoad();

            },
            error: function (data, errorCode, errorMessage) {
                console.log('ERROR Get Document Data: ' + errorMessage); 
            },
            state: 'Get Document Data'
        });
    }
}

// State grid filling
function getStateFilingDetails(action, filingStates, cNumber) {
    var getControlNumber = $('span.controlNumber').html();
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });

    function execCrossDomainRequest() {

        var executor;
        executor = new SP.RequestExecutor(appUrl);
        var stateListQueryUrl = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbyTitle('" + StateFilingList + "')/Items?&$select=ID,Title,State,Date_x0020_Filed,Date_x0020_Approved,Comment&$orderby=Created desc&$filter=Title eq '" + getControlNumber + "'&@target='" + hostUrl + "'";
        executor.executeAsync(
            {
                url: stateListQueryUrl,
                method: "GET",
                headers: { "Accept": "application/json; odata=verbose" },
                success: stateSuccessHandler,
                error: errorHandler
            }
        );
    }

    function stateSuccessHandler(data) {
        var jsonObject = JSON.parse(data.body);
        var results = jsonObject.d.results;
        if (action == 'submit' || action == 'load') {
            if (results.length > 0) {                
                deleteStateData(results, action, filingStates, cNumber);                   
                //saveStates(statesTosave, cNumber, action);
            }
            else {
                saveStates(filingStates, cNumber, action);
            }
        }
        else {

            fillData(results, StateFilingList);
        }
    }

    function errorHandler(data, errorCode, errorMessage) {
        console.log(data + ' >> ' + errorCode + ' >> ' + errorMessage);
    }

}
function fillData(results, _ListName) {
    var $appContent = $('#StateFilingList tbody');

    for (var i = 0; i < results.length; i++) {
        var dateFiledVal = '';
        var dateApprovedVal = '';
        if (results[i].Date_x0020_Filed != null){
            var dateFiledVal = convertDate(results[i].Date_x0020_Filed, "date");  
        }
        if (results[i].Date_x0020_Approved != null) {
            var dateApprovedVal = convertDate(results[i].Date_x0020_Approved, "date");
        }
        var comments = addslashes(results[i].Comment);

        var $tr = $('<tr/>');

        var $wrap = $('<div/>');
        var $in = $('<input type="text" style="padding-bottom:4px"  class="datepicker requiredText input_half rangeFull" maxlength="10" data-bind="value: DateFiled" data-validate="required" value="' + dateFiledVal + '"/>').attr('id', 'DateFiled' + i);

        var $wrap1 = $('<div/>');
        var $in2 = $('<input type="text" style="padding-bottom:4px;padding-left:20px" class="datepicker input_half rangeFull" maxlength="10" data-bind="value: DateApproved" value="' + dateApprovedVal + '"/>').attr('id', 'DateApproved' + i);

        var $wrapcomment = $('<div/>');
        var $inComment = $('<input type="text" style="padding-bottom:4px" class="stateComments input_full" maxlength="250" data-bind="value: stateFilingComments" value="' + comments + '" />').attr('id', 'stateFilingComments' + i);

        $wrap.append($in);
        $wrap1.append($in2);

        $wrapcomment.append($inComment);

        $('<td class="tdID" style="display:none;"/>').text(results[i].ID).appendTo($tr);
        $('<td class="tdState col-xs-1 col-gray" style="padding-left:10px;"/>').text(results[i].State).appendTo($tr);
        $('<td class="tdDateFiled col-xs-3 col-gray"/>').addClass("cellediting").append($wrap).appendTo($tr);
        $('<td class="tdDateApproved col-xs-3 col-gray"/>').addClass("cellediting").append($wrap1).appendTo($tr);
        $('<td class="tdComments col-xs-7 col-gray"/>').addClass("cellediting").append($wrapcomment).appendTo($tr);
        $tr.appendTo($appContent);

    }

    // activate dates for states
    $('#StateFilingList .datepicker').datepicker({ changeMonth: true, showOtherMonths: true, selectOtherMonths: true, dateFormat: 'mm/dd/yy' });

    // remove state loading icon
    $('.uploadLoading_states').addClass('hidden');

}
    //Tentative date of first use validtion

    function now() {
    var d = new Date();
    var month = d.getMonth() +1;
    var day = d.getDate();
    var date = (month < 10 ? '0' : '') + month + '/' + (day < 10 ? '0' : '') + day + '/' + d.getFullYear();

    return date;
}

$(document).on('change', '#DateOfFirstUse', function () {
    var currentDate = now();
    var val = DateOfFirstUse;
    var selectedDate = $('#DateOfFirstUse').val();
    if (selectedDate < currentDate) {
        $('#DateOfFirstUse').val(currentDate);
    }
}); 
$(document).on('change', '#DateOfFirstUse2', function () {   
    var selectedDate = $('#DateOfFirstUse2').val();   
    $('#From_x0020_Intended_x0020_Usage_').text(selectedDate);    
});



// Delete file on select
$(document).on('click', '.validation', function () {
    //$(this).hide();
});

    // Delete file on select
$(document).on('click', '.delete', function () {
    $this = $(this);
    var docType = $this.data('type');
    var docDiv = docType.toLowerCase();
    var cNumber = $('span.controlNumber').html();
    var fileName = $this.data('file');
    var path = $this.data('path');
    if (confirm('Are you sure you want to delete ' + fileName + '?')) {
        $this.addClass('hidden'); // hide delete link
        $this.nextAll('.deleteloading').removeClass('hidden'); // display loading graphic
        var domain = serviceUrl + '/api/docupload?siteUrl=' + hostUrl +
            '&docPath=' + encodeURIComponent(hostSite + path);
        if (test) {
            console.log(domain);
        }
        $.ajax({
            type: "DELETE",
            url: domain,
            xhrFields: {
                withCredentials: true
            },
            success: function (messages) {
                if (test) {
                    console.log('Doc List Name: ' + path);
                }
                $('.documents_display_' + docDiv + ' div[data-path="' + path + '"]').html(''); // remove document/item


                //check if draft files deleted before submitting the request
                if (docType == "Draft" && validatedFiles.length == 0) {
                    //$('.draft_count').html('');
                    $('.draft_count').empty();
                }
                //check if approved files deleted before submitting the request
                if (doctype == "Approved" && validatedFiles.length == 0) {
                    $('.approved_count').empty();
                }
                if (test) {
                    console.log("success: File Deleted");
                }
            },
            error: function (jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connected.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = jqXHR.responseText;
                }
                addLog('Unable to delete document: ' + msg, '', 'Delete Document');
                $this.removeClass('hidden'); // reveal delete link 
                $this.nextAll('.deleteloading').addClass('hidden'); // display loading graphic
                // error reveal
                alert('Unable to delete document');
            }
        });


    }
});

function afterLoad() {
    var discontinuestatus = '';
    // project input field .. lowercase only
    $('input#projectName').keyup(function () {
        this.value = this.value.toLowerCase();
        this.value = this.value.replace(/[^a-za-z0-9._ ]/g, '');
        this.value = this.value.replace(/[ ]/g, '_');
    });
    // numbers only
    $('input#PagesReviewed').keyup(function () {
        this.value = this.value.replace(/[^0-9]/g, '');
    });
    // date format
    $('input.datepicker').keyup(function () {
        this.value = this.value.replace(/(\d{2})(\d{2})(\d{4})/, "$1/$2/$3");
    });

    // cancel button function
    $('#cancel-A-input, #cancel-B-input, #cancel-C-input, #cancel-C2-input, #cancel-D-input, #cancel-E-input, #cancel-F-input').click(function () {
        //SP.UI.ModalDialog.commonModalDialogClose(1, 1);
        window.parent.location = hostUrl + '/Lists/' + listName + '/AllItems.aspx';
    });

    // check related content - reveal if true
    var relatedData;
    var relatedID;
    // on click
    $('input[type=checkbox]').click(function () {
        relatedID = $(this).attr('id');
        if ($(this).is(':checked')) {
            $('*[data-related="' + relatedID + '"]').removeClass('hidden');
        } else {
            $('*[data-related="' + relatedID + '"]').addClass('hidden');
            // clear values
            $('*[data-related="' + relatedID + '"] input').val('');
        }
    });
    // on click
    $('input[type=radio]').click(function () {
        relatedID = $(this).attr('id');
        if (test) {
            console.log('Radio Click: ' + relatedID);
        }
        // check Turnaround
        if ($('#Turnaround_e').is(':checked')) {
            $('#checked_reveal_Turnaround').removeClass('hidden');
        } else if ($('#Turnaround_r').is(':checked')) {
            $('#checked_reveal_Turnaround').addClass('hidden');
        }
    });

    // on change
    var selectionText;
    $('select').change(function () {
        // hide error
        $(this).nextAll('span.validation').hide();
        //
        relatedID = $(this).attr('id');
        selectionText = $('#' + relatedID + ' option:selected').text();
        if (selectionText == 'None of the above' || selectionText == 'None selected') {
            $('*[data-related="' + relatedID + '"]').addClass('hidden');
            $('#AcknowledgeDetailsSubmitted').nextAll('span.validation').hide();
            // clear values
            $('#AcknowledgeDetailsSubmitted').prop("checked", false);
        } else {
            $('*[data-related="' + relatedID + '"]').removeClass('hidden');
        }
        // check 
        if (relatedID == 'FilingRequired') {
            if (selectionText.search('FINRA') >= 0) {
                $('#checked_reveal_FS_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_FS_Other').addClass('hidden');
                // clear values
                $('#FINRARule').val('');
            }
            if (selectionText.search('State') >= 0) {
                $('#checked_reveal_State_List').removeClass('hidden');
            } else {
                $('#checked_reveal_State_List').addClass('hidden');
                // clear values
                $('#StateFilingsRequired').val('');
            }
            if (selectionText.search('None Required') >= 0) {
                $('#checked_reveal_N_nofile').removeClass('hidden');
            } else {
                $('#checked_reveal_N_nofile').addClass('hidden');
                // clear values
                $('#NoFilingReasons').val('');
            }
            // disable option handling
            if (selectionText.search('FINRA') >= 0 || selectionText.search('State') >= 0) {
                // enable FINRA/State options
                $('#FilingRequired option[value="FINRA"], #FilingRequired option[value="State Insurance Dept"]').attr('disabled', false);
                $('#FilingRequired').next('.btn-group').find('input[value="FINRA"], input[value="State Insurance Dept"]').attr('disabled', false);
                // disable None Required option
                $('#FilingRequired option[value="None Required"]').attr('disabled', 'disabled');
                $('#FilingRequired').next('.btn-group').find('input[value="None Required"]').attr('disabled', 'disabled');
            } else if (selectionText.search('None Required') >= 0) {
                // enable None Required option
                $('#FilingRequired option[value="None Required"]').attr('disabled', false);
                $('#FilingRequired').next('.btn-group').find('input[value="None Required"]').attr('disabled', false);
                // disable FINRA/State options
                $('#FilingRequired option[value="FINRA"], #FilingRequired option[value="State Insurance Dept"]').attr('disabled', 'disabled');
                $('#FilingRequired').next('.btn-group').find('input[value="FINRA"], input[value="State Insurance Dept"]').attr('disabled', 'disabled');
            } else {
                // enable all
                $('#FilingRequired option').attr('disabled', false);
                $('#FilingRequired').next('.btn-group').find('input').attr('disabled', false);
            }
        }
        // check 
        if (relatedID == 'NoFilingReasons') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_NO_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_NO_Other').addClass('hidden');
                // clear values
                $('#NoFilingReasonsSelectedOther').val('');
            }
        }

        // check Material Reference
        if (relatedID == 'MaterialReference') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_MC_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_MC_Other').addClass('hidden');
                // clear values
                $('#MaterialReferenceOther').val('');
            }
        }
        // check State Filings Required
        if (relatedID == 'StateFilingsRequired') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_S_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_S_Other').addClass('hidden');
                // clear values
                $('#StateFilingsSelectedOther').val('');
            }
        }
        // check Type Of Project
        if (relatedID == 'TypeOfProject') {
            if (selectionText.search('Streamlined') >= 0) {
                $('#checked_reveal_T_Streamlined').removeClass('hidden');
                $('#checked_reveal_C_Turnaround').addClass('hidden');
                // set default
                if ($('#Turnaround_r').not(':checked') && $('#Turnaround_e').not(':checked')) {
                    //$('#Turnaround_r').prop('checked', false);
                    //$('#Turnaround_e').prop('checked', false);
                }
                fillMaterialList('Material Categories');
            } else {
                $('#checked_reveal_T_Streamlined').addClass('hidden');
                $('#checked_reveal_C_Turnaround').removeClass('hidden');
                // clear values
                $('#AcknowledgeDetailsSubmitted').prop("checked", false);
                $('#CategoryOfMaterial').val('None selected');
                // set default
                if ($('#Turnaround_r').not(':checked') && $('#Turnaround_e').not(':checked')) {
                    //$('#Turnaround_r').prop('checked', true);
                    //$('#Turnaround_e').prop('checked', false);
                }
            }

        }
        // Audience
        if (relatedID == 'Audience') {
            if (selectionText.search('Institutional investors') >= 0) {
                $('#displayAudience').removeClass('hidden');
                fillAudience();
            }
            else {
                $('#displayAudience').addClass('hidden');
            }
        }
        // check Type of material
        if (relatedID == 'TypeOfMaterial') {
            if (selectionText.search('Email') >= 0) {
                $('#checked_reveal_Email').removeClass('hidden');
            } else {
                $('#checked_reveal_Email').addClass('hidden');
                // clear values
                $('#checked_reveal_Email input').val('');
            }
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_Other').addClass('hidden');
                // clear values
                $('#checked_reveal_Other input').val('');
            }
        }
        // check Audience
        if (relatedID == 'Audience') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_A_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_A_Other').addClass('hidden');
                // clear values
                $('#checked_reveal_A_Other input').val('');
            }
        }
        // check DistributionGroup
        if (relatedID == 'DistributionGroup') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_D_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_D_Other').addClass('hidden');
                // clear values
                $('#checked_reveal_D_Other input').val('');
            }
        }
        // check DistributionMethod
        if (relatedID == 'DistributionMethod') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_M_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_M_Other').addClass('hidden');
                // clear values
                $('#checked_reveal_M_Other input').val('');
            }
        }


    });

    // related Category of material
    if ($('#CategoryOfMaterial option:selected').text() != 'None selected') {
        $('*[data-related="CategoryOfMaterial"]').removeClass('hidden');
    }
    $('.relatedSection').each(function () {
        // on load
        relatedData = $(this).data('related');
        if ($('input[type=checkbox]#' + relatedData + '').is(':checked')) {
            $('*[data-related="' + relatedData + '"]').removeClass('hidden');
        }
        relatedID = $(this).attr('id');
        selectionText = $('#' + relatedData + ' option:selected').text();
        if (test) {
            console.log('Text: ' + selectionText);
        }

        // check 
        if (relatedID == 'checked_reveal_FS_Other') {
            if (selectionText.search('FINRA') >= 0) {
                $('#checked_reveal_FS_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_FS_Other').addClass('hidden');
            }
        }
        if (relatedID == 'checked_reveal_FS_Other') {
            if (selectionText.search('State') >= 0) {
                $('#checked_reveal_State_List').removeClass('hidden');
            } else {
                $('#checked_reveal_State_List').addClass('hidden');
            }
        }
        // check 
        if (relatedID == 'checked_reveal_N_nofile') {
            if (selectionText.search('Required') >= 0) {
                $('#checked_reveal_N_nofile').removeClass('hidden');
            } else {
                $('#checked_reveal_N_nofile').addClass('hidden');
            }
        }
        // check 
        if (relatedID == 'checked_reveal_NO_Other') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_NO_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_NO_Other').addClass('hidden');
            }
        }

        // check State Filings Required
        if (relatedID == 'checked_reveal_MC_Other') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_MC_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_MC_Other').addClass('hidden');
            }
        }
        // check Material Reference
        if (relatedID == 'checked_reveal_S_Other') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_S_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_S_Other').addClass('hidden');
            }
        }
        // check Turnaround
        if (relatedID == 'checked_reveal_Turnaround') {
            if ($('#Turnaround_e').is(':checked')) {
                $('#checked_reveal_Turnaround').removeClass('hidden');
            } else if ($('#Turnaround_r').is(':checked')) {
                $('#checked_reveal_Turnaround').addClass('hidden');
            }
        }
        // check Type Of Project
        if (relatedID == 'checked_reveal_T_Streamlined') {
            if (selectionText == 'Streamlined') {
                $('#checked_reveal_T_Streamlined').removeClass('hidden');
                $('#checked_reveal_C_Turnaround').addClass('hidden');
                fillMaterialList('Material Categories');
                // set default
                if ($('#Turnaround_r').not(':checked') && $('#Turnaround_e').not(':checked')) {
                    //$('#Turnaround_r').prop('checked', false);
                    //$('#Turnaround_e').prop('checked', false);
                }
            } else {
                $('#checked_reveal_T_Streamlined').addClass('hidden');
                // reveal if other selected, but not null
                if (selectionText != 'None selected' && selectionText != '') {
                    $('#checked_reveal_C_Turnaround').removeClass('hidden');
                }
                // set default
                if ($('#Turnaround_r').not(':checked') && $('#Turnaround_e').not(':checked')) {
                    //$('#Turnaround_r').prop('checked', true);
                    //$('#Turnaround_e').prop('checked', false);
                }
            }
        }
        // check Type of material
        if (relatedID == 'checked_reveal_Email') {
            if (selectionText.search('Email') >= 0) {
                $('#checked_reveal_Email').removeClass('hidden');
            } else {
                $('#checked_reveal_Email').addClass('hidden');
            }
        }
        if (relatedID == 'checked_reveal_Other') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_Other').addClass('hidden');
            }
        }
        // check Audience
        if (relatedID == 'checked_reveal_A_Other') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_A_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_A_Other').addClass('hidden');
            }
        }
        // check DistributionGroup
        if (relatedID == 'checked_reveal_D_Other') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_D_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_D_Other').addClass('hidden');
            }
        }
        // check DistributionMethod
        if (relatedID == 'checked_reveal_M_Other') {
            if (selectionText.search('Other') >= 0) {
                $('#checked_reveal_M_Other').removeClass('hidden');
            } else {
                $('#checked_reveal_M_Other').addClass('hidden');
            }
        }

    });
    // hide Filing Required section if Internal Project
    // check if starts with C or I
    if ($('span.controlNumber').html().charAt(0) == 'I') {
        $('#filingHiddenINumber').html('').removeClass('row-top');
    }

    // hide TIAA Entity field if Streamlined
    if ($('#TypeOfProject').val() == 'Streamlined') {
        $('#reviewTab').children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-minus');
        $('#FINRATab').children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-minus');
        $('#stateTab').children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-minus');
    } else {
        $('#TIAA_Entity_2').html('').removeClass('row-top');
    }
    // reveal Audience message
    var AudienceSelectionText = $('#Audience option:selected').text();
    if (AudienceSelectionText.search('Institutional investors') >= 0) {
        $('#displayAudience').removeClass('hidden');
        fillAudience();
    }
    // change icons on FINRA/State tabs
    var FilingRequiredSelectionText = $('#FilingRequired option:selected').text();
    if (FilingRequiredSelectionText.search('FINRA') >= 0) {
        if ($('#FINRAFilingStatus').text() == '') {
            $('#FINRAFilingStatus').prev().removeClass('glyphicon-ban-circle').addClass('glyphicon-remove-sign');
            $('#FINRAFilingStatus').closest('.col-gray').removeClass('col-gray').addClass('alert-danger');
            $('#FINRAFilingStatus').text('Not Started');
        }
    } else {
        $('#FINRATab').children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-minus');
    }
    if (FilingRequiredSelectionText.search('State') >= 0) {
        if ($('#StateFilingStatus').text() == '') {
            $('#StateFilingStatus').prev().removeClass('glyphicon-ban-circle').addClass('glyphicon-remove-sign');
            $('#StateFilingStatus').closest('.col-gray').removeClass('col-gray').addClass('alert-danger');
            $('#StateFilingStatus').text('Not Started');
        }
    } else {
        $('#stateTab').children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-minus');
    }

    // initiate multi select
    $('.multiselectDropdown').multiselect({
        maxHeight: 200,
        numberDisplayed: 100,
        delimiterText: '; '
    });
    $('.multiselectDropdownSingle').multiselect({
        maxHeight: 200,
        multiple: false,
        numberDisplayed: 1,
        onDropdownShow: function (event) {
            if (test) {
                console.log($(this));
            }
            var getID = $(this)[0]['originalOptions']['id'];
            $('select#' + getID + ' option:contains("None selected")').attr('disabled', 'disabled');
            $('#' + getID + '').next('.btn-group').find('li:nth-child(1)').addClass('disabled');
            $('#' + getID + '').next('.btn-group').find('li:nth-child(1) input').attr('disabled', 'disabled');
        },
        onDropdownHide: function (event) {

        }
    });
    // hide dropdown on mouse out
    $('.btn-group').mouseleave(function () {
        $(this).removeClass('open');
    });


    // disable fields
    // disable option handling
    if (FilingRequiredSelectionText.search('FINRA') >= 0 || FilingRequiredSelectionText.search('State') >= 0) {
        // enable FINRA/State options
        $('#FilingRequired option[value="FINRA"], #FilingRequired option[value="State Insurance Dept"]').attr('disabled', false);
        $('#FilingRequired').next('.btn-group').find('input[value="FINRA"], input[value="State Insurance Dept"]').attr('disabled', false);
        // disable None Required option
        $('#FilingRequired option[value="None Required"]').attr('disabled', 'disabled');
        $('#FilingRequired').next('.btn-group').find('input[value="None Required"]').attr('disabled', 'disabled');
    } else if (FilingRequiredSelectionText.search('None Required') >= 0) {
        // enable None Required option
        $('#FilingRequired option[value="None Required"]').attr('disabled', false);
        $('#FilingRequired').next('.btn-group').find('input[value="None Required"]').attr('disabled', false);
        // disable FINRA/State options
        $('#FilingRequired option[value="FINRA"], #FilingRequired option[value="State Insurance Dept"]').attr('disabled', 'disabled');
        $('#FilingRequired').next('.btn-group').find('input[value="FINRA"], input[value="State Insurance Dept"]').attr('disabled', 'disabled');
    } else {
        // enable all
        $('#FilingRequired option').attr('disabled', false);
        $('#FilingRequired').next('.btn-group').find('input').attr('disabled', false);
    }
    // remove disabled from li
    $('#FilingRequired').next('.btn-group').find('li').addClass('hia');

    // add image for people pickers
    //$('.peoplepicker[data-multiple=""]').after('<img src="../Images/ppicker.png" alt="People picker" />');
    //$('.peoplepicker[data-multiple="Y"]').after('<img src="../Images/mppicker.png" alt="Multi people picker" />');

    // initiate date picker
    $('.datepicker.rangeFull').datepicker({ changeMonth: true, changeYear: true, showOtherMonths: true, selectOtherMonths: true, dateFormat: 'mm/dd/yy' });
    $('.datepicker.rangeFuture').datepicker({ minDate: 0, changeMonth: true, changeYear: true, showOtherMonths: true, selectOtherMonths: true, dateFormat: 'mm/dd/yy' }); // disable old dates
    $('.datepicker.rangeSpan').datepicker({ showOtherMonths: true, changeYear: true, selectOtherMonths: true, dateFormat: 'mm/dd/yy' });
    /*
    var masks = [];
    var options;
    var DPId;
    // var buttonImage;
    $('.datepicker').each(function () {
        DPId = $(this).attr('id');
        options = {
            $el: $('#' + DPId),
            mask: "",
            isUtc: true,
            placeholder: '',                
            errorFunction: function () {
                //
            }
        }
        var mask = Mask.newMask(options);
        masks.push(mask);
    });
    */

    // reveal UNLOCK buttons 
    if (discontinueStatus != 'discontinued') {
        var controlNumber = $('span.controlNumber').html();
        // check if request outstanding, if so, reveal unlock button
        $.getScript(scriptbase + 'SP.Runtime.js',
        function () {
            $.getScript(scriptbase + 'SP.js',
                function () {
                    $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
                });
        });

        function execCrossDomainRequest() {
            var executor = new SP.RequestExecutor(appUrl);
            var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + projControlNotificationList + "')/items?$filter=Title eq '" + controlNumber + "' and Complete ne 'Y' and Complete ne 'N' &@target='" + hostUrl + "'";
            if (test) {
                console.log(domain);
            }
            executor.executeAsync({
                url: domain,
                method: "GET",
                headers: { "Accept": "application/json; odata=verbose" },
                success: function (data, status, headers, config) {
                    var body = jQuery.parseJSON(data.body);
                    var results = body.d.results;
                    $.each(results, function (index, value) {
                        var properties = results[index];
                        if (properties.UnlockSection == 'Project Information') {
                            // set Notification id
                            $('#Notification_A').html(properties.Id);
                            // hide option from Control tab
                            $('#sectionH select#UnLockSection option:contains("Information")').attr('disabled', 'disabled');
                            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(2)').addClass('disabled');
                            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(2) input').attr('disabled', 'disabled');
                            // if admin, display unlock button
                            if (isAdmin && $('#ProjectInformationStatus').text() == 'Submitted') {
                                $('#unlock-A').prop('disabled', false).removeClass('hidden');
                            }
                        } else if (properties.UnlockSection == 'Compliance/Law Review') {
                            // set Notification id
                            $('#Notification_B').html(properties.Id);
                            // hide option from Control tab
                            $('#sectionH select#UnLockSection option:contains("Compliance")').attr('disabled', 'disabled');
                            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(3)').addClass('disabled');
                            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(3) input').attr('disabled', 'disabled');
                            // if admin, display unlock button
                            if (isAdmin && $('#ComplianceReviewStatus').text() == 'Submitted') {
                                $('#unlock-B').prop('disabled', false).removeClass('hidden');
                            }
                        } else if (properties.UnlockSection == 'Revision') {
                            // set Notification id
                            $('#Notification_C').html(properties.Id);
                            // hide option from Control tab
                            $('#sectionH select#UnLockSection option:contains("Revision")').attr('disabled', 'disabled');
                            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(4)').addClass('disabled');
                            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(4) input').attr('disabled', 'disabled');
                            // if admin, display unlock button
                            if (isAdmin && $('#RevisionStatus').text() == 'Submitted') {
                                $('#unlock-C').prop('disabled', false).removeClass('hidden');
                            }
                        } else if (properties.UnlockSection == 'Approval') {
                            // set Notification id
                            $('#Notification_C2').html(properties.Id);
                            // hide option from Control tab
                            $('#sectionH select#UnLockSection option:contains("Approval")').attr('disabled', 'disabled');
                            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(5)').addClass('disabled');
                            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(5) input').attr('disabled', 'disabled');
                            // if admin, display unlock button
                            if (isAdmin && isAdmin && $('#ApprovalStatus').text() == 'Submitted') {
                                $('#unlock-C2').prop('disabled', false).removeClass('hidden');
                            }
                        } else if (properties.UnlockSection == 'FINRA Filing') {
                            // set Notification id
                            $('#Notification_D').html(properties.Id);
                            // hide option from Control tab
                            $('#sectionH select#UnLockSection option:contains("FINRA")').attr('disabled', 'disabled');
                            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(6)').addClass('disabled');
                            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(6) input').attr('disabled', 'disabled');
                            // if admin, display unlock button
                            if (isAdmin && $('#FINRAFilingStatus').text() == 'Submitted') {
                                $('#unlock-D').prop('disabled', false).removeClass('hidden');
                            }
                        } else if (properties.UnlockSection == 'State Insurance Dept. Filing') {
                            // set Notification id
                            $('#Notification_E').html(properties.Id);
                            // hide option from Control tab
                            $('#sectionH select#UnLockSection option:contains("State Insurance")').attr('disabled', 'disabled');
                            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(7)').addClass('disabled');
                            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(7) input').attr('disabled', 'disabled');
                            // if admin, display unlock button
                            if (isAdmin && $('#StateFilingStatus').text() == 'Submitted') {
                                $('#unlock-E').prop('disabled', false).removeClass('hidden');
                            }
                        } else if (properties.UnlockOrDiscontinue == 'Discontinue') {
                            // set Notification id
                            $('#Notification_discontinue').html(properties.Id);
                            $('#DiscontinueComments').val(properties.ReasonToDiscontinue);                            
                            // disable
                            $('#DiscontinuedComments, #discontinue-H-input').prop('disabled', true);
                            // hide option from Control tab
                            if (isAdmin) {
                                $('#DivdiscontinueReason').removeClass('hidden'); //.prop('disabled', false)
                                $('.discontinuebtn').prop('disabled', false).removeClass('hidden');
                                $('#cancelDiscontinue').prop('disabled', false).removeClass('hidden');
                            }
                        }
                    });
                },
                error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connected.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal Server Error [500].';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    addLog(msg, 'Status', 'Check Unlock Status');

                },
                state: "Get List Data"
            });
        }
        
    }
    



    // onClick Unlock Button from Control Tab
    $('.unlockBtn').click(function () {
        // display loading icon
        $(this).next().removeClass('hidden');
        // disable unlock button
        $(this).attr('disabled', true);
        // disable submit button on current tab
        var currentTab = $('#StartingTab').html();
        $('#submit-' + currentTab + '-input').attr('disabled', true);
        // change status
        var getId = $(this).attr('id').split('-')[1];
        setControlID('unlock-' + getId);
    });
    $('#discontinue').click(function () {
        var section = 'sectionG';
        // disable discontinue button
        $('#discontinue, #cancelDiscontinue').prop('disabled', true);
        // hide error message
        $('#' + section + ' .error, #' + section + ' span.validation').addClass('hidden');
        // show loading graphic
        $('#' + section + ' .uploadLoading').removeClass('hidden');

        if (validation(section) == 'no') {
            discontinueProject(section);
            discontinueStatus = 'discontinue';
        } else {
            $('#discontinue, #cancelDiscontinue').prop('disabled', false);
            // hide loading graphic
            $('#' + section + ' .uploadLoading').addClass('hidden');
            // error message
            $('#' + section + ' .error .error_msg').html('Validation failed');
            $('#' + section + ' .error').removeClass('hidden');
        }

    });
    $('#cancelDiscontinue').click(function () {
        var section = 'sectionG';
        // disable discontinue button
        $('#discontinue, #cancelDiscontinue, #DiscontinueComments').prop('disabled', true);
        // hide error message
        $('#' + section + ' .error, #' + section + ' span.validation').addClass('hidden');
        // show loading graphic
        $('#' + section + ' .uploadLoading').removeClass('hidden');

        discontinueStatus = 'canceldiscontinue';
        cancelDiscontinueProject(section);

    });

    // FIX MISSING STATES
    // update state list if missing data -- because execution is asnyc, sometimes the rest api delays and the states are not populated, so running the same function on page load to catch missed states.
    var getControlNumber = $('span.controlNumber').html();
    var StateFilingsRequired_items = [];
    var StateFilingsRequired = $('#StateFilingsRequired').next().children().children().html();
    if (StateFilingsRequired && StateFilingsRequired != 'None selected') {
        var StateFilingsRequired_array = StateFilingsRequired.split('; ');
        $.each(StateFilingsRequired_array, function (i, val) {
            if ($.trim(val) == 'Other') {
                StateFilingsRequired_items.push($('#StateFilingsSelectedOther').val());
            } else {
                StateFilingsRequired_items.push($.trim(val));
            }
        });
        getStateFilingDetails('load', StateFilingsRequired_items, getControlNumber);
        
    }

    // disable dropdown options if not submitted
    disableControls();

    // load workflow permissions
    setWorkflowStatus(discontinueStatus);

}

function discontinueProject(section) {
    // var discontinuestatus = 'discontinued';
    var addSection = '';
    var dateDiscontinue = now();
    addSection = "'SectionNumber': '100', ";

    exeBody = "{'__metadata': { 'type': 'SP.Data." + listName_metadata + "ListItem' }," +
        addSection +
        "'DiscontinuedComments': '" + addslashes($('#DiscontinueComments').val()) + "', " +
        "'DateDiscontinued': '" + dateDiscontinue + "'" +
            "}";
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
           function () {
               $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest2);
        });
    });
    function execCrossDomainRequest2() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items(" + idParameter + ")?@target='" + hostUrl + "'";

        executor.executeAsync({
            url: domain,
            method: 'POST',
            contentType: 'application/json;odata=verbose',
            headers: {
                'IF-MATCH': '*',
                'X-HTTP-Method': 'MERGE',
                'content-type': 'application/json; odata=verbose'
            },
            body: exeBody,
            success: function (data, status, headers, config) {
                if (test) {
                    console.log('project discontinued');
                }
                notificationId = $('#Notification_discontinue').html();
                updateNotification(notificationId, section, '')
                
            },
            error: function (jqXHR, exception) {

                // clear values, reset buttons
                
                $('#discontinue').prop('disabled', false);
                $('#discontinue').html('Discontinue Project');
               
                // hide error message on item chaneg
                $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea').bind("change paste keyup click", function () {
                    $('#' + section + ' .error').addClass('hidden'); // hide success message
                });
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connected.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.\n' + jqXHR.responseText;
                }
                addLog(msg, section, 'Notifications Discontinue Project');

            }
        });

    }
}

function cancelDiscontinueProject(section) {
    var Notification_discontinue = $('span#Notification_discontinue').text();
    $.getScript(scriptbase + 'SP.Runtime.js',
        function () {
            $.getScript(scriptbase + 'SP.js',
                function () {
                    $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest2);
                });
        });
    function execCrossDomainRequest2() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + projControlNotificationList + "')/items(" + Notification_discontinue + ")?@target='" + hostUrl + "'";
        var exeBody = "{'__metadata': { 'type': 'SP.Data." + projControlNotificationList_metadata + "ListItem' }," +
        "'Complete': 'N' " +
                "}";
        if (test) {
            console.log(domain);
        }
        executor.executeAsync({
            url: domain,
            method: 'POST',
            contentType: 'application/json;odata=verbose',
            headers: {
                'IF-MATCH': '*',
                'X-HTTP-Method': 'MERGE',
                'content-type': 'application/json; odata=verbose'
            },
            body: exeBody,
            success: function (data, status, headers, config) {

                // reveal success message
                $('#' + section + ' .success .success_msg').html('Discontinue cancelled');
                $('#' + section + ' .success').removeClass('hidden');
                // show loading graphic
                $('#' + section + ' .uploadLoading').addClass('hidden');

            },
            error: function (jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connected.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.\n' + jqXHR.responseText;
                }
                addLog(msg, section, 'Discontinue cancelled error');

            }
        });

    }
}

/* edit existing list item */
function editListItem(section, action, controlID, unlockRequest) {
    var submitterId = '';
    
    getPeople();
    function getPeople() {

        // look up valid people pickers

        var passUsers = '';
        var person = '';
        var personType;
        var key;
        var totalComplete = 0;
        var currentPerson = 0;
        //var personArrayR = [];
        var personArraySO = [];
        $('#' + section + ' .peoplepicker').each(function () {
            personType = $(this).data('person');
            person = ''; // reset
            $('.peoplepicker[data-person="' + personType + '"] .sp-peoplepicker-userSpan').each(function () {
                currentPerson++;
                person = $(this).children('.ms-entity-resolved').html();
                key = $(this).children('.ms-entity-resolved').attr('id');
                key = key.split('_')[2];
                if (test) {
                    console.log('People Scrape: ' + key);
                }
                //var getRevisor = GetUserId(key, person, personType);
                GetUserId(key, person, personType);
            });
            if (person == '') {
                currentPerson++;
                person = $('.display_' + personType + ' span.name').html();
                var userId = $('.display_' + personType + ' span.id').html();
                if (userId) {
                    passUsers = passUsers + createString(personType, person, userId);
                    if (test) {
                        console.log('no user');
                        console.log(passUsers);
                    }
                }
                totalComplete++;
            }
        });
        function GetUserId(userName, person, personType) {
            //var context = new SP.ClientContext.get_current();
            if (personType == 'Submitter') {
                submitterKey = userName;
            }
            var website = context.get_web();
            var currentUser = website.ensureUser(userName);

            context.load(website);
            context.load(currentUser);
            context.executeQueryAsync(onRequestSucceeded, onRequestFailed);

            function onRequestSucceeded() {
                var userId = currentUser.get_id();
                if (test) {
                    console.log(userId);
                }
                passUsers = passUsers + createString(personType, person, userId);
                totalComplete++;
                if (test) {
                    console.log(passUsers);
                    console.log(totalComplete);
                }
            }

            function onRequestFailed(sender, args) {
                if (test) {
                    console.log('Error: ' + args.get_message());
                }
            }

        }

        function createString(personType, person, userId) {
            var value = '';
            if (personType == 'contentOwner') {
                value = "'Content_x0020_Owner_x0020_val': '" + person + "', 'Content_x0020_OwnerId': " + userId + ", ";
            } else if (personType == 'Reviewers') {
                value = "'ReviewersVal': '" + person + "', 'ReviewersId': " + userId + ", ";
            } else if (personType == 'AttorneyName') {
                value = "'AttorneyNameVal': '" + person + "', 'AttorneyNameId': " + userId + ", ";
            } else if (personType == 'SecondaryReviewer') {
                personArraySO.push({
                    0: person,
                    1: userId
                });
                //value = "'SecondaryReviewerVal': '" + person + "', 'SecondaryReviewerId': " + userId + ", ";                   
            } else if (personType == 'ApprovingManager') {
                value = "'ApprovingManagerVal': '" + person + "', 'ApprovingManagerId': " + userId + ", ";
            } else if (personType == 'FiledBy') {
                value = "'FiledByVal': '" + person + "', 'FiledById': " + userId + ", ";
            } else if (personType == 'StateFiler') {
                value = "'StateFilerVal': '" + person + "', 'StateFilerId': " + userId + ", ";
            } else if (personType == 'Submitter') {
                value = "'Submitter_val': '" + person + "', 'WriterId': " + userId + ", ";
            }
            if (test) {
                console.log(value);
            }
            return value;
        }


        // loop until all people are pulled
        var completeCheck = false;
        var countLoops = 0;
        var complete = false;
        function checkComplete() {
            if (test) {
                console.log('Checking Complete...');
            }
            setInterval(function () {
                countLoops++;
                if (countLoops == 10 && complete == false) {
                    // throw error, lookup is not working right
                    addLog('Issue resolving people pickers. Please try again.', section, 'Edit');
                } else if (totalComplete == currentPerson && completeCheck == false) {
                    completeCheck = true;
                    if (test) {
                        console.log('people string: ' + passUsers);
                    }
                    // check all secondary reviewers
                    var passSOUser = '';
                    var passSOUserId = '';
                    //console.log(personArraySO);
                    $.each(personArraySO, function (index, value) {
                        passSOUser = passSOUser + value[0] + '; ';
                        passSOUserId = passSOUserId + value[1] + ',';
                    });
                    if (test) {
                        console.log('Length of personArraySO: ' + personArraySO.length);
                    }
                    if (personArraySO.length > 0) {
                        passUsers = passUsers + "'SecondaryReviewerVal': '" + passSOUser + "', 'SecondaryReviewerId': {'results': [" + passSOUserId.slice(0, -1) + "]}, ";
                    }
                    complete = true;
                    completeAddItem(passUsers, unlockRequest);
                } else if (totalComplete < currentPerson) {
                    if (test) {
                        console.log('check for completed people picker pull: ' + totalComplete + ' ' + currentPerson);
                        console.log('people string: ' + passUsers);
                    }
                } else {
                    if (test) {
                        //console.log(totalComplete + ' ' + currentPerson);
                        //console.log('else... people string: ' + passUsers);
                    }
                }
            }, 2000);
        }
        setTimeout(checkComplete);


    }



    function completeAddItem(passUsers, unlockRequest) {
        
        $.getScript(scriptbase + 'SP.Runtime.js',
        function () {
            $.getScript(scriptbase + 'SP.js',
                function () {
                    $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
                });
        });
        function execCrossDomainRequest() {
            var executor = new SP.RequestExecutor(appUrl);
            var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items(" + idParameter + ")?@target='" + hostUrl + "'";
            var exeBody = '';
            var exeBody2 = '';

            // get current status'
            var ProjectInformationStatus = $('#ProjectInformationStatus').text();
            var ComplianceReviewStatus = $('#ComplianceReviewStatus').text();
            var RevisionStatus = $('#RevisionStatus').text();
            var ApprovalStatus = $('#ApprovalStatus').text();
            var FINRAFilingStatus = $('#FINRAFilingStatus').text();
            var StateFilingStatus = $('#StateFilingStatus').text();

            if (section == 'sectionA') {
                ///////////////////////////
                /// PROJECT INFORMATION ///
                ///////////////////////////
                var Turnaround;
                if ($('#Turnaround_r').is(':checked')) {
                    Turnaround = 'Routine';
                } else if ($('#Turnaround_e').is(':checked')) {
                    Turnaround = 'Expedited';
                }
                var OtherMaterialsIncluded = 'No';
                if ($('#projectName').val()) {
                    OtherMaterialsIncluded = 'Yes';
                }

                var IsPreviouslyApproved = '';
                var PreviousReviewDate = null;
                if ($('#IsPreviouslyApproved').is(':checked')) {
                    IsPreviouslyApproved = 'Yes';
                    PreviousReviewDate = "'" + $('#PreviousReviewDate').val() + "'";
                }
                var IsPreviouslyApprovedBySME = '';
                var SMEPReviousReviewDate = null;
                if ($('#IsPreviouslyApprovedBySME').is(':checked')) {
                    IsPreviouslyApprovedBySME = 'Yes';
                    SMEPReviousReviewDate = "'" + $('#SMEPReviousReviewDate').val() + "'";
                }
                var AcknowledgeDetailsSubmitted = false;
                if ($('#AcknowledgeDetailsSubmitted').is(':checked')) {
                    AcknowledgeDetailsSubmitted = true;
                }
                var PerformanceVerification = '';
                var DateOfVerification = null;
                if ($('#PerformanceVerification').is(':checked')) {
                    PerformanceVerification = 'Yes';
                    DateOfVerification = "'" + $('#DateOfVerification').val() + "'";
                }

                var dateSubmitted = fillDate();
                if (test) {
                    console.log(DateOfFirstUse);
                }

                var status = 'Saved';
                var addSection = '';
                if (action == 'submit') {
                    status = 'Submitted';
                    // get sectionnumber
                    var SectionNumber = $('#SectionNumber').text();
                    if (ApprovalStatus == 'Submitted' && (FINRAFilingStatus == 'N/A' || FINRAFilingStatus == 'Submitted') && (StateFilingStatus == 'N/A' || StateFilingStatus == 'Submitted')) {
                        addSection = "'SectionNumber': '5', " +
                            "'Moved': 'No', ";
                    } else if (ApprovalStatus == 'Submitted' && (FINRAFilingStatus != 'N/A' || StateFilingStatus != 'N/A')) {
                        addSection = "'SectionNumber': '4', ";
                    } else if (ComplianceReviewStatus == 'Submitted') {
                        addSection = "'SectionNumber': '3', ";
                    } else if ($('#TypeOfProject').val() != 'Streamlined' && SectionNumber < '2') {
                        addSection = "'SectionNumber': '2', ";
                    } else if (SectionNumber < '3') {
                        addSection = "'SectionNumber': '3', ";
                    }
                }
                var TypeOfMaterial = '';
                if ($('#TypeOfMaterial').val() && (typeof $('#TypeOfMaterial').val() != 'undefined')) {
                    TypeOfMaterial = convertDropDown($('#TypeOfMaterial').val());
                    //TypeOfMaterial = $('#TypeOfMaterial').next().children().attr('title');
                }
                var Audience = '';
                if ($('#Audience').val() && (typeof $('#Audience').val() != 'undefined')) {
                    Audience = convertDropDown($('#Audience').val());
                    //Audience = $('#Audience').next().children().attr('title');
                }
                var Location = '';
                if ($('#Location').val() && (typeof $('#Location').val() != 'undefined')) {
                    Location = convertDropDown($('#Location').val());
                    //Location = $('#Location').next().children().attr('title');
                }
                var DistributionGroup = '';
                if ($('#DistributionGroup').val() && (typeof $('#DistributionGroup').val() != 'undefined')) {
                    DistributionGroup = convertDropDown($('#DistributionGroup').val());
                    //DistributionGroup = $('#DistributionGroup').next().children().attr('title');
                }
                var DistributionMethod = '';
                if ($('#DistributionGroup').val() && (typeof $('#DistributionMethod').val() != 'undefined')) {
                    DistributionMethod = convertDropDown($('#DistributionMethod').val());
                    //DistributionMethod = $('#DistributionMethod').next().children().attr('title');
                }
                var CategoryOfMaterial = '';
                if ($('#CategoryOfMaterial').val() && (typeof $('#CategoryOfMaterial').val() != 'undefined')) {
                    CategoryOfMaterial = convertDropDown($('#CategoryOfMaterial').val());
                    //CategoryOfMaterial = $('#CategoryOfMaterial').next().children().attr('title');
                }
                
                // update Review status
                var complianceStatus = '';
                if (action == 'submit') {
                    if ($('#TypeOfProject').val() == 'Streamlined') {
                        complianceStatus = "'ComplianceReviewStatus': '', " +
                        "'FINRAFilingStatus': '', " +
                        "'StateFilingStatus': '', " +
                        "'MaterialReference': 'N/A', ";
                    } else if ($('#ComplianceReviewStatus').html() == '' || $('#ComplianceReviewStatus').html() == 'N/A') {
                        complianceStatus = "'ComplianceReviewStatus': 'Not Started', ";
                    }
                }
                exeBody = "{'__metadata': { 'type': 'SP.Data." + listName_metadata + "ListItem' }," +
                    addSection +
                    "'Title': '" + addslashes($('#projectName').val()) + "', " +
                    passUsers +
                    complianceStatus +
                    "'OtherMaterialsIncluded': '" + OtherMaterialsIncluded + "', " +
                    "'DateOfFirstUse': '" + $('#DateOfFirstUse').val() + "', " +
                    "'ProjectCNumber': '" + addslashes($('#ProjectCNumber').val()) + "', " +
                    "'Turnaround': '" + Turnaround + "'," +
                    "'IsPreviouslyApproved': '" + IsPreviouslyApproved + "', " +
                    "'PreviousAttorneyName': '" + addslashes($('#PreviousAttorneyName').val()) + "', " +
                    "'PreviousReviewDate': " + PreviousReviewDate + ", " +
                    "'IsPreviouslyApprovedBySME': '" + IsPreviouslyApprovedBySME + "', " +
                    "'PreviousSMEName': '" + addslashes($('#PreviousSMEName').val()) + "', " +
                    "'SMEPReviousReviewDate': " + SMEPReviousReviewDate + ", " +
                    "'TypeOfProject': '" + $('#TypeOfProject').val() + "', ";
                exeBody2 = "'CategoryOfMaterial': '" + CategoryOfMaterial + "', " +
                    "'AcknowledgeDetailsSubmitted': " + AcknowledgeDetailsSubmitted + ", " +
                    "'TypeOfMaterial': '" + TypeOfMaterial + "', " +
                    "'TypeOfMaterialOtherSelected': '" + addslashes($('#TypeOfMaterialOtherSelected').val()) + "', " +
                    "'PerformanceVerification': '" + PerformanceVerification + "', " +
                    "'DateOfVerification': " + DateOfVerification + ", " +
                    "'To': '" + addslashes($('#To').val()) + "', " +
                    "'From': '" + addslashes($('#From').val()) + "', " +
                    "'Subject': '" + addslashes($('#Subject').val()) + "', " +
                    "'Audience': '" + Audience + "', " +
                    "'AudienceOtherSelected': '" + addslashes($('#AudienceOtherSelected').val()) + "', " +
                    "'Location': '" + Location + "', " +
                    "'DistributionGroup': '" + DistributionGroup + "', " +
                    "'DistributionGroupOtherSelected': '" + addslashes($('#DistributionGroupOtherSelected').val()) + "', " +
                    "'DistributionMethod': '" + DistributionMethod + "', " +
                    "'DistributeMaterialOtherSelected': '" + addslashes($('#DistributeMaterialOtherSelected').val()) + "', " +
                    "'AdditionalInformation': '" + addslashes($('#AdditionalInformation').val()) + "', " +
                    "'DateSubmitted': '" + dateSubmitted + "', " +
                    "'Date_x0020_Submitted_x0020_to_x0': '" + dateSubmitted + "', " +
                    "'ProjectInformationStatus': '" + status + "'" +
                    "}";

            } else if (section == 'sectionB') {
                /////////////////////////
                /// COMPLIANCE REVIEW ///
                /////////////////////////
                var TypeOfReview;
                if ($('#TypeOfReview_s').is(':checked')) {
                    TypeOfReview = 'Simple';
                } else if ($('#TypeOfReview_c').is(':checked')) {
                    TypeOfReview = 'Complex';
                }
                var RevisionRequired = 'No';
                if ($('#RevisionRequired_y').is(':checked')) {
                    RevisionRequired = 'Yes';
                }
                var ComplianceReviewComplete = 'No';
                if ($('#ComplianceReviewComplete_y').is(':checked')) {
                    ComplianceReviewComplete = 'Yes';
                }
                var NewReview = 'No';
                if ($('#NewReview_y').is(':checked')) {
                    NewReview = 'Yes';
                }
                var Re_x002d_Review = 'No';
                if ($('#Re_x002d_Review_y').is(':checked')) {
                    Re_x002d_Review = 'Yes';
                }
                var Preceded = 'No';
                if ($('#Preceded_y').is(':checked')) {
                    Preceded = 'Yes'; 
                } else if ($('#Preceded_na').is(':checked')) {
                    Preceded = 'Not Applicable';
                }
                var NoFilingReasons = '';
                if ($('#NoFilingReasons').val() && (typeof $('#NoFilingReasons').val() != 'undefined')) {
                    NoFilingReasons = convertDropDown($('#NoFilingReasons').val());
                    //NoFilingReasons = $('#NoFilingReasons').next().children().attr('title');
                }

                var passLaw = '';
                if ($('#SubmittedToLawForReview').is(':checked')) {
                    var DateSentToLaw = '';
                    if ($('#DateSentToLaw').val() != '') {
                        DateSentToLaw = "'DateSentToLaw': '" + $('#DateSentToLaw').val() + "', ";
                    }
                    var DateCommentsReceivedFromLaw = '';
                    if ($('#DateCommentsReceivedFromLaw').val() != '') {
                        DateCommentsReceivedFromLaw = "'DateCommentsReceivedFromLaw': '" + $('#DateCommentsReceivedFromLaw').val() + "', ";
                    }
                    var NoCommentsReceivedFromLaw = false;
                    if ($('#NoCommentsReceivedFromLaw').is(':checked')) {
                        NoCommentsReceivedFromLaw = "'NoCommentsReceivedFromLaw': true, ";
                    } else {
                        NoCommentsReceivedFromLaw = "'NoCommentsReceivedFromLaw': false, ";
                    }

                    passLaw = "'SubmittedToLawForReview': 'Yes', " + DateCommentsReceivedFromLaw + DateSentToLaw + NoCommentsReceivedFromLaw;
                }



                var status = 'Saved';
                var addSection = '';
                if (action == 'submit') {
                    status = 'Submitted';
                    // get sectionnumber
                    var SectionNumber = $('#SectionNumber').text();
                    if (ApprovalStatus == 'Submitted' && (FINRAFilingStatus == 'N/A' || FINRAFilingStatus == 'Submitted') && (StateFilingStatus == 'N/A' || StateFilingStatus == 'Submitted')) {
                        addSection = "'SectionNumber': '5', " +
                            "'Moved': 'No', ";
                    } else if (ApprovalStatus == 'Submitted' && (FINRAFilingStatus != 'N/A' || StateFilingStatus != 'N/A')) {
                        addSection = "'SectionNumber': '4', ";
                    } if (SectionNumber < '3') {
                        addSection = "'SectionNumber': '3', ";
                    }
                }

                // define variables if Control Number IS NOT internal
                var filingRequiredEntry = '';
                if ($('span.controlNumber').html().charAt(0) == 'C') {
                    var FilingRequired = '';
                    if ($('#FilingRequired').val() && (typeof $('#FilingRequired').val() != 'undefined')) {
                        FilingRequired = convertDropDown($('#FilingRequired').val());
                        //FilingRequired = $('#FilingRequired').next().children().attr('title');
                    }
                    var StateFilingsRequired = '';
                    if ($('#StateFilingsRequired').val() && (typeof $('#StateFilingsRequired').val() != 'undefined')) {
                        StateFilingsRequired = convertDropDown($('#StateFilingsRequired').val());
                        //StateFilingsRequired = $('#StateFilingsRequired').next().children().attr('title');
                    }

                    filingRequiredEntry = "'FilingRequired': '" + FilingRequired + "', " +
                    "'FINRARule': '" + addslashes($('#FINRARule').val()) + "', " +
                    "'StateFilingsRequired': '" + StateFilingsRequired + "', " +
                    "'StateFilingsSelectedOther': '" + addslashes($('#StateFilingsSelectedOther').val()) + "', ";
                    //}

                    // update status'
                    var updateStatus = '';
                    if (action == 'submit') {
                        var FilingRequiredSelectionText = $('#FilingRequired').nextAll('.btn-group').children().attr('title');
                        if ($('#TypeOfProject').val() != 'Streamlined') {
                            if (FilingRequiredSelectionText.search('FINRA') >= 0 && ($('#FINRAFilingStatus').html() == '' || $('#FINRAFilingStatus').html() == 'N/A')) {
                                updateStatus = updateStatus + "'FINRAFilingStatus': 'Not Started', ";
                            } else if (FilingRequiredSelectionText.search('FINRA') >= 0) {

                            } else {
                                updateStatus = updateStatus + "'FINRAFilingStatus': '', ";
                            }
                            if (FilingRequiredSelectionText.search('State') >= 0 && ($('#StateFilingStatus').html() == '' || $('#StateFilingStatus').html() == 'N/A')) {
                                updateStatus = updateStatus + "'StateFilingStatus': 'Not Started', ";
                            } else if (FilingRequiredSelectionText.search('State') >= 0) {

                            } else {
                                updateStatus = updateStatus + "'StateFilingStatus': '', ";
                            }
                        }
                    }
                    //State Filing list data insert
                    if (action == 'submit') {
                        //var rest_data = [];
                        var rest_data = '';
                        var cNumber = $('span.controlNumber').html();
                        var filingStates = [];
                        if (StateFilingsRequired != null && StateFilingsRequired != '') {
                            filingStates = StateFilingsRequired.split('; ');
                            filingStates_Update = StateFilingsRequired.split('; ');
                            if ($.inArray('Other', filingStates) > -1) {
                                var removeOthers = 'Other';
                                filingStates.splice($.inArray(removeOthers, filingStates), 1);
                                filingStates.push(addslashes($('#StateFilingsSelectedOther').val()));
                                filingStates_Update.splice($.inArray(removeOthers, filingStates), 1);
                                filingStates_Update.push(addslashes($('#StateFilingsSelectedOther').val()));

                            }
                        }
                    }
                }
                var TIAA_x002d_CREF_x0020_Entity = '';
                if ($('#TIAA_x002d_CREF_x0020_Entity').val() && (typeof $('#TIAA_x002d_CREF_x0020_Entity').val() != 'undefined')) {
                    TIAA_x002d_CREF_x0020_Entity = convertDropDown($('#TIAA_x002d_CREF_x0020_Entity').val());
                    //TIAA_x002d_CREF_x0020_Entity = $('#TIAA_x002d_CREF_x0020_Entity').next().children().attr('title');
                }
                var MaterialReference = '';
                if ($('#MaterialReference').val() && (typeof $('#MaterialReference').val() != 'undefined')) {
                    MaterialReference = convertDropDown($('#MaterialReference').val());
                   // MaterialReference = $('#MaterialReference').next().children().attr('title');
                }
                
                ////////////////////////////
                if ($('span.controlNumber').html().charAt(0) == 'C') {
                    exeBody = "{'__metadata': { 'type': 'SP.Data." + listName_metadata + "ListItem' }," +
                   addSection +
                   "'TypeOfReview': '" + TypeOfReview + "', " +
                   passUsers +
                   filingRequiredEntry +
                   updateStatus +
                   "'DateSubmitted': '" + $('#DateSubmitted').val() + "', " +
                   "'DateAssigned': '" + $('#DateAssigned').val() + "', " +
                   "'PagesReviewed': '" + addslashes($('#PagesReviewed').val()) + "', " +
                   "'RevisionRequired': '" + RevisionRequired + "', " +
                   "'ComplianceReviewComplete': '" + ComplianceReviewComplete + "', " +
                   "'NewReview': '" + NewReview + "', " +
                   "'Re_x002d_Review': '" + Re_x002d_Review + "', " +
                   "'Preceded': '" + Preceded + "', ";
                } else {
                    exeBody = "{'__metadata': { 'type': 'SP.Data." + listName_metadata + "ListItem' }," +
                        addSection +
                        "'TypeOfReview': '" + TypeOfReview + "', " +
                        passUsers +                                                
                        "'DateSubmitted': '" + $('#DateSubmitted').val() + "', " +
                        "'DateAssigned': '" + $('#DateAssigned').val() + "', " +
                        "'PagesReviewed': '" + addslashes($('#PagesReviewed').val()) + "', " +
                        "'RevisionRequired': '" + RevisionRequired + "', " +
                        "'ComplianceReviewComplete': '" + ComplianceReviewComplete + "', " +
                        "'NewReview': '" + NewReview + "', " +
                        "'Re_x002d_Review': '" + Re_x002d_Review + "', " +
                        "'Preceded': '" + Preceded + "', ";
                }
                exeBody2 = "'NoFilingReasons': '" + NoFilingReasons + "', " +
                    "'NoFilingReasonsSelectedOther': '" + addslashes($('#NoFilingReasonsSelectedOther').val()) + "', " +
                    "'TIAA_x002d_CREF_x0020_Entity': '" + TIAA_x002d_CREF_x0020_Entity + "', " +
                    "'MaterialReference': '" + MaterialReference + "', " +
                    "'MaterialReferenceOther': '" + $('#MaterialReferenceOther').val() + "', " +
                    "'ComplianceComment': '" + addslashes($('#ComplianceComment').val()) + "', " +
                    "'ComplianceReviewCompletedDate': '" + $('#ComplianceReviewCompletedDate').val() + "', " +
                    passLaw +
                    "'ReviewersAssessmentOfMarketingMa': '" + addslashes($('#ReviewersAssessmentOfMarketingMa').val()) + "', " +
                    "'ComplianceReviewStatus': '" + status + "'" +
                    "}";
            } else if (section == 'sectionC') {
                  ////////////////
                 /// REVISION ///
                ////////////////

                var IsRegisteredPrincipal = 'No';
                if ($('#IsRegisteredPrincipal_y').is(':checked')) {
                    IsRegisteredPrincipal = 'Yes';
                }
                var MaterialSubmittedIsWebContent = 'false';
                if ($('#MaterialSubmittedIsWebContent').is(':checked')) {
                    MaterialSubmittedIsWebContent = 'true';
                }
                var TIAA_x002d_CREF_x0020_Entity_2 = '';
                if ($('#TIAA_x002d_CREF_x0020_Entity_2').val() && (typeof $('#TIAA_x002d_CREF_x0020_Entity_2').val() != 'undefined')) {
                    TIAA_x002d_CREF_x0020_Entity_2 = "'TIAA_x002d_CREF_x0020_Entity': '" + $('#TIAA_x002d_CREF_x0020_Entity_2').val() + "', ";
                    //TIAA_x002d_CREF_x0020_Entity_2 = "'TIAA_x002d_CREF_x0020_Entity': '" + $('#TIAA_x002d_CREF_x0020_Entity_2').next().children().attr('title') + "', ";
                }

                var status = 'Saved';
                var addSection = '';
                if (action == 'submit') {
                    status = 'Submitted';
                    // get sectionnumber
                    var SectionNumber = $('#SectionNumber').text();
                    if (ApprovalStatus == 'Submitted' && (FINRAFilingStatus == 'N/A' || FINRAFilingStatus == 'Submitted') && (StateFilingStatus == 'N/A' || StateFilingStatus == 'Submitted')) {
                        addSection = "'SectionNumber': '5', " +
                            "'Moved': 'No', ";
                    } else if (ApprovalStatus == 'Submitted' && (FINRAFilingStatus != 'N/A' || StateFilingStatus != 'N/A')) {
                        addSection = "'SectionNumber': '4', ";
                    } if (SectionNumber < '3') {
                        addSection = "'SectionNumber': '3', ";
                    }
                }
                exeBody = "{'__metadata': { 'type': 'SP.Data." + listName_metadata + "ListItem' }," +
                    addSection +
                    "'MaterialSubmittedIsWebContent': " + MaterialSubmittedIsWebContent + ", " +
                    "'DateOfFirstUse': '" + $('#DateOfFirstUse2').val() + "', " +
                    "'From_x0020_Intended_x0020_Usage_': '" + $('#DateOfFirstUse2').val() + "', " +
                    "'To_x0020_Intended_x0020_Usage_x0': '" + $('#To_x0020_Intended_x0020_Usage_x0').val() + "', " +
                    "'ExpirationDate': '" + $('#ExpirationDate').val() + "', " +
                    passUsers +
                    TIAA_x002d_CREF_x0020_Entity_2 + 
                    "'IsRegisteredPrincipal': '" + IsRegisteredPrincipal + "', " +
                    "'RevisionStatus': '" + status + "'" +
                    "}";
                exeBody2 = '';

            } else if (section == 'sectionC2') {
                  ////////////////
                 /// APPROVAL ///
                ////////////////
                var isApproved = 'No'; 
                if ($('#isApproved').is(':checked')) {
                    isApproved = 'Yes';
                }
                var status = 'Saved';
                var addSection = '';
                if (action == 'submit') {
                    status = 'Submitted';
                    // get sectionnumber
                    var SectionNumber = $('#SectionNumber').text();
                    if (((FINRAFilingStatus == 'Submitted' || FINRAFilingStatus == 'N/A') && (StateFilingStatus == 'Submitted' || StateFilingStatus == 'N/A')) && SectionNumber < '5') {
                        addSection = "'SectionNumber': '5', " +
                            "'Moved': 'No', ";
                    } else if ($('#CategoryOfMaterial').val() == 'None of the above' && SectionNumber < '4') {
                        addSection = "'SectionNumber': '4', ";
                    } else if (SectionNumber < '4') {
                        addSection = "'SectionNumber': '4', ";
                    }
                }
                exeBody = "{'__metadata': { 'type': 'SP.Data." + listName_metadata + "ListItem' }," +
                    addSection +
                    "'isApproved': '" + isApproved + "', " + 
                    "'ApprovalDate': '" + $('#ApprovalDate').val() + "', " +
                    "'ApprovalComments': '" + addslashes($('#ApprovalComments').val()) + "', " +
                    "'ApprovalStatus': '" + status + "'" +
                        "}";
                exeBody2 = '';
            } else if (section == 'sectionD') {
                  /////////////
                 /// FINRA ///
                /////////////
                var TypeOfFiling;
                if ($('#TypeOfFiling_e').is(':checked')) {
                    TypeOfFiling = 'Expedited';
                } else if ($('#TypeOfFiling_r').is(':checked')) {
                    TypeOfFiling = 'Routine';
                }
                var ReplyStatus;
                if ($('#ReplyStatus_c').is(':checked')) {
                    ReplyStatus = 'Clean';
                } else if ($('#ReplyStatus_d').is(':checked')) {
                    ReplyStatus = 'Dirty';
                } else if ($('#ReplyStatus_u').is(':checked')) {
                    ReplyStatus = 'Do not use';
                } else if ($('#ReplyStatus_n').is(':checked')) {
                    ReplyStatus = 'Need more information';
                }
                var replyDate;
                if ($('#ReplyDate').val() != "") {
                    replyDate = "'" + $('#ReplyDate').val() + "'";
                } else {
                    replyDate = null;
                }
                var status = 'Saved';
                var addSection = '';
                if (action == 'submit') {
                    status = 'Submitted';
                    // get sectionnumber
                    var StateFilingStatus = $('#StateFilingStatus').text();
                    var SectionNumber = $('#SectionNumber').text();
                    if ((StateFilingStatus == 'Submitted' || StateFilingStatus == 'N/A') && SectionNumber < '5') {
                        addSection = "'SectionNumber': '5', " +
                            "'Moved': 'No', ";
                    } 
                }

                ////////////////////////////
                exeBody = "{'__metadata': { 'type': 'SP.Data." + listName_metadata + "ListItem' }," +
                    addSection +
                    "'FilingSubmittedOn': '" + $('#FilingSubmittedOn').val() + "', " +
                    "'FilingType': '" + TypeOfFiling + "', " +
                        passUsers +
                    "'FilingReplyDate': " + replyDate + ", " +
                     "'ReplyStatus': '" + ReplyStatus + "', " +
                      "'FINFRAFilingComment': '" + addslashes($('#FINRAComments').val()) + "', " +
                    "'FINRAFilingStatus': '" + status + "'" +
                        "}";
                exeBody2 = '';
            } else if (section == 'sectionE') {
                  /////////////
                 /// STATE ///
                /////////////

                var status = 'Saved';
                var addSection = '';
                if (action == 'submit') {
                    status = 'Submitted';
                    // get sectionnumber
                    var FINRAFilingStatus = $('#FINRAFilingStatus').text();
                    var SectionNumber = $('#SectionNumber').text();
                    if ((FINRAFilingStatus == 'Submitted' || FINRAFilingStatus == 'N/A') && SectionNumber < '5') {
                        addSection = "'SectionNumber': '5', " +
                            "'Moved': 'No', ";
                    }
                }
                
                ////////////////////////////
                exeBody = "{'__metadata': { 'type': 'SP.Data." + listName_metadata + "ListItem' }," +
                    addSection +
                    passUsers +
                    "'StateAdditionalInfo': '" + $('#AdditionalInformationState').val() + "', " +
                    "'StateFilingStatus': '" + status + "'" +
                        "}";
                exeBody2 = '';
            } 
            if (test) {
                console.log('REST: ' + exeBody + exeBody2);
            }
            if (exeBody) {

                // Add to list
                executor.executeAsync({
                    url: domain,
                    method: 'POST',
                    contentType: 'application/json;odata=verbose',
                    headers: {
                        'IF-MATCH': '*',
                        'X-HTTP-Method': 'MERGE',
                        'content-type': 'application/json; odata=verbose'
                    },
                    body: exeBody + exeBody2,
                    success: function (data, status, headers, config) {
                        ///// ***** SAVE PROJECT ***** /////
                        if (section == 'sectionA') {
                            if (test) {
                                console.log('Edit project successful')
                            }

                            // upload file
                            uploadFile('Draft', action, section, controlID, unlockRequest);
                            if (action == 'edit') {
                                $('#infoTab').children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-check');
                                $('#ProjectInformationStatus').closest('.col-gray').removeClass('col-gray').addClass('alert-info');
                            }
                        }
                        ///// ***** SAVE REVIEW ***** /////
                        if (section == 'sectionB') {
                            if (test) {
                                console.log('Edit review successful')
                            }
                            //if ($('span.controlNumber').html().charAt(0) == 'C') {
                            //    if (action == 'submit') {
                            //        getStateFilingDetails(action, filingStates, cNumber);                                                                                                                                               
                            //    }                                
                            //}                            
                           // filingStates_Update.push(filingStates);
                            // upload file
                            uploadFile('', action, section, controlID, unlockRequest);

                            if (action == 'edit') {
                                $('#reviewTab').children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-check');
                                $('#ComplianceReviewStatus').prev().removeClass('glyphicon-ban-circle').addClass('glyphicon-plus-sign');
                                $('#ComplianceReviewStatus').closest('.col-gray').removeClass('col-gray').addClass('alert-info');
                            }
                        }
                        ///// ***** SAVE REVISION ***** /////
                        if (section == 'sectionC') {
                            if (test) {
                                console.log('Edit revision successful')
                            }
                            // update Intended Usage Start Date on form
                            $('#From_x0020_Intended_x0020_Usage_').text($('#DateOfFirstUse2').val());                            

                            if (submitterKey) {
                                getReplacedUserArea(submitterKey);
                            }
                            
                            // upload file
                            uploadFile('Approved', action, section, controlID, unlockRequest);

                            if (action == 'edit') {
                                $('#revisionTab').children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-check');
                                $('#RevisionStatus').prev().removeClass('glyphicon-ban-circle').addClass('glyphicon-plus-sign');
                                $('#RevisionStatus').closest('.col-gray').removeClass('col-gray').addClass('alert-info');
                            }
                        }
                        ///// ***** SAVE APPROVAL ***** /////
                        if (section == 'sectionC2') {
                            if (test) {
                                console.log('Edit approval successful')
                            }

                            // upload file
                            uploadFile('Approved', action, section, controlID, unlockRequest);
                            if (action == 'edit') {
                                $('#ApprovalTab').children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-check');
                                $('#ApprovalStatus').prev().removeClass('glyphicon-ban-circle').addClass('glyphicon-plus-sign');
                                $('#ApprovalStatus').closest('.col-gray').removeClass('col-gray').addClass('alert-info');
                            }

                        }
                        ///// ***** SAVE FINRA ***** /////
                        if (section == 'sectionD') {
                            if (test) {
                                console.log('Edit finra successful')
                            }

                            // upload file
                            uploadFile('Approved', action, section, controlID, unlockRequest);
                            if (action == 'edit') {
                                $('#FINRATab').children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-check');
                                $('#FINRAFilingStatus').prev().removeClass('glyphicon-ban-circle').addClass('glyphicon-plus-sign');
                                $('#FINRAFilingStatus').closest('.col-gray').removeClass('col-gray').addClass('alert-info');
                            }

                        }
                        ///// ***** SAVE STATE ***** /////
                        if (section == 'sectionE')
                        {
                            if (test) {
                                console.log('Edit state successful')
                            }
                            saveStateFilingData();

                            // upload file
                            uploadFile('Approved', action, section, controlID, unlockRequest);
                            if (action == 'edit') {
                                $('#stateTab').children().children().removeClass('glyphicon-unchecked').addClass('glyphicon-check');
                                $('#StateFilingStatus').prev().removeClass('glyphicon-ban-circle').addClass('glyphicon-plus-sign');
                                $('#StateFilingStatus').closest('.col-gray').removeClass('col-gray').addClass('alert-info');
                            }
                        }                        

                    },
                    error: function (jqXHR, exception) {
                        var msg = '';
                        if (jqXHR.status === 0) {
                            msg = 'Not connected.\n Verify Network.';
                        } else if (jqXHR.status == 404) {
                            msg = 'Requested page not found. [404]';
                        } else if (jqXHR.status == 500) {
                            msg = 'Internal Server Error [500].';
                        } else if (exception === 'parsererror') {
                            msg = 'Requested JSON parse failed.';
                        } else if (exception === 'timeout') {
                            msg = 'Time out error.';
                        } else if (exception === 'abort') {
                            msg = 'Ajax request aborted.';
                        } else {
                            msg = 'Uncaught Error.\n' + jqXHR.responseText;
                        }
                        addLog(msg, section, 'Edit');
                    },
                    state: 'Edit List Item'
                });

            } else {
                // fail
                if (test) {
                    console.log('Executable string empty');
                }
            }


        }
    }
}
function saveStates(filingStates, cNumber, action) {

    var section = 'sectionB';
    var counterStates = 0;
    var totalStates = filingStates.length;
    if (totalStates == 0 && action == 'submit') {
        // hide loading icon
        $('#' + section + ' .uploadLoading').addClass('hidden');
        // display success message
        $('#' + section + ' .success .success_msg').html('Form successfully submitted, redirecting to Main Project List...');
        $('#' + section + ' .success').removeClass('hidden');
        // redirect to main list
        window.parent.location = hostUrl + '/Lists/' + listName + '/AllItems.aspx';
    }

    $.getScript(scriptbase + 'SP.Runtime.js',
      function () {
          $.getScript(scriptbase + 'SP.js',
              function () {
                  $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest2);
              });
      });

    // After the cross-domain library is loaded, execution 
    function execCrossDomainRequest2() {
        
        var executor = new SP.RequestExecutor(appUrl);
        var domain1 = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + StateFilingList + "')/items?@target='" + hostUrl + "'";
        if (test) {
            console.log(domain1);
        }
        for (i = 0; i < filingStates.length; i++) {
            rest_data = JSON.stringify({
                '__metadata': { 'type': 'SP.Data.' + StateFilingList_metadata + 'ListItem' },
                'Title': cNumber,
                'State': filingStates[i]
            });
            executor.executeAsync({
                url: domain1,
                method: "POST",
                async:false,
                contentType: "application/json;odata=verbose",
                headers: {
                    "content-type": "application/json; odata=verbose"
                },
                body: rest_data,
                success: function (data, status, headers, config) {
                    counterStates++;
                    if (test) {
                        console.log('SUCCESS: State Filing List item created');
                        console.log('conterstates' + counterStates);
                    }
                    //redirect after saving all states
                    if (totalStates == counterStates) {
                        if (test) {
                            console.log('totalStates' + totalStates);
                        }
                        if (action == 'submit') {
                            // hide loading icon
                            $('#' + section + ' .uploadLoading').addClass('hidden');
                            // reveal success message
                            $('#' + section + ' .success .success_msg').html('Form successfully submitted, redirecting to Main Project List...');
                            $('#' + section + ' .success').removeClass('hidden');
                            // redirect to main list
                            window.parent.location = hostUrl + '/Lists/' + listName + '/AllItems.aspx';
                        }
                    } else {
                        // loop to next item
                    }
                },
                error: function (data, errorCode, errorMessage) {
                    console.log('Error' + errorMessage);
                },

            });
        }
    }
}

function saveProjectControlInfo(section, control) {
    
    var cNumber = $('span.controlNumber').html();
    var requester = $('span#CurrentUserLogin').html();
    var website = context.get_web();
    var currentUser = website.ensureUser(requester);

    context.load(website);
    context.load(currentUser);
    context.executeQueryAsync(onRequestSucceeded, onRequestFailed);

    function onRequestSucceeded() {
        var userId = currentUser.get_id();
        if (test) {
            console.log(userId);
        }

        var exeBody = '';
        ////////////////////////////
        if (control == 'unlock') {

            var UnLockSection = '';
            if ($('#UnLockSection').val() && (typeof $('#UnLockSection').val() != 'undefined')) {
                UnLockSection = convertDropDown($('#UnLockSection').val());
                //UnLockSection = $('#UnLockSection').next().children().attr('title');
            }

            exeBody = "{'__metadata': { 'type': 'SP.Data." + projControlNotificationList_metadata + "ListItem' }," +
                "'Title': '" + cNumber + "', " +
                "'RequestorId': '" + userId + "', " +
                "'ItemID': '" + idParameter + "', " +
                "'UnlockSection': '" + UnLockSection + "', " +
                 "'ReasonForUnlock': '" + addslashes($('#UnLockComments').val()) + "', " +
                "'UnlockOrDiscontinue': 'Unlock'" +
                    "}";
        } else if (control == 'discontinue') {
            exeBody = "{'__metadata': { 'type': 'SP.Data." + projControlNotificationList_metadata + "ListItem' }," +
               "'Title': '" + cNumber + "', " +
               "'RequestorId': '" + userId + "', " +
               "'ItemID': '" + idParameter + "', " +
               "'ReasonToDiscontinue': '" + addslashes($('#DiscontinuedComments').val()) + "', " +
               "'UnlockOrDiscontinue': 'Discontinue'" +
                   "}";
        }

        $.getScript(scriptbase + 'SP.Runtime.js',
            function () {
                $.getScript(scriptbase + 'SP.js',
                    function () {
                        $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest2);
                    });
            });
        function execCrossDomainRequest2() {
            var executor = new SP.RequestExecutor(appUrl);
            domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + projControlNotificationList + "')/items?@target='" + hostUrl + "'";

            executor.executeAsync({
                url: domain,
                method: "POST",
                contentType: "application/json;odata=verbose",
                headers: { "content-type": "application/json; odata=verbose" },
                body: exeBody,
                success: function (data, status, headers, config) {

                    // set first option as active
                    $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(1)').addClass('active');
                    $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(1) input').attr('checked', true);
                    $('#sectionH #UnLockSection').next('.btn-group').find('button > span').html('None selected');

                    // update status
                    var getStatusIs = '';
                    $('.statusDis').each(function () {
                        // get Status Label
                        if ($(this).parent().prev().html().replace('<label>', '').replace('</label>', '').trim() == UnLockSection) {
                            // updates status  - temporary update
                            getStatusIs = $(this).attr('Id');
                            $('#' + getStatusIs).html('Submitted - Request sent for unlock');
                        }
                    });


                    // disable controls
                    disableControls();

                    // clear values, reset buttons
                    if (control == 'unlock') {
                        $('#unlock-H-input').prop('disabled', false);
                        $('#unlock-H-input').html('Request Unlock');
                        $('#UnLockComments').val('');
                        $('#' + section + ' input:checkbox').removeAttr('checked');
                    } else {
                        $('#discontinue-H-input, #DiscontinuedComments').prop('disabled', true);
                        $('#discontinue-H-input').html('Submitted');
                        //$('#DiscontinuedComments').val('');
                    }
                    // hide loading graphic
                    $('#' + section + ' .uploadLoading').addClass('hidden');
                    // hide success message on item chaneg
                    $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea').bind("change paste keyup click", function () {
                        $('#' + section + ' .success').addClass('hidden'); // hide success message
                    });
                    // success message
                    $('#' + section + ' .success .success_msg').html('Request successfully sent');
                    $('#' + section + ' .success').removeClass('hidden');

                },
                error: function (jqXHR, exception) {
                    // clear values, reset buttons
                    if (control == 'unlock') {
                        $('#unlock-H-input').prop('disabled', false);
                        $('#unlock-H-input').html('Request Unlock');
                    } else {
                        $('#discontinue-H-input').prop('disabled', false);
                        $('#discontinue-H-input').html('Discontinue Project Request');
                    }
                    // hide error message on item change
                    $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea').bind("change paste keyup click", function () {
                        $('#' + section + ' .error').addClass('hidden'); // hide success message
                    });
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connected.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal Server Error [500].';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    addLog(msg, section, 'Notification Unlock/Discontinue');

                },

            });


        }


    }

    function onRequestFailed(sender, args) {
        if (test) {
            console.log('Error: ' + args.get_message());
        }
        // clear values, reset buttons
        if (control == 'unlock') {
            $('#unlock-H-input').prop('disabled', false);
            $('#unlock-H-input').html('Request Unlock');
        } else {
            $('#discontinue-H-input').prop('disabled', false);
            $('#discontinue-H-input').html('Discontinue Project Request');
        }
        // hide error message on item chaneg
        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea').bind("change paste keyup click", function () {
            $('#' + section + ' .error').addClass('hidden'); // hide success message
        });

        addLog(args.get_message(), section, 'Notification Unlock/Discontinue');
    }


    

}
// Save State Filing information in CPRO State Filing list
function saveStateFilingData() {
    var getControlNumber = $('span.controlNumber').html();
    var $appContent = $('#StateFilingList tbody');
    var count = $appContent.children('tr').length;
    var $trContent = $('#StateFilingList tbody tr');

    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest2);
            });
    });

    var dateFiled;
    var dateApproved;
    var comments;
    var Id = '';
    var state;

    // After the cross-domain library is loaded, execution update StatFiling list data
    function execCrossDomainRequest2() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain1 = '';
        var count = 0;
        $('#StateFilingList tbody tr').each(function () {
            dateFiled = $(this).find('.datepicker[id="DateFiled' + count + '"]').val();
            dateApproved = $(this).find('.datepicker[id="DateApproved' + count + '"]').val();
            comments = addslashes($(this).find('.stateComments[id="stateFilingComments' + count + '"]').val());
            state = $(this).find(".tdState").html();//
            Id = $(this).find(".tdID").html();
            domain1 = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + StateFilingList + "')/items(" + Id + ")?@target='" + hostUrl + "'";
            if (dateApproved) {
                rest_data = JSON.stringify({
                    '__metadata': { 'type': 'SP.Data.' + StateFilingList_metadata + 'ListItem' },
                    'Date_x0020_Filed': dateFiled,
                    'Date_x0020_Approved': dateApproved,
                    'Comment': comments
                });
            }
            else {
                rest_data = JSON.stringify({
                    '__metadata': { 'type': 'SP.Data.' + StateFilingList_metadata + 'ListItem' },
                    'Date_x0020_Filed': dateFiled,                   
                    'Comment': comments
                });
            }
            executor.executeAsync({
                url: domain1,
                method: "POST",
                contentType: "application/json;odata=verbose",
                headers: {
                    'IF-MATCH': '*',
                    'X-HTTP-Method': 'MERGE',
                    'content-type': 'application/json; odata=verbose'
                },
                body: rest_data,
                success: function (data, status, headers, config) {
                    if (test) {
                        console.log('SUCCESS: State Filing List item created');
                    }
                },
                error: function (data, errorCode, errorMessage) {
                    console.log('Error' + errorMessage);
                },

            });
            count++;
        });

    }

}
function addLog(message, section, action) {
    var skipLog = false;
    if (section == 'sectionA') {
        // change buttons
        $('#save-A-input, #submit-A-input, #cancel-A-input').prop('disabled', false);
        $('#save-A-input').html('Save Project Information');
        $('#submit-A-input').html('Submit Project Information');
    } else if (section == 'sectionB') {
        // change buttons
        $('#save-B-input, #submit-B-input, #cancel-B-input').prop('disabled', false);
        $('#save-B-input').html('Save Review');
        $('#submit-B-input').html('Submit Review');
    } else if (section == 'sectionC') {
        // change buttons
        $('#save-C-input, #submit-C-input, #cancel-C-input').prop('disabled', false);
        $('#save-C-input').html('Save Material');
        $('#submit-C-input').html('Material is Ready (Send Notification to Approver)');
    } else if (section == 'sectionC2') {
        // change buttons
        $('#save-C2-input, #submit-C2-input, #cancel-C2-input').prop('disabled', false);
        $('#save-C2-input').html('Save Approval');
        $('#submit-C2-input').html('Submit Approval');
    } else if (section == 'sectionD') {
        // change buttons
        $('#save-D-input, #submit-D-input, #cancel-D-input').prop('disabled', false);
        $('#save-D-input').html('Save FINRA Filing');
        $('#submit-D-input').html('Submit FINRA Filing');
    } else if (section == 'sectionE') {
        // change buttons
        $('#save-E-input, #submit-E-input, #cancel-E-input').prop('disabled', false);
        $('#save-E-input').html('Save State Filing');
        $('#submit-E-input').html('Submit State Filing');
    } else if (section == 'sectionF') {
        // change buttons
        $('#upload-F-input, #cancel-E-input').prop('disabled', false);
    }
    // check for unlocked sections and disable submit if applicable
    checkUnlockedTabs();
    // hide loading icon
    $('.uploadLoading').addClass('hidden');
    // error message
    if (message == 'Bad Request') {
        message = 'ENTRY ERROR: Please check entry fields';
        skipLog = true;
    }

    if (section) {
        $('#' + section + ' .error .error_msg').html('' + message + '');
        $('#' + section + ' .error').removeClass('hidden');
    }

    if (skipLog == false) {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('Logs')/items?@target='" + hostUrl + "'";
        if (test) {
            console.log(domain);
        }
        var rest_data = JSON.stringify({
            '__metadata': {
                'type': 'SP.Data.LogsListItem'
            },
            'Title': idParameter,
            'Message': message,
            'User': $('#CurrentUser').html(),
            'Section': section + ' on ' + action
        });
        // Add to list
        executor.executeAsync({
            url: domain,
            method: "POST",
            contentType: "application/json;odata=verbose",
            headers: {
                "content-type": "application/json; odata=verbose"
            },
            body: rest_data,
            success: function () {
            },
            error: function (data, errorCode, errorMessage) {
               alert('ERROR LOGGING: ' + errorMessage + " " + errorCode);
            },
            state: "Add Log Item"
        });
    }
}

    // Get List Item Type metadata
function GetItemTypeForListName(name) {
    return "SP.Data." + name.charAt(0).toUpperCase() + name.split(" ").join("").slice(1) + "ListItem";
}

    //  handle the query string
function getQueryStringParameter(paramToRetrieve) {
    var params =
        document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] == paramToRetrieve)
            return singleParam[1];
    }
}

function getUrlParameters(parameter, staticURL, decode) {

    var currLocation = (staticURL.length) ? staticURL : window.location.search,
        parArr = currLocation.split("?")[1].split("&"),
        returnBool = true;

    for (var i = 0; i < parArr.length; i++) {
        parr = parArr[i].split("=");
        if (parr[0] == parameter) {
            return (decode) ? decodeURIComponent(parr[1]) : parr[1];
            returnBool = true;
        } else {
            returnBool = false;
        }
    }

    if (!returnBool) return false;
}

// Status tab upload
$(document).on('click', '#upload-F-input', function () {
    var section = 'sectionF';
    var doctype = $('#fileDocType :selected').text();
    if (validatedFiles.length > 0 && doctype != 'None selected') {
       $('#' + section + ' .error').addClass('hidden'); // hide success message       
       $('#getFile3').nextAll('.validation').addClass('hidden');
        $('#sectionF .uploadLoading').removeClass('hidden'); // display loading graphic
        $('#upload-F-input').prop('disabled', true); // disable button when uploading
        uploadFile(doctype, 'edit', 'sectionF', '', '')
    } else {
        // hide loading icon
        $('#' + section + ' .uploadLoading').addClass('hidden');
        // error message
        $('#' + section + ' .error .error_msg').html('Required Fields');
        $('#' + section + ' .error').removeClass('hidden');
        if (validatedFiles.length == 0) {
            $('#getFile3').nextAll('.validation').removeClass('hidden');
        }
        if (doctype == 'None selected') {
            $('#fileDocType').after('<span class="validation">required</span>');
        }
        
    }
  
});

$(document).on('click', '.remove', function () {
    var file = $(this).parents('.pendingFile').text().slice(0, -1);
    for (var i = 0; i < validatedFiles.length; i++) {
        if (validatedFiles[i].name === file) {
            validatedFiles.splice(i, 1);
            break;
        }
    }
    $(this).parents('.pendingFile').remove();

});

//fileUpload
$(document).on('change', '.fileUpload', function () {
    var getFileData = $(this).attr('Id');
    //$('*[data-upload="' + getFileData + '"] .upload_prev').empty();
    //$('*[data-upload="' + getFileData + '"] .upload_prev').removeClass('hidden');
    $('.upload_prev').empty();
    $('.upload_prev').removeClass('hidden');
    var files = $('#' + getFileData)[0].files;
    if (test) {
        console.log('Total files: ' + files.length);
    }
    for (var i = 0; i < files.length; i++) {
        validatedFiles.push(files[i]);
    }
    for (var i = 0; i < validatedFiles.length; i++) {
        //$('*[data-upload="' + getFileData + '"] .upload_prev').append('<div class="pendingFile">' + validatedFiles[i].name + '<div class="remove">X</div></div>');
        $('.upload_prev').append('<div class="pendingFile">' + validatedFiles[i].name + '<div class="remove">X</div></div>');
    }
});


// Upload the file. 
// You can upload files up to 2 GB with the REST API. 
function uploadFile(doctype, action, section, controlID, unlockRequest) {

    //check();
    var fileCount = validatedFiles.length;
    var cNumber = $('span.controlNumber').html(); // get control # ;
    var path = docPath + '/' + cNumber + '/' + doctype;
    var projectName = $('span.projectName').html();
    var projectCreatedDate = $('span.projectDate').html();

    if (fileCount > 0) {
        var formData = new FormData();
        for (var i = 0; i < validatedFiles.length; i++) {
            formData.append('uploadDoc', validatedFiles[i]);
        }
        // groupFoPermissionsCheck = verify that the logged in user has permissions to this group
        var domain = serviceUrl + '/api/docupload?siteUrl=' + hostUrl +
            '&controlNum=' + cNumber +
            '&projName=' + encodeURIComponent(projectName) +
            '&projCreatedDate=' + projectCreatedDate +
            '&docType=' + doctype + 
            '&docLibName=' + encodeURIComponent('CPRO Documents');
        if (test) {
            console.log(domain);
        }
        $.ajax({
            type: "POST",
            url: domain,
            contentType: false,
            processData: false,
            data: formData,
            xhrFields: {
                withCredentials: true
            },
            success: function (messages) {
                // loop files
                for (var i = 0; i < validatedFiles.length; i++) {
                    /***** add items to page on document upload *****/
                    replacedFile = '&nbsp;<span class="replacedFile alert alert-info" role="alert">new</span>';
                    fileName = validatedFiles[i].name;
                    if (doctype == 'Draft') {
                        // if rewritting, then hide other version
                        $('.documents_display_draft > .row').each(function () {
                            if (fileName == $(this).data('file')) {
                                $(this).addClass('hidden');
                                replacedFile = '&nbsp;<span class="replacedFile alert alert-info" role="alert">replaced</span>';
                            }
                        });
                        documents_draft = '<div class="draft_count hidden">1</div><div class="row row-top" data-file="' + fileName + '" data-path="/sites/cpro/' + path + '/' + fileName + '"><div class="col-xs-8"><a class="fileTgt" target="_blank" href="' + hostUrl + '/' + path + '/' + fileName + '"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> ' + fileName + '</a></div>' +
                        '<div class="col-xs-4 pull-right"><a class="delete" data-file="' + fileName + '" data-path="/sites/cpro/' + path + '/' + fileName + '" data-type="Draft"><span class="glyphicon glyphicon-trash" aria-hidden="true" alt="delete"></span></a><div class="deleteloading hidden"></div></div></div>';
                        $('.documents_display_draft').append(documents_draft);
                        $('.draft_count').html("1");
                        if (replacedFile) {
                            $('.documents_display_draft > div[data-file="' + fileName + '"] > div > a.fileTgt').append(replacedFile);
                        }
                    } else if (doctype == 'Final') {
                        // if rewritting, then hide other version
                        $('.documents_display_final > .row').each(function () {
                            if (fileName == $(this).data('file')) {
                                $(this).addClass('hidden');
                                replacedFile = '&nbsp;<span class="replacedFile alert alert-info" role="alert">replaced</span>';
                            } 
                        });
                        documents_final = '<div class="row row-top" data-file="' + fileName + '" data-path="/sites/cpro/' + path + '/' + fileName + '"><div class="col-xs-8"><a class="fileTgt" target="_blank" href="' + hostUrl + '/' + path + '/' + fileName + '"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> ' + fileName + '</a></div>' +
                        '<div class="col-xs-4 pull-right"><a class="delete" data-file="' + fileName + '" data-path="/sites/cpro/' + path + '/' + fileName + '" data-type="Final"><span class="glyphicon glyphicon-trash" aria-hidden="true" alt="delete"></span></a><div class="deleteloading hidden"></div></div>';
                        $('.documents_display_final').append(documents_final);
                        if (replacedFile) {
                            $('.documents_display_final > div[data-file="' + fileName + '"] > div > a.fileTgt').append(replacedFile);
                        }
                    } else if (doctype == 'Approved') {
                        // if rewritting, then hide other version
                        $('.documents_display_approved > .row').each(function () {
                            if (fileName == $(this).data('file')) {
                                $(this).addClass('hidden');
                                replacedFile = '&nbsp;<span class="replacedFile alert alert-info" role="alert">replaced</span>';
                            } 
                        });
                        documents_approved = '<div class="approved_count hidden">1</div><div class="row row-top" data-file="' + fileName + '" data-path="/sites/cpro/' + path + '/' + fileName + '"><div class="col-xs-8"><a class="fileTgt" target="_blank" href="' + hostUrl + '/' + path + '/' + fileName + '"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> ' + fileName + '</a></div>' +
                        '<div class="col-xs-4 pull-right"><a class="delete" data-file="' + fileName + '" data-path="/sites/cpro/' + path + '/' + fileName + '" data-type="Approved"><span class="glyphicon glyphicon-trash" aria-hidden="true" alt="delete"></span></a><div class="deleteloading hidden"></div></div>';
                        $('.documents_display_approved').append(documents_approved);
                        $('.approved_count').html("1");
                        if (replacedFile) {
                            $('.documents_display_approved > div[data-file="' + fileName + '"] > div > a.fileTgt').append(replacedFile);
                        }

                    }
                }

                complete();



            },
            error: function (jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connected.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = jqXHR.responseText;
                }
                addLog('ERROR: Unable to upload file: ' + msg + '. Verify that your file is less than 25MB and does not contain special characters like &, *, $, #, %, !, @.', section, 'File Upload');
            }
        });
    } else {

        complete(unlockRequest);

    }

    function complete(unlockRequest) {

        // remove from upload field and preview
        $('.upload_prev').empty();
        $('.upload_prev').addClass('hidden');
        $('#getFile, #getFile2, #getFile3, #getFile4, #getFile5, #getFile6').value = null;
        validatedFiles = [];
        var control;
        if (section == 'sectionA') {
            control = $('#getFile');
        } else if (section == 'sectionC') {
            control = $('#getFile2');
        } else if (section == 'sectionC2') {
            control = $('#getFile4');
        } else if (section == 'sectionD') {
            control = $('#getFile5');
        } else if (section == 'sectionE') {
            control = $('#getFile6');
        } else if (section == 'sectionF') {
            control = $('#getFile3');
        }
        if (control) {
            control.replaceWith(control = control.clone(true));
        }


        if (test) {
            console.log('Control ID on complete: ' + controlID)
        }

        if (action == 'edit') {
            editComplete(section);

        } else if (action == 'submit') {
            // check if draft document is loaded
            var countDocs = 0;
            var validate = '';
            if (section == 'sectionA') {
                countDocs = $('.draft_count').html();
                validate = 'y';
            } else if (section == 'sectionC') {
                countDocs = $('.approved_count').html();
                validate = 'y';
            } else if (section == 'sectionD') {
                countDocs = $('.approved_count').html();
                validate = 'y';
            } else if (section == 'sectionE') {
                countDocs = $('.approved_count').html();
                validate = 'y';
            }
            if (test) {
                console.log('Count Draft Docs: ' + countDocs)
            }
            if ((countDocs == 0 || countDocs == null) && validate == 'y') {
                fail = 'yes';
                if (test) {
                    console.log('Fail: Document available');
                }

                if (section == 'sectionA') {
                    // change buttons
                    $('#save-A-input, #submit-A-input, #cancel-A-input').prop('disabled', false);
                    $('#save-A-input').html('Save Project Information');
                    $('#submit-A-input').html('Submit Project Information');
                    $('#getFile').nextAll('.validation').removeClass('hidden');
                } else if (section == 'sectionB') {
                    // change buttons
                    $('#save-B-input, #submit-B-input, #cancel-B-input').prop('disabled', false);
                    $('#save-B-input').html('Save Review');
                    $('#submit-B-input').html('Submit Review');
                } else if (section == 'sectionC') {
                    // change buttons
                    $('#save-C-input, #submit-C-input, #cancel-C-input').prop('disabled', false);
                    $('#save-C-input').html('Save Material');
                    $('#submit-C-input').html('Material is Ready (Send Notification to Approver)');
                    $('#getFile2').nextAll('.validation').removeClass('hidden');
                } else if (section == 'sectionC2') {
                    // change buttons
                    $('#save-C2-input, #submit-C2-input, #cancel-C2-input').prop('disabled', false);
                    $('#save-C2-input').html('Save Approval');
                    $('#submit-C2-input').html('Submit Approval');
                    $('#getFile4').nextAll('.validation').removeClass('hidden');
                } else if (section == 'sectionD') {
                    // change buttons
                    $('#save-D-input, #submit-D-input, #cancel-D-input').prop('disabled', false);
                    $('#save-D-input').html('Save FINRA Filing');
                    $('#submit-D-input').html('Submit FINRA Filing');
                    $('#getFile5').nextAll('.validation').removeClass('hidden');
                } else if (section == 'sectionE') {
                    // change buttons
                    $('#save-E-input, #submit-E-input, #cancel-E-input').prop('disabled', false);
                    $('#save-E-input').html('Save State Filing');
                    $('#submit-E-input').html('Submit State Filing');
                    $('#getFile6').nextAll('.validation').removeClass('hidden');
                }
                // hide loading icon
                $('#' + section + ' .uploadLoading').addClass('hidden');
                // error message
                $('#' + section + ' .error .error_msg').html('Document Required');
                $('#' + section + ' .error').removeClass('hidden');

                // check for unlocked sections and disable submit if applicable
                checkUnlockedTabs();

            } else {
                submit(section, controlID, unlockRequest);
            }
        }
    }
};


function submit(section, controlID, unlockRequest) {
    // set Control Option, if Unlock request was made: 'Unlock Request' = 'Yes'
    var listChange;
    if (section == 'sectionA') {
        if (unlockRequest == 'project') {
            listChange = "'IsProjectInformationLocked': 'Reset', ";
            // Lock Review tab if Streamlined
            if ($('#TypeOfProject').val() == 'Streamlined') {
                listChange = listChange + "'IsComplianceReviewLocked': 'Yes', ";
            } else {
                listChange = listChange + "'IsComplianceReviewLocked': '', ";
            }
        } else {
            listChange = "'IsProjectInformationLocked': 'Yes', ";
            // Lock Review tab if Streamlined
            if ($('#TypeOfProject').val() == 'Streamlined') {
                listChange = listChange + "'IsComplianceReviewLocked': 'Yes', ";
            } else {
                listChange = listChange + "'IsComplianceReviewLocked': '', ";
            }
        }
    } else if (section == 'sectionB') {
        if (unlockRequest == 'review') {
            listChange = "'IsComplianceReviewLocked': 'Reset', ";
        } else {
            listChange = "'IsComplianceReviewLocked': 'Yes', ";
            // if previous tab is complete, then change to Yes (to check for Reset status) to allow workflow to work properly
            if ($('#ProjectInformationStatus').text() == 'Submitted') {
                listChange = listChange + "'IsProjectInformationLocked': 'Yes', ";
            }
        }
    } else if (section == 'sectionC') {
        if (unlockRequest == 'revision') {
            listChange = "'IsCheckedLocked': 'Reset', ";
        } else {
            listChange = "'IsCheckedLocked': 'Yes', ";
            // if previous tabs are complete, then change to Yes (to check for Reset status) to allow workflow to work properly
            if ($('#ProjectInformationStatus').text() == 'Submitted') {
                listChange = listChange + "'IsProjectInformationLocked': 'Yes', ";
            }
            if ($('#ComplianceReviewStatus').text() == 'Submitted') {
                listChange = listChange + "'IsComplianceReviewLocked': 'Yes', ";
            }
        }
    } else if (section == 'sectionC2') {
        if (unlockRequest == 'approval') {
            listChange = "'IsApprovalLocked': 'Reset', ";
        } else {
            listChange = "'IsApprovalLocked': 'Yes', ";
            // if previous tabs are complete, then change to Yes (to check for Reset status) to allow workflow to work properly
            if ($('#ProjectInformationStatus').text() == 'Submitted') {
                listChange = listChange + "'IsProjectInformationLocked': 'Yes', ";
            }
            if ($('#ComplianceReviewStatus').text() == 'Submitted') {
                listChange = listChange + "'IsComplianceReviewLocked': 'Yes', ";
            }
            if ($('#RevisionStatus').text() == 'Submitted') {
                listChange = listChange + "'IsCheckedLocked': 'Yes', ";
            }
        }
    } else if (section == 'sectionD') {
        if (unlockRequest == 'finra') {
            listChange = "'IsFINRALocked': 'Reset', ";
        } else {
            listChange = "'IsFINRALocked': 'Yes', ";
            // if previous tabs are complete, then change to Yes (to check for Reset status) to allow workflow to work properly
            if ($('#ProjectInformationStatus').text() == 'Submitted') {
                listChange = listChange + "'IsProjectInformationLocked': 'Yes', ";
            }
            if ($('#ComplianceReviewStatus').text() == 'Submitted') {
                listChange = listChange + "'IsComplianceReviewLocked': 'Yes', ";
            }
            if ($('#RevisionStatus').text() == 'Submitted') {
                listChange = listChange + "'IsCheckedLocked': 'Yes', ";
            }
            if ($('#ApprovalStatus').text() == 'Submitted') {
                listChange = listChange + "'IsApprovalLocked': 'Yes', ";
            }
            if ($('#StateFilingStatus').text() == 'Submitted') {
                listChange = listChange + "'IsStateFilingLocked': 'Yes', ";
            }
        }
    } else if (section == 'sectionE') {
        if (unlockRequest == 'state') {
            listChange = "'IsStateFilingLocked': 'Reset', ";
        } else {
            listChange = "'IsStateFilingLocked': 'Yes', ";
            // if previous tabs are complete, then change to Yes (to check for Reset status) to allow workflow to work properly
            if ($('#ProjectInformationStatus').text() == 'Submitted') {
                listChange = listChange + "'IsProjectInformationLocked': 'Yes', ";
            }
            if ($('#ComplianceReviewStatus').text() == 'Submitted') {
                listChange = listChange + "'IsComplianceReviewLocked': 'Yes', ";
            }
            if ($('#RevisionStatus').text() == 'Submitted') {
                listChange = listChange + "'IsCheckedLocked': 'Yes', ";
            }
            if ($('#ApprovalStatus').text() == 'Submitted') {
                listChange = listChange + "'IsApprovalLocked': 'Yes', ";
            }
            if ($('#FINRAFilingStatus').text() == 'Submitted') {
                listChange = listChange + "'IsFINRALocked': 'Yes', ";
            }
        }
    }
    if (test) {
        console.log('Control ID on submit' + controlID);
    }
    // update control list
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });
    function execCrossDomainRequest() {
        // update control list
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName2 + "')/items(" + controlID + ")?@target='" + hostUrl + "'";
        var exeBody = "{'__metadata': { 'type': 'SP.Data." + listName2_metadata + "ListItem' }," +
            listChange +
            "'UnLockRequest': '' " +
                    "}";
        if (test) {
            console.log(domain);
        }
        executor.executeAsync({
            url: domain,
            method: 'POST',
            contentType: 'application/json;odata=verbose',
            headers: {
                'IF-MATCH': '*',
                'X-HTTP-Method': 'MERGE',
                'content-type': 'application/json; odata=verbose'
            },
            body: exeBody,
            success: function (data, status, headers, config) {
                

                // redirect
                if ($('#TypeOfProject').val() == 'Streamlined' && section == 'sectionA') {

                    // hide loading icon
                    $('#' + section + ' .uploadLoading').addClass('hidden');
                    // reveal success message
                    $('#' + section + ' .success .success_msg').html('Form successfully submitted, redirecting to Revision Tab...');
                    $('#' + section + ' .success').removeClass('hidden');
                    // redirect to revision tab if submitting Project Information and Type of Project is Streamlined
                    window.parent.location = hostUrl + '/Lists/' + listName + '/Item/editifs.aspx?ID=' + idParameter;
                     
                } else {

                    if (section == 'sectionB') {
                        var filingStates = [];
                        var action = 'submit';
                        var cNumber = $('span.controlNumber').html();
                        filingStates = filingStates_Update;
                        //filingStates.push(filingStates_Update);
                        if ($('span.controlNumber').html().charAt(0) == 'C') {
                            //if (action == 'submit') {
                            getStateFilingDetails(action, filingStates, cNumber);
                            //}
                        }

                    }
                    else {
                        // hide loading icon
                        $('#' + section + ' .uploadLoading').addClass('hidden');
                        // reveal success message
                        $('#' + section + ' .success .success_msg').html('Form successfully submitted, redirecting to Main Project List...');
                        $('#' + section + ' .success').removeClass('hidden');
                        // redirect to main list
                        window.parent.location = hostUrl + '/Lists/' + listName + '/AllItems.aspx';
                    }
               
                }
            },
            error: function (jqXHR, exception) {
                // change buttons
                if (section == 'sectionA') {
                    $('#submit-A-input').html('Submit Project Information');
                } else if (section == 'sectionB') {
                    $('#submit-B-input').html('Submit Review');
                } else if (section == 'sectionC') {
                    $('#submit-C-input').html('Material is Ready (Send Notification to Approver)');
                } else if (section == 'sectionC2') {
                    $('#submit-C2-input').html('Submit Approval');
                } else if (section == 'sectionD') {
                    $('#submit-D-input').html('Submit FINRA Filing');
                } else if (section == 'sectionE') {
                    $('#submit-E-input').html('Submit State Filing');
                }

                if (test) {
                    console.log('ERROR (submit): ' + jqXHR.responseText);
                }
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connected.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.\n' + jqXHR.responseText;
                }

                addLog(msg, section, 'Submit');
            },
            state: 'Edit List Item'
        });


    }
}

function editComplete(section) {
    var successMessage = 'Form successfully saved';
    if (section == 'sectionA') {
        // disable save button
        $('#submit-A-input, #cancel-A-input').prop('disabled', false);
        $('#save-A-input').html('Saved');

        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea, #' + section + ' .replaceUser').bind("change paste keyup click", function () {
            $('#save-A-input').prop('disabled', false);
            $('#save-A-input').html('Save Project Information');
            $('#' + section + ' .success').addClass('hidden'); // hide success message
        });

        // reveal success message
        $('#' + section + ' .success .success_msg').html(successMessage);
        $('#' + section + ' .success').removeClass('hidden');
    } else if (section == 'sectionB') {
        // disable save button
        $('#submit-B-input, #cancel-B-input').prop('disabled', false);
        $('#save-B-input').html('Saved');

        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea, #' + section + ' .replaceUser').bind("change paste keyup click", function () {
            $('#save-B-input').prop('disabled', false);
            $('#save-B-input').html('Save Review');
            $('#' + section + ' .success').addClass('hidden'); // hide success message
        });

        // reveal success message
        $('#' + section + ' .success .success_msg').html(successMessage);
        $('#' + section + ' .success').removeClass('hidden');
    } else if (section == 'sectionC') {
        // disable save button
        $('#submit-C-input, #cancel-C-input').prop('disabled', false);
        $('#save-C-input').html('Saved');

        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea, #' + section + ' .replaceUser').bind("change paste keyup click", function () {
            $('#save-C-input').prop('disabled', false);
            $('#save-C-input').html('Save Material');
            $('#' + section + ' .success').addClass('hidden'); // hide success message
        });

        // reveal success message
        $('#' + section + ' .success .success_msg').html(successMessage);
        $('#' + section + ' .success').removeClass('hidden');
    } else if (section == 'sectionC2') {
        // disable save button
        $('#submit-C2-input, #cancel-C2-input').prop('disabled', false);
        $('#save-C2-input').html('Saved');

        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea, #' + section + ' .replaceUser').bind("change paste keyup click", function () {
            $('#save-C2-input').prop('disabled', false);
            $('#save-C2-input').html('Save Approval');
            $('#' + section + ' .success').addClass('hidden'); // hide success message
        });

        // reveal success message
        $('#' + section + ' .success .success_msg').html(successMessage);
        $('#' + section + ' .success').removeClass('hidden');
    } else if (section == 'sectionD') {
        // disable save button
        $('#submit-D-input, #cancel-D-input').prop('disabled', false);
        $('#save-D-input').html('Saved');

        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea, #' + section + ' .replaceUser').bind("change paste keyup click", function () {
            $('#save-D-input').prop('disabled', false);
            $('#save-D-input').html('Save FINRA Filing');
            $('#' + section + ' .success').addClass('hidden'); // hide success message
        });

        // reveal success message
        $('#' + section + ' .success .success_msg').html(successMessage);
        $('#' + section + ' .success').removeClass('hidden');
    } else if (section == 'sectionE') {
        // disable save button
        $('#submit-E-input, #cancel-E-input').prop('disabled', false);
        $('#save-E-input').html('Saved');

        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea, #' + section + ' .replaceUser').bind("change paste keyup click", function () {
            $('#save-E-input').prop('disabled', false);
            $('#save-E-input').html('Save State Filing');
            $('#' + section + ' .success').addClass('hidden'); // hide success message
        });

        // reveal success message
        $('#' + section + ' .success .success_msg').html(successMessage);
        $('#' + section + ' .success').removeClass('hidden');
    } else if (section == 'sectionF') {
        $('#upload-F-input').prop('disabled', false); // enable button
        // reveal success message
        $('#' + section + ' .success .success_msg').html('Documents uploaded');
        $('#' + section + ' .success').removeClass('hidden');

        $('#' + section + ' input, #' + section + ' select').bind('change paste keyup click', function () {
            $('#' + section + ' .success').addClass('hidden'); // hide success message
        });
    }            
    // hide loading icon
    $('#' + section + ' .uploadLoading').addClass('hidden');
}

function updateNotification(notificationId, section, getId) {
    
    if (notificationId) {
        $.getScript(scriptbase + 'SP.Runtime.js',
        function () {
            $.getScript(scriptbase + 'SP.js',
                function () {
                    $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest2);
                });
        });
        function execCrossDomainRequest2() {
            var executor = new SP.RequestExecutor(appUrl);
            var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + projControlNotificationList + "')/items(" + notificationId + ")?@target='" + hostUrl + "'";
            var exeBody = "{'__metadata': { 'type': 'SP.Data." + projControlNotificationList_metadata + "ListItem' }," +
            "'Complete': 'Y' " +
                    "}";
            if (test) {
                console.log(domain);
            }
            executor.executeAsync({
                url: domain,
                method: 'POST',
                contentType: 'application/json;odata=verbose',
                headers: {
                    'IF-MATCH': '*',
                    'X-HTTP-Method': 'MERGE',
                    'content-type': 'application/json; odata=verbose'
                },
                body: exeBody,
                success: function (data, status, headers, config) {
                    if (test) {
                        console.log('Notification Unlock Updated');
                    }

                    if (getId) {
                        // change Section Number
                        setSectionNumber(getId);
                    } else {
                        // hide loading graphic
                        $('#' + section + ' .uploadLoading').addClass('hidden');
                        // hide success message on item chaneg
                        $('#' + section + ' input, #' + section + ' select, #' + section + ' textarea').bind("change paste keyup click", function () {
                            $('#' + section + ' .success').addClass('hidden'); // hide success message
                        });
                        // success message
                        $('#' + section + ' .success .success_msg').html('Project discontinued successfully');
                        $('#' + section + ' .success').removeClass('hidden');
                        // redirect to main list
                        window.parent.location = hostUrl + '/Lists/' + listName + '/AllItems.aspx';
                    }
                    

                },
                error: function (data, errorCode, errorMessage) {
                    if (test) {
                        console.log('ERROR (unlock complete): ' + errorMessage + " " + errorCode);
                    }
                    //addLog(errorMessage, section, 'Notifications Unlock Reset to Complete');

                }
            });

        }
    }
    
}

function wireEvents() {
    $(function () {
        $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });

        function execCrossDomainRequest() {

            var executor = new SP.RequestExecutor(appUrl);
            // the url to use for the REST call.
            var url = appUrl + "/_api/SP.AppContextSite(@target)" +
                "/web/lists/getbytitle('" + listName + "')/items?$top=5000" +
                "&@target='" + hostUrl + "'";

            // create  new executor passing it the url created previously


            // execute the request, this is similar although not the same as a standard AJAX request
            executor.executeAsync(
                {
                    url: url,
                    method: "GET",
                    headers: {
                        "Accept": "application/json; odata=verbose"
                    },
                    success: function (data) {
                        var body = jQuery.parseJSON(data.body);
                        var results = body.d.results;
                        $.each(results, function (i, result) {
                            if (result.CNumber) {
                                myData.push(result.CNumber);
                            }
                            if (result.INumber) {
                                myData.push(result.INumber);
                            }
                            //if (result.Title) {
                            //    myData.push(result.Title);
                            //   // alert("result.Title=" + result.Title);
                            //}

                        });
                        // parse the results into an object that you can use within javascript
                        //var results = eval(JSON.parse(data.body));
                    },
                    error: function (data) {

                        // an error occured, the details can be found in the data object.
                        //alert("ERROR on CNumber lookup");
                    }
                });

        }

        availableTags = myData;


    });
}
///function to get control numbers from list for autopopulate

function getdata() {

    function split(val) {
        return val.split(/,/);
    }

    function extractLast(term) {
        var nonSpaceTerm = split(term).pop().toString();
        if (/^\s+\S*/.test(nonSpaceTerm)) {
            nonSpaceTerm = nonSpaceTerm.replace(/\s+/, "");
        }
        return split(nonSpaceTerm).pop();
    }

    $("input[name*='ProjectCNumber']")
    // don't navigate away from the field on tab when selecting an item
            .bind("keydown", function (event) {
                if (event.keyCode === $.ui.keyCode.TAB &&
                    $(this).data("autocomplete").menu.active) {
                    event.preventDefault();
                }
            })
            .autocomplete(
    {
        minLength: 0,
        maxShowItems: 5,
        source: function (request, response) {
            // delegate back to autocomplete, but extract the last term
            response($.ui.autocomplete.filter(
                        myData, extractLast(request.term)));
        },
        focus: function () {
            // prevent value inserted on focus
            return false;
        },
        select: function (event, ui) {
            var terms = split(this.value);
            // remove the current input
            terms.pop();
            // add the selected item
            terms.push(ui.item.value);
            // add placeholder to get the comma-and-space at the end
            //terms.push("");
            //this.value = terms.join(",");
            //this.value += " ";
            this.value = terms;
            return false;
        }
    });
}

function convertDate(x, formatter) {

    var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    var shortMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    // split up date and time
    xDate = x.split("T")[0];
    xTime = x.split("T")[1];

    // split off the hour from the minute/second
    xMinSec = xTime.split(":")[1];
    xHour = xTime.split(":")[0];

    // set the am or pm suffix
    if (xHour > 12) {
        ampm = "pm";
        xHour -= 12;
    } else if (xHour < 12) {
        ampm = "am";
    } else {
        ampm = "pm";
    }
    //extract the minute from the minute/second
    xMin = xMinSec.split(":")[0];

    // split up the date into day, month (-1), and year
    xDay = xDate.split("-")[2];
    //xMonth = shortMonths[xMonth = xDate.split("-")[1] - 1];
    xMonth = xDate.split("-")[1];
    xYear = xDate.split("-")[0];

    // format your date as you like
    xFullDate = xMonth + "/" + xDay + "/" + xYear;

    // format the time as you like
    xFullTime = xHour + ":" + xMin + ampm;

    // check the parameter to see which one to return
    if (formatter === "date") {
        return xFullDate;
    } else if (formatter === "time") {
        return xFullTime;
    }
}

function addslashes(string) {
    if (string) {
        return string.replace(/\\/g, '\\\\').
            replace(/\u0008/g, '\\b').
            replace(/\t/g, '\\t').
            replace(/\n/g, '\\n').
            replace(/\f/g, '\\f').
            replace(/\r/g, '\\r').
            replace(/'/g, '\\\'').
            replace(/"/g, '\\"');                    
    } else {
        return '';
    }
}

/* error handle */
function RemoveCssClassFromElement() {
    //console.log('pp removeclass');
}
function AddCssClassToElement() {

}

/* populate date into html */
function fillDate(htmlVar) {
    var d = new Date();
    var month = d.getMonth() + 1;
    month = (('' + month).length < 2 ? '0' : '') + month;
    var day = d.getDate();
    day = (('' + day).length < 2 ? '0' : '') + day;
    var year = d.getFullYear();
    var date = month + '/' + day + '/' + year
    if (htmlVar) {
        $(htmlVar).html(date);
    } else {
        return date;
    }

}
/* getting division property */
function getReplacedUserArea(userName) {
    var domain = appUrl + "/_api/SP.UserProfiles.PeopleManager/GetUserProfilePropertyFor(accountName=@v,propertyName='Division')?@v='" + userName.split('|')[1] + "'";
    if (test) {
        console.log(domain);
    }
    $.ajax({
        url: domain,
        type: "GET",
        headers: { "Accept": "application/json; odata=verbose" },
        success: function (data) {
            try {
                //Get properties from user profile Json response
                var Division = data.d.GetUserProfilePropertyFor;
                updateBusinessArea(Division);
            } catch (err2) {
                $('#sectionC .error .error_msg').html('ERROR C: ' + JSON.stringify(err2) + '');
                $('.error').removeClass('hidden');                       
                // hide loading icon
                $('.uploadLoading').addClass('hidden');
            }
        },
        error: function (jqXHR, exception) {
            var msg = '';
            if (jqXHR.status === 0) {
                msg = 'Not connected.\n Verify Network.';
            } else if (jqXHR.status == 404) {
                msg = 'Requested page not found. [404]';
            } else if (jqXHR.status == 500) {
                msg = 'Internal Server Error [500].';
            } else if (exception === 'parsererror') {
                msg = 'Requested JSON parse failed.';
            } else if (exception === 'timeout') {
                msg = 'Time out error.';
            } else if (exception === 'abort') {
                msg = 'Ajax request aborted.';
            } else {
                msg = 'Uncaught Error.\n' + jqXHR.responseText;
            }
            addLog('ERROR: ' + msg + '', 'sectionC', 'Replaced User Area');
        }
    });
}

//updating business area for replaced submitter
function updateBusinessArea(Division) {
    if (!Division) {
        Division = 'Not Available';
    }
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });
    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items(" + idParameter + ")?@target='" + hostUrl + "'";
        if (test) {
            console.log(domain);
        }
        var exeBody = "{'__metadata': { 'type': 'SP.Data." + listName_metadata + "ListItem' }," +
            "'BusinessArea': '" + Division + "'" +
        "}";
        if (test) {
            console.log(exeBody);
        }

        executor.executeAsync({
            url: domain,
            method: 'POST',
            contentType: 'application/json;odata=verbose',
            headers: {
                'IF-MATCH': '*',
                'X-HTTP-Method': 'MERGE',
                'content-type': 'application/json; odata=verbose'
            },
            body: exeBody,
            success: function (data, status, headers, config) {
                if (test) {
                    console.log('SUCCESS: Business area updated');
                }
            },
            error: function (jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connected.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.\n' + jqXHR.responseText;
                }
                addLog('ERROR: ' + msg + '', 'sectionC', 'Business Area');
            },
        });
    }
}

// change status when unlocking
function unlockStatus(controlID, getId) {
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });
    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName2 + "')/items(" + controlID + ")?@target='" + hostUrl + "'";
        if (test) {
            console.log(domain);
        }
        // get unlock area
        if (getId == 'A') {
            var columnName = 'IsProjectInformationLocked';
        } else if (getId == 'B') {
            var columnName = 'IsComplianceReviewLocked';
        } else if (getId == 'C') {
            var columnName = 'IsCheckedLocked';
        } else if (getId == 'C2') {
            var columnName = 'IsApprovalLocked';
        } else if (getId == 'D') {
            var columnName = 'IsFINRALocked';
        } else if (getId == 'E') {
            var columnName = 'IsStateFilingLocked';
        }
        var exeBody = "{'__metadata': { 'type': 'SP.Data." + listName2_metadata + "ListItem' }," +
            "'" + columnName + "': 'No'" +
        "}";
        if (test) {
            console.log(exeBody);
        }
        executor.executeAsync({
            url: domain,
            method: 'POST',
            contentType: 'application/json;odata=verbose',
            headers: {
                'IF-MATCH': '*',
                'X-HTTP-Method': 'MERGE',
                'content-type': 'application/json; odata=verbose'
            },
            body: exeBody,
            success: function (data, status, headers, config) {

                // change buttons
                var notificationId = '';
                var section = 'section' + getId;
                if (section == 'sectionA') {
                    $('#submit-A-input').html('Submitted');
                    notificationId = $('#Notification_A').html();
                } else if (section == 'sectionB') {
                    $('#submit-B-input').html('Submitted');
                    notificationId = $('#Notification_B').html();
                } else if (section == 'sectionC') {
                    $('#submit-C-input').html('Submitted');
                    notificationId = $('#Notification_C').html();
                } else if (section == 'sectionC2') {
                    $('#submit-C2-input').html('Submitted');
                    notificationId = $('#Notification_C2').html();
                } else if (section == 'sectionD') {
                    $('#submit-D-input').html('Submitted');
                    notificationId = $('#Notification_D').html();
                } else if (section == 'sectionE') {
                    $('#submit-E-input').html('Submitted');
                    notificationId = $('#Notification_E').html();
                }
                updateNotification(notificationId, section, getId);

            },
            error: function (jqXHR, exception) {
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connected.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Requested JSON parse failed.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.\n' + jqXHR.responseText;
                }
                addLog('ENTRY ERROR: ' + msg + '', 'sectionG', 'Unlock Status');
            },
        });
    }
}

// change status when unlocking
function setSectionNumber(getId) {
    $.getScript(scriptbase + 'SP.Runtime.js',
    function () {
        $.getScript(scriptbase + 'SP.js',
            function () {
                $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });
    function execCrossDomainRequest() {
        var executor = new SP.RequestExecutor(appUrl);
        var domain = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('" + listName + "')/items(" + idParameter + ")?@target='" + hostUrl + "'";
        if (test) {
            console.log(domain);
        }
        
        var setStatus;
        // get unlock area
        if (getId == 'A') { // information
            setStatus = '1';
        } else if (getId == 'B') { // review
            setStatus = '2';
        } else if (getId == 'C') { // revision
            setStatus = '3';
        } else if (getId == 'C2') { // approval
            setStatus = '4';
        } else if (getId == 'D') { // finra
            setStatus = '4';
        } else if (getId == 'E') { // state
            setStatus = '4';
        }

        if (setStatus) {
            var exeBody = "{'__metadata': { 'type': 'SP.Data." + listName_metadata + "ListItem' }," +
                "'SectionNumber': '" + setStatus + "'" +
                "}";
            if (test) {
                console.log(exeBody);
            }
            executor.executeAsync({
                url: domain,
                method: 'POST',
                contentType: 'application/json;odata=verbose',
                headers: {
                    'IF-MATCH': '*',
                    'X-HTTP-Method': 'MERGE',
                    'content-type': 'application/json; odata=verbose'
                },
                body: exeBody,
                success: function (data, status, headers, config) {

                    $('#sectionG .success .success_msg').html('Unlock complete');
                    $('#sectionG .success').removeClass('hidden');
                    // hide unlock button and loading
                    $('#unlock-' + getId).addClass('hidden');
                    $('#unlock-' + getId).next().addClass('hidden');
                    // variables from html
                    var tab = $('#unlock-' + getId).attr('data-tab');
                    var statusArea = $('#unlock-' + getId).prev().attr('id');
                    // change status color, text and icon
                    $('#' + statusArea).prev().removeClass('glyphicon-ok-sign').addClass('glyphicon-plus-sign');
                    $('#' + statusArea).closest('.alert-success').removeClass('alert-success').addClass('alert-info');
                    $('#' + statusArea).text('Unlocked');
                    // change icon on tab
                    $('#' + tab).children().children().removeClass('glyphicon-lock').addClass('glyphicon-check');
                    // enable tabs
                    //$('#' + tab).removeClass('disabled');
                    //$('#' + tab + ' a').attr('data-toggle', 'tab');
                    // enable fields
                    $('#section' + getId + ' input, #section' + getId + ' select, #section' + getId + ' textarea').prop('disabled', false);
                    $('#section' + getId + ' .multiselect').removeClass('disable_ms'); // disable UI by default
                    // reveal People Picker replace 
                    $('#section' + getId + ' .replaceUser').removeClass('hidden');
                    // set buttons
                    $('#save-' + getId + '-input, #submit-' + getId + '-input').prop('disabled', false);
                    if (getId == "C2") {
                        $('#ApprovalDate').val(now());
                        $('#ApprovalDate').prop('disabled', true);
                    }
                },
                error: function (jqXHR, exception) {
                    var msg = '';
                    if (jqXHR.status === 0) {
                        msg = 'Not connected.\n Verify Network.';
                    } else if (jqXHR.status == 404) {
                        msg = 'Requested page not found. [404]';
                    } else if (jqXHR.status == 500) {
                        msg = 'Internal Server Error [500].';
                    } else if (exception === 'parsererror') {
                        msg = 'Requested JSON parse failed.';
                    } else if (exception === 'timeout') {
                        msg = 'Time out error.';
                    } else if (exception === 'abort') {
                        msg = 'Ajax request aborted.';
                    } else {
                        msg = 'Uncaught Error.\n' + jqXHR.responseText;
                    }
                    addLog('ENTRY ERROR: ' + msg + '', 'sectionG', 'Unlock Status');
                },
            });
        }
        
    }
}


//Delete CPRO state Filing list data for control number before submit
function deleteStateData(results, action, filingStates, cNumber) {
    $.getScript(scriptbase + 'SP.Runtime.js',
       function () {
           $.getScript(scriptbase + 'SP.js',
               function () {
                   $.getScript(scriptbase + 'SP.RequestExecutor.js', execCrossDomainRequest);
               });
       });
    // After the cross-domain library is loaded, execution 
    function execCrossDomainRequest() {        
        var statesTosave = [];
        var statesToDelete = [];
        var deletedCount = 0;
        var oldData = [];
        for (i = 0; i < results.length; i++) {
            oldData.push(results[i].State);
        }
        if (test) {
            console.log('Delete State Date Function');
        }
        var executor = new SP.RequestExecutor(appUrl);
        var domain1 = '';
        var itemId = '';
        for (j = 0; j < filingStates.length; j++) {
            if (oldData.indexOf(filingStates[j]) < 0) {
                statesTosave.push(filingStates[j]);
                //statesToDelete.push(results[i].ID);
                if (test) {
                    console.log('Save State: ' + filingStates[j]);
                }
            }
        }
        for (i = 0; i < results.length; i++) {
            if (filingStates.indexOf(results[i].State) < 0) {
                statesToDelete.push(results[i].ID);
                if (test) {
                    console.log('Delete State: ' + results[i].ID);
                }
            }
        }
        if (statesToDelete.length > 0) {
            for (i = 0; i < statesToDelete.length; i++) {
                itemId = statesToDelete[i];
                domain1 = appUrl + "/_api/SP.AppContextSite(@target)/web/lists/getbyTitle('" + StateFilingList + "')/items(" + itemId + ")?@target='" + hostUrl + "'";
                if (test) {
                    console.log(domain1);
                }
                executor.executeAsync({
                    url: domain1,
                    method: "POST",
                    async: false,
                    contentType: "application/json;odata=verbose",
                    headers: {
                        "content-type": "application/json; odata=verbose",
                        'IF-MATCH': '*',
                        "Accept": "application/json; odata=verbose",
                        "X-RequestDigest": jQuery("#__REQUESTDIGEST").val(),
                        "X-HTTP-Method": "DELETE"
                    },
                    success: function (data, status, headers, config) {
                        if (test) {
                            console.log('SUCCESS: State Filing List item deleted');
                        }
                        deletedCount++;
                        if (statesToDelete.length == deletedCount)
                        {
                            if (statesTosave.length > 0) {
                                filingStates = statesTosave;
                                saveStates(filingStates, cNumber, action);
                            }
                            else {
                                var section = 'sectionB';
                                // hide loading icon
                                $('#' + section + ' .uploadLoading').addClass('hidden');
                                // reveal success message
                                $('#' + section + ' .success .success_msg').html('Form successfully submitted, redirecting to Main Project List...');
                                $('#' + section + ' .success').removeClass('hidden');
                                // redirect to main list
                                window.parent.location = hostUrl + '/Lists/' + listName + '/AllItems.aspx';
                            }
                        }

                    },
                    error: function (data, errorCode, errorMessage) {
                        console.log('Error' + errorMessage);
                    },

                });
            }
        } else if (statesTosave.length > 0) {
            saveStates(statesTosave, cNumber, action);
        } else if(action == 'submit') {
            var section = 'sectionB';
            // hide loading icon
            $('#' + section + ' .uploadLoading').addClass('hidden');
            // reveal success message
            $('#' + section + ' .success .success_msg').html('Form successfully submitted, redirecting to Main Project List...');
            $('#' + section + ' .success').removeClass('hidden');
            // redirect to main list
            window.parent.location = hostUrl + '/Lists/' + listName + '/AllItems.aspx';
        } else if (action == 'load') {
            // function is executed on page load to check for missing states, end function here.
        }
        
    }
}

// check for submitted status
function disableControls() {
    var statusArray = ['ProjectInformationStatus', 'ComplianceReviewStatus', 'RevisionStatus', 'ApprovalStatus', 'FINRAFilingStatus', 'StateFilingStatus'];
    var searchTerm = ['Information', 'Compliance', 'Revision', 'Approval', 'FINRA', 'State'];
    $.each(statusArray, function (index, value) {
        $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(' + (index + 2) + ')').removeClass('active');
        $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(' + (index + 2) + ') input').attr('checked', false);
        if ($('#' + value).text() != 'Submitted') {
            // hide option from Control tab
            $('#sectionH select#UnLockSection option:contains("' + searchTerm[index] + '")').attr('disabled', 'disabled');
            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(' + (index + 2) + ')').addClass('disabled');
            $('#sectionH #UnLockSection').next('.btn-group').find('li:nth-child(' + (index + 2) + ') input').attr('disabled', 'disabled');
        }
    });
}

// for checking the connection to Service URL
function check() {
    $.ajax({
        type: 'GET',
        url: serviceUrl + '/api/test/1',
        xhrFields: {
            withCredentials: true
        },
        success: function (messages) {
            alert(messages);
        },
        error: function () {
            alert('Error while invoking the Web API');
        }
    });
}
//locking all tabs if project is discontinued
function lockAllTabs() {

}

function convertDropDown(value) {
    if ($.isArray(value) == true) {
        var string = '';
        $.each(value, function (key, value) {
            string = string + value + '; ';
        });
        return string;
    } else {
        return value + ';';
    }
}
