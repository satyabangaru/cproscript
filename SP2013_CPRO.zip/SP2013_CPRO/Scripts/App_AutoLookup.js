﻿var SPAppWebUrl;
var SPHostUrl;
var myData = [];
var availableTags = [];
Sys.Application.add_load(wireEvents);


function wireEvents() {
    $(function () {
         
        SPHostUrl = decodeURIComponent(getQueryStringParameter('SPHostUrl'));
        SPAppWebUrl = decodeURIComponent(getQueryStringParameter('SPAppWebUrl'));

        var scriptbase = SPAppWebUrl + '/_layouts/15/';
        $.getScript(scriptbase + "SP.Runtime.js",
    function () {
        $.getScript(scriptbase + "SP.js",
            function () {
                $.getScript(SPAppWebUrl + '/_layouts/15/SP.RequestExecutor.js', execCrossDomainRequest);
            });
    });

        function execCrossDomainRequest() {

            var executor = new SP.RequestExecutor(SPAppWebUrl);
            // the name of the list to interact with
            var listName = "Compliance PRO List";

            // the url to use for the REST call.
            var url = SPAppWebUrl + "/_api/SP.AppContextSite(@target)" +
                "/web/lists/getbytitle('" + listName + "')/items?" +
                "@target='" + SPHostUrl + "'";

            // create  new executor passing it the url created previously


            // execute the request, this is similar although not the same as a standard AJAX request
            executor.executeAsync(
                {
                    url: url,
                    method: "GET",
                    headers: { "Accept": "application/json; odata=verbose" },
                    success: function (data) {
                        var body = jQuery.parseJSON(data.body);
                        var results = body.d.results;
                        $.each(results, function (i, result) {
                            if (result.CNumber) {
                                myData.push(result.CNumber);
                            }
                            //if (result.Title) {
                            //    myData.push(result.Title);
                            //   // alert("result.Title=" + result.Title);
                            //}

                        });
                        // parse the results into an object that you can use within javascript
                        //var results = eval(JSON.parse(data.body));
                    },
                    error: function (data) {

                        // an error occured, the details can be found in the data object.
                        alert("Ooops an error occured");
                    }
                });

        }

        availableTags = myData;


    });
}
///function to get list items using spservice

function getdata()
{

    function split(val) {
        return val.split(/,/);
    }

    function extractLast(term) {
        var nonSpaceTerm = split(term).pop().toString();
        if (/^\s+\S*/.test(nonSpaceTerm)) {
            nonSpaceTerm = nonSpaceTerm.replace(/\s+/, "");
        }
        return split(nonSpaceTerm).pop();
    }

    $("input[name*='txtKeyword']")
    // don't navigate away from the field on tab when selecting an item
           .bind("keydown", function (event) {
               if (event.keyCode === $.ui.keyCode.TAB &&
                               $(this).data("autocomplete").menu.active) {
                   event.preventDefault();
               }
           })
           .autocomplete(
  {
      minLength: 0,
      source: function (request, response) {
          // delegate back to autocomplete, but extract the last term
          response($.ui.autocomplete.filter(
                      availableTags, extractLast(request.term)));
      },
      focus: function () {
          // prevent value inserted on focus
          return false;
      },
      select: function (event, ui) {
          var terms = split(this.value);
          // remove the current input
          terms.pop();
          // add the selected item
          terms.push(ui.item.value);
          // add placeholder to get the comma-and-space at the end
          //terms.push("");
          //this.value = terms.join(",");
          //this.value += " ";
          this.value = terms;
          return false;
      }
  });
}

function getQueryStringParameter(paramToRetrieve) {
    var params =
        document.URL.split("?")[1].split("&");
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] == paramToRetrieve)
            return singleParam[1];
    }
}

